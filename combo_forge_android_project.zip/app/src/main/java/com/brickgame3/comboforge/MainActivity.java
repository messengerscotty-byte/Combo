package com.brickgame3.comboforge;

import android.app.Activity;
import android.os.Bundle;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    static {
        System.loadLibrary("ocgcore");
        System.loadLibrary("comboengine");
    }

    public static native String nativeEngineVersion();
    public static native String nativeMilestoneTest(android.content.res.AssetManager assetManager);

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public final class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public String engineVersion() {
            try { return nativeEngineVersion(); }
            catch (Throwable t) { return "unavailable: " + t.getClass().getSimpleName(); }
        }

        @JavascriptInterface
        public String engineMilestoneStatus() {
            try { return nativeMilestoneTest(getAssets()); }
            catch (Throwable t) { return "FAIL|jni=" + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()); }
        }

        @JavascriptInterface
        public String imageAsDataUrl(String sourceUrl) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(sourceUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("User-Agent", "ComboForge/1.7");
                try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
                    String mime = conn.getContentType();
                    if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
                    return "data:" + mime + ";base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                }
            } catch (Exception ignored) {
                return "";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @JavascriptInterface
        public void saveImage(String filename, String dataUrl) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Invalid data URL");
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename.endsWith(".png") ? filename : filename + ".png");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Combo Forge");
                android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Could not create image");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Could not open image");
                    out.write(bytes);
                }
                runOnUiThread(() -> Toast.makeText(context, "Saved to Pictures/Combo Forge", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(context, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }
}
