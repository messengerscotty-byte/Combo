package com.brickgame3.comboforge;

import android.app.Activity;
import androidx.core.content.FileProvider;
import android.os.Environment;
import android.provider.Settings;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static boolean nativeAvailable = false;
    private WebView web;
    private SharedPreferences prefs;
    private static final String UPDATE_MANIFEST_URL = "https://messengerscotty-byte.github.io/Combo/update/latest.json";
    private File pendingApk = null;

    static {
        try {
            System.loadLibrary("ocgcore");
            System.loadLibrary("comboengine");
            nativeAvailable = true;
        } catch (Throwable ignored) {
            nativeAvailable = false;
        }
    }

    public static native String nativeEngineVersion();
    public static native String nativeSessionCreate(android.content.res.AssetManager assets, String updateRoot);
    public static native String nativeSessionAddCard(int code,int owner,int controller,int location,int sequence,int position);
    public static native String nativeSessionStart();
    public static native String nativeSessionProcess();
    public static native String nativeSessionRespond(String hex);
    public static native void nativeSessionDestroy();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
        prefs=getSharedPreferences("combo_forge_updates", Context.MODE_PRIVATE);
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new CacheClient());
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy(){
        if(nativeAvailable){try{nativeSessionDestroy();}catch(Throwable ignored){}}
        if(web!=null)web.destroy();
        super.onDestroy();
    }

    @Override public void onWindowFocusChanged(boolean f){
        super.onWindowFocusChanged(f);
        if(f)getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private File updateRoot(){ return new File(getFilesDir(),"engine-updates"); }
    private File updatedDb(){ return new File(updateRoot(),"db/cards.tsv"); }
    private File scriptsRoot(){ return new File(updateRoot(),"scripts"); }

    private String readAll(InputStream in) throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[16384]; int n;
        while((n=in.read(buf))!=-1)out.write(buf,0,n);
        in.close();
        return out.toString("UTF-8");
    }

    private String readTextFile(File f){
        try{return readAll(new FileInputStream(f));}catch(Throwable t){return "";}
    }

    private String bundledRevision(String key){
        try{
            String txt=readAll(getAssets().open("engine/SOURCE-REVISIONS.txt"));
            for(String line:txt.split("\n")){
                if(line.startsWith(key+"="))return line.substring(key.length()+1).trim();
            }
        }catch(Throwable ignored){}
        return "";
    }

    private String currentRevision(String key){
        String saved=prefs.getString(key+"_sha","");
        return saved.isEmpty()?bundledRevision(key):saved;
    }

    private String latestSha(String repo) throws Exception{
        URL u=new URL("https://api.github.com/repos/ProjectIgnis/"+repo+"/commits/master");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent","ComboForge/5.6");
        c.setRequestProperty("Accept","application/vnd.github+json");
        int code=c.getResponseCode();
        if(code<200||code>=300)throw new Exception("GitHub HTTP "+code);
        String body=readAll(c.getInputStream());
        int p=body.indexOf("\"sha\"");
        if(p<0)throw new Exception("No SHA");
        int q=body.indexOf('"',p+5), r=body.indexOf('"',q+1);
        if(q<0||r<0)throw new Exception("Bad SHA");
        return body.substring(q+1,r);
    }

    private void download(String url, File out) throws Exception{
        File parent=out.getParentFile(); if(parent!=null)parent.mkdirs();
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(15000); c.setReadTimeout(60000);
        c.setRequestProperty("User-Agent","ComboForge/5.6");
        int code=c.getResponseCode();
        if(code<200||code>=300)throw new Exception("Download HTTP "+code);
        BufferedInputStream in=new BufferedInputStream(c.getInputStream());
        BufferedOutputStream os=new BufferedOutputStream(new FileOutputStream(out));
        byte[] buf=new byte[32768]; int n;
        while((n=in.read(buf))!=-1)os.write(buf,0,n);
        os.close(); in.close();
    }

    private String cleanTsv(String s){
        if(s==null)return "";
        return s.replace("\\","\\\\").replace("\t","\\t").replace("\r","").replace("\n","\\n");
    }

    private void exportCdb(File cdb, File tsv) throws Exception{
        File parent=tsv.getParentFile(); if(parent!=null)parent.mkdirs();
        SQLiteDatabase db=SQLiteDatabase.openDatabase(cdb.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        Cursor cur=db.rawQuery(
            "select d.id,d.alias,d.setcode,d.type,d.atk,d.def,d.level,d.race,d.attribute,"+
            "coalesce(t.name,''),coalesce(t.desc,'') from datas d left join texts t on t.id=d.id order by d.id", null);
        BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(tsv));
        out.write("#id\talias\tsetcode\ttype\tatk\tdef\tlevel\trace\tattribute\tname\tdesc\n".getBytes(StandardCharsets.UTF_8));
        StringBuilder row=new StringBuilder(1024);
        while(cur.moveToNext()){
            row.setLength(0);
            for(int i=0;i<9;i++){ if(i>0)row.append('\t'); row.append(cur.getLong(i)); }
            row.append('\t').append(cleanTsv(cur.getString(9))).append('\t').append(cleanTsv(cur.getString(10))).append('\n');
            out.write(row.toString().getBytes(StandardCharsets.UTF_8));
        }
        out.close(); cur.close(); db.close();
    }

    private void deleteTree(File f){
        if(f==null||!f.exists())return;
        if(f.isDirectory()){
            File[] kids=f.listFiles();
            if(kids!=null)for(File k:kids)deleteTree(k);
        }
        f.delete();
    }

    private void unzipScripts(File zip, File dest) throws Exception{
        File tmp=new File(updateRoot(),"scripts-new");
        deleteTree(tmp); tmp.mkdirs();
        ZipInputStream zin=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)));
        ZipEntry e; byte[] buf=new byte[32768];
        while((e=zin.getNextEntry())!=null){
            String n=e.getName();
            int slash=n.indexOf('/');
            if(slash>=0)n=n.substring(slash+1); // strip GitHub's generated top folder
            if(n.isEmpty()||n.contains("..")){zin.closeEntry();continue;}
            File out=new File(tmp,n);
            String canon=out.getCanonicalPath(), root=tmp.getCanonicalPath()+File.separator;
            if(!canon.startsWith(root)){zin.closeEntry();continue;}
            if(e.isDirectory()){out.mkdirs();}
            else{
                File p=out.getParentFile();if(p!=null)p.mkdirs();
                BufferedOutputStream os=new BufferedOutputStream(new FileOutputStream(out));
                int x; while((x=zin.read(buf))!=-1)os.write(buf,0,x);
                os.close();
            }
            zin.closeEntry();
        }
        zin.close();
        deleteTree(dest);
        if(!tmp.renameTo(dest))throw new Exception("Could not activate scripts");
    }

    private void updateCardDb(String sha) throws Exception{
        File raw=new File(updateRoot(),"db/cards.cdb.tmp");
        download("https://raw.githubusercontent.com/ProjectIgnis/BabelCDB/master/cards.cdb",raw);
        File newTsv=new File(updateRoot(),"db/cards.tsv.new");
        exportCdb(raw,newTsv);
        File live=updatedDb();
        if(live.exists())live.delete();
        if(!newTsv.renameTo(live))throw new Exception("Could not activate database");
        raw.delete();
        prefs.edit().putString("BabelCDB_sha",sha).apply();
    }

    private void updateScripts(String sha) throws Exception{
        File zip=new File(updateRoot(),"cardscripts.zip");
        download("https://api.github.com/repos/ProjectIgnis/CardScripts/zipball/master",zip);
        unzipScripts(zip,scriptsRoot());
        zip.delete();
        prefs.edit().putString("CardScripts_sha",sha).apply();
    }

    private void js(String call){
        runOnUiThread(()->{
            if(web!=null)web.evaluateJavascript(call,null);
        });
    }

    private String jsQuote(String s){
        if(s==null)return "\"\"";
        return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","")+"\"";
    }


    private int currentVersionCode(){
        try{
            if(android.os.Build.VERSION.SDK_INT>=28)
                return (int)getPackageManager().getPackageInfo(getPackageName(),0).getLongVersionCode();
            return getPackageManager().getPackageInfo(getPackageName(),0).versionCode;
        }catch(Throwable t){return 0;}
    }

    private String currentVersionName(){
        try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Throwable t){return "";}
    }

    private String httpText(String url) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url+"?t="+System.currentTimeMillis()).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(15000);
        c.setUseCaches(false);
        c.setRequestProperty("User-Agent","ComboForge/"+currentVersionName());
        int code=c.getResponseCode();
        if(code<200||code>=300)throw new Exception("HTTP "+code);
        return readAll(c.getInputStream());
    }

    private int jsonInt(String body,String key){
        try{
            String k="\""+key+"\"";
            int p=body.indexOf(k); if(p<0)return 0;
            p=body.indexOf(':',p+k.length()); if(p<0)return 0;
            int e=p+1;
            while(e<body.length()&&Character.isWhitespace(body.charAt(e)))e++;
            int s=e;
            while(e<body.length()&&Character.isDigit(body.charAt(e)))e++;
            return Integer.parseInt(body.substring(s,e));
        }catch(Throwable t){return 0;}
    }

    private String jsonString(String body,String key){
        try{
            String k="\""+key+"\"";
            int p=body.indexOf(k); if(p<0)return "";
            p=body.indexOf(':',p+k.length()); if(p<0)return "";
            int q=body.indexOf('"',p+1); if(q<0)return "";
            int r=q+1; StringBuilder out=new StringBuilder();
            while(r<body.length()){
                char ch=body.charAt(r++);
                if(ch=='"')break;
                if(ch=='\\'&&r<body.length()){
                    char n=body.charAt(r++);
                    if(n=='n')out.append('\n');
                    else if(n=='r')out.append('\r');
                    else if(n=='t')out.append('\t');
                    else out.append(n);
                }else out.append(ch);
            }
            return out.toString();
        }catch(Throwable t){return "";}
    }

    private void checkForAppUpdate(){
        new Thread(()->{
            try{
                String body=httpText(UPDATE_MANIFEST_URL);
                int remoteCode=jsonInt(body,"versionCode");
                String remoteName=jsonString(body,"versionName");
                String apkUrl=jsonString(body,"apkUrl");
                String notes=jsonString(body,"notes");
                boolean available=remoteCode>currentVersionCode()&&!apkUrl.isEmpty();
                js("window.comboAppUpdateResult&&window.comboAppUpdateResult({ok:true,available:"+available+
                   ",versionCode:"+remoteCode+",versionName:"+jsQuote(remoteName)+",apkUrl:"+jsQuote(apkUrl)+
                   ",notes:"+jsQuote(notes)+"});");
            }catch(Throwable t){
                js("window.comboAppUpdateResult&&window.comboAppUpdateResult({ok:false,error:"+jsQuote(t.getMessage())+"});");
            }
        },"cf-app-update-check").start();
    }

    private void downloadAppUpdate(String apkUrl){
        new Thread(()->{
            try{
                js("window.comboAppUpdateProgress&&window.comboAppUpdateProgress('Downloading app update…');");
                File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"updates");
                dir.mkdirs();
                File apk=new File(dir,"Combo-Forge-update.apk");
                download(apkUrl,apk);
                pendingApk=apk;
                js("window.comboAppUpdateProgress&&window.comboAppUpdateProgress('Download complete. Opening Android installer…');");
                installPendingApk();
            }catch(Throwable t){
                js("window.comboAppUpdateFinished&&window.comboAppUpdateFinished({ok:false,error:"+jsQuote(t.getMessage())+"});");
            }
        },"cf-app-update-download").start();
    }

    private void installPendingApk(){
        runOnUiThread(()->{
            try{
                if(pendingApk==null||!pendingApk.exists()){
                    js("window.comboAppUpdateFinished&&window.comboAppUpdateFinished({ok:false,error:'Downloaded APK is missing'});");
                    return;
                }
                if(android.os.Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()){
                    Intent perm=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:"+getPackageName()));
                    startActivity(perm);
                    js("window.comboAppUpdateNeedsPermission&&window.comboAppUpdateNeedsPermission();");
                    return;
                }
                Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",pendingApk);
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri,"application/vnd.android.package-archive");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }catch(Throwable t){
                js("window.comboAppUpdateFinished&&window.comboAppUpdateFinished({ok:false,error:"+jsQuote(t.getMessage())+"});");
            }
        });
    }

    private class CacheClient extends WebViewClient{
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
            try{
                Uri u=request.getUrl();
                if(u!=null && "images.ygoprodeck.com".equalsIgnoreCase(u.getHost()) && u.getPath()!=null && u.getPath().contains("/images/cards/")){
                    String name=u.getLastPathSegment();
                    if(name!=null && name.matches("[0-9]+\\.jpg")){
                        File dir=new File(getCacheDir(),"card-images");dir.mkdirs();
                        File f=new File(dir,name);
                        if(!f.exists()||f.length()<1000){
                            File tmp=new File(dir,name+".tmp");
                            download(u.toString(),tmp);
                            if(f.exists())f.delete();
                            tmp.renameTo(f);
                        }
                        if(f.exists())return new WebResourceResponse("image/jpeg",null,new FileInputStream(f));
                    }
                }
            }catch(Throwable ignored){}
            return super.shouldInterceptRequest(view,request);
        }
    }

    public class Bridge {
        @JavascriptInterface public String readAssetText(String path){
            if(path==null||path.contains(".."))return "";
            try{
                if("engine/db/cards.tsv".equals(path) && updatedDb().exists()){
                    String txt=readTextFile(updatedDb());
                    if(!txt.isEmpty())return txt;
                }
                return readAll(getAssets().open(path));
            }catch(Throwable t){return "";}
        }

        @JavascriptInterface public String dataInfo(){
            String b=currentRevision("BabelCDB");
            String s=currentRevision("CardScripts");
            return "{\"babel\":"+jsQuote(b)+",\"scripts\":"+jsQuote(s)+",\"updatedDb\":"+(updatedDb().exists()?"true":"false")+
                   ",\"updatedScripts\":"+(scriptsRoot().exists()?"true":"false")+"}";
        }

        @JavascriptInterface public void checkDataUpdates(){
            new Thread(()->{
                try{
                    String lb=latestSha("BabelCDB");
                    String ls=latestSha("CardScripts");
                    boolean db=!lb.equals(currentRevision("BabelCDB"));
                    boolean sc=!ls.equals(currentRevision("CardScripts"));
                    js("window.comboDataUpdateResult&&window.comboDataUpdateResult({ok:true,db:"+db+",scripts:"+sc+
                       ",babel:"+jsQuote(lb)+",scriptSha:"+jsQuote(ls)+"});");
                }catch(Throwable t){
                    js("window.comboDataUpdateResult&&window.comboDataUpdateResult({ok:false,error:"+jsQuote(t.getMessage())+"});");
                }
            },"cf-update-check").start();
        }

        @JavascriptInterface public void updateAllData(){
            new Thread(()->{
                try{
                    js("window.comboDataUpdateProgress&&window.comboDataUpdateProgress('Checking current Project Ignis data…');");
                    String b=latestSha("BabelCDB");
                    String s=latestSha("CardScripts");
                    if(!b.equals(currentRevision("BabelCDB")) || !updatedDb().exists()){
                        js("window.comboDataUpdateProgress&&window.comboDataUpdateProgress('Downloading card database…');");
                        updateCardDb(b);
                    }
                    if(!s.equals(currentRevision("CardScripts")) || !scriptsRoot().exists()){
                        js("window.comboDataUpdateProgress&&window.comboDataUpdateProgress('Downloading card scripts…');");
                        updateScripts(s);
                    }
                    prefs.edit().putLong("last_update",System.currentTimeMillis()).apply();
                    js("window.comboDataUpdateFinished&&window.comboDataUpdateFinished({ok:true});");
                }catch(Throwable t){
                    js("window.comboDataUpdateFinished&&window.comboDataUpdateFinished({ok:false,error:"+jsQuote(t.getMessage())+"});");
                }
            },"cf-data-update").start();
        }

        @JavascriptInterface public void clearDownloadedData(){
            deleteTree(updateRoot());
            prefs.edit().clear().apply();
        }

        @JavascriptInterface public String appVersion(){
            return "{\"versionCode\":"+currentVersionCode()+",\"versionName\":"+jsQuote(currentVersionName())+"}";
        }
        @JavascriptInterface public void checkAppUpdate(){checkForAppUpdate();}
        @JavascriptInterface public void downloadAppUpdate(String apkUrl){
            if(apkUrl==null||!apkUrl.startsWith("https://messengerscotty-byte.github.io/Combo/")) {
                js("window.comboAppUpdateFinished&&window.comboAppUpdateFinished({ok:false,error:'Refused untrusted update URL'});");
                return;
            }
            downloadAppUpdate(apkUrl);
        }
        @JavascriptInterface public void installDownloadedUpdate(){installPendingApk();}
        @JavascriptInterface public String engineVersion(){
            if(!nativeAvailable)return "NATIVE_OFFLINE";
            try{return nativeEngineVersion();}catch(Throwable t){return "NATIVE_ERROR";}
        }
        @JavascriptInterface public String sessionCreate(){
            if(!nativeAvailable)return "FAIL|NATIVE_OFFLINE";
            try{return nativeSessionCreate(getAssets(),updateRoot().getAbsolutePath());}catch(Throwable t){return "FAIL|NATIVE_ERROR";}
        }
        @JavascriptInterface public String addCard(int code,int owner,int controller,int location,int sequence,int position){
            if(!nativeAvailable)return "FAIL|NATIVE_OFFLINE";
            try{return nativeSessionAddCard(code,owner,controller,location,sequence,position);}catch(Throwable t){return "FAIL|NATIVE_ERROR";}
        }
        @JavascriptInterface public String start(){
            if(!nativeAvailable)return "FAIL|NATIVE_OFFLINE";
            try{return nativeSessionStart();}catch(Throwable t){return "FAIL|NATIVE_ERROR";}
        }
        @JavascriptInterface public String process(){
            if(!nativeAvailable)return "FAIL|NATIVE_OFFLINE";
            try{return nativeSessionProcess();}catch(Throwable t){return "FAIL|NATIVE_ERROR";}
        }
        @JavascriptInterface public String respond(String hex){
            if(!nativeAvailable)return "FAIL|NATIVE_OFFLINE";
            try{return nativeSessionRespond(hex);}catch(Throwable t){return "FAIL|NATIVE_ERROR";}
        }
        @JavascriptInterface public void destroy(){if(nativeAvailable){try{nativeSessionDestroy();}catch(Throwable ignored){}}}
    }
}
