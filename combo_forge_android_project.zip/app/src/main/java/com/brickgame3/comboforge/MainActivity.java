package com.brickgame3.comboforge;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    static { System.loadLibrary("ocgcore"); System.loadLibrary("comboengine"); }
    private WebView web;

    public static native String nativeEngineVersion();
    public static native String nativeSessionCreate(android.content.res.AssetManager assets);
    public static native String nativeSessionAddCard(int code,int owner,int controller,int location,int sequence,int position);
    public static native String nativeSessionStart();
    public static native String nativeSessionProcess();
    public static native String nativeSessionRespond(String hex);
    public static native void nativeSessionDestroy();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        web=new WebView(this);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(),"AndroidBridge");
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onDestroy(){nativeSessionDestroy();if(web!=null)web.destroy();super.onDestroy();}
    @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}

    public class Bridge {
        @JavascriptInterface public String engineVersion(){return nativeEngineVersion();}
        @JavascriptInterface public String sessionCreate(){return nativeSessionCreate(getAssets());}
        @JavascriptInterface public String addCard(int code,int owner,int controller,int location,int sequence,int position){return nativeSessionAddCard(code,owner,controller,location,sequence,position);}
        @JavascriptInterface public String start(){return nativeSessionStart();}
        @JavascriptInterface public String process(){return nativeSessionProcess();}
        @JavascriptInterface public String respond(String hex){return nativeSessionRespond(hex);}
        @JavascriptInterface public void destroy(){nativeSessionDestroy();}
    }
}
