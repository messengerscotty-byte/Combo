package com.brickgame3.comboforge;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.Window;
import android.view.WindowManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    static {
        System.loadLibrary("ocgcore");
        System.loadLibrary("comboengine");
    }

    public static native String nativeEngineVersion();
    public static native String nativeMilestoneTest(android.content.res.AssetManager assetManager);
    public static native String nativeSessionCreate(android.content.res.AssetManager assetManager);
    public static native String nativeSessionAddCard(int code, int team, int loc, int seq, int pos);
    public static native String nativeSessionStart();
    public static native String nativeSessionProcess();
    public static native String nativeSessionRespond(String hex);
    public static native void nativeSessionDestroy();

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Force true device landscape; CSS media queries alone cannot rotate an Android Activity.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        enterImmersiveLandscape();
        webView = new WebView(this);
        setContentView(webView);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }


    private void enterImmersiveLandscape() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        enterImmersiveLandscape();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersiveLandscape();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public final class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public String engineVersion() {
            try { return nativeEngineVersion(); }
            catch (Throwable t) { return "unavailable: " + t.getClass().getSimpleName(); }
        }

        @JavascriptInterface
        public String engineMilestoneStatus() {
            try { return nativeMilestoneTest(getAssets()); }
            catch (Throwable t) { return "FAIL|jni=" + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()); }
        }


        @JavascriptInterface public String engineSessionCreate() { try { return nativeSessionCreate(getAssets()); } catch (Throwable t) { return "FAIL|" + t; } }
        @JavascriptInterface public String engineSessionAddCard(int code,int team,int loc,int seq,int pos) { try { return nativeSessionAddCard(code,team,loc,seq,pos); } catch (Throwable t) { return "FAIL|" + t; } }
        @JavascriptInterface public String engineSessionStart() { try { return nativeSessionStart(); } catch (Throwable t) { return "FAIL|" + t; } }
        @JavascriptInterface public String engineSessionProcess() { try { return nativeSessionProcess(); } catch (Throwable t) { return "FAIL|" + t; } }
        @JavascriptInterface public String engineSessionRespond(String hex) { try { return nativeSessionRespond(hex); } catch (Throwable t) { return "FAIL|" + t; } }
        @JavascriptInterface public void engineSessionDestroy() { try { nativeSessionDestroy(); } catch (Throwable ignored) {} }

        @JavascriptInterface
        public String imageAsDataUrl(String sourceUrl) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(sourceUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("User-Agent", "ComboForge/2.0");
                try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
                    String mime = conn.getContentType();
                    if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
                    return "data:" + mime + ";base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                }
            } catch (Exception ignored) {
                return "";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @JavascriptInterface
        public void saveImage(String filename, String dataUrl) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Invalid data URL");
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, filename.endsWith(".png") ? filename : filename + ".png");
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Combo Forge");
                android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Could not create image");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Could not open image");
                    out.write(bytes);
                }
                runOnUiThread(() -> Toast.makeText(context, "Saved to Pictures/Combo Forge", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(context, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }
}
