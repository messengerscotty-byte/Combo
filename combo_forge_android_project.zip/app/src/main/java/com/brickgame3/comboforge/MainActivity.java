package com.brickgame3.comboforge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String REMOTE_URL = "https://messengerscotty-byte.github.io/Combo/";
    private static final String LOCAL_URL = "file:///android_asset/index.html";
    private WebView webView;
    private boolean usingFallback = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (isTrusted(url)) view.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
                else view.removeJavascriptInterface("AndroidBridge");
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (isTrusted(url)) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            }

            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame() && !usingFallback) {
                    usingFallback = true;
                    Toast.makeText(MainActivity.this, "Offline — opening the built-in version", Toast.LENGTH_SHORT).show();
                    view.loadUrl(LOCAL_URL);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl(REMOTE_URL + "?app=" + System.currentTimeMillis());
    }

    private boolean isTrusted(String url) {
        return url.startsWith(LOCAL_URL) || url.startsWith(REMOTE_URL);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidBridge {
        @JavascriptInterface public String imageAsDataUrl(String source) {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(source);
                if (!"https".equals(url.getProtocol()) || !"images.ygoprodeck.com".equals(url.getHost())) return "";
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("User-Agent", "ComboForge/1.4");
                try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int read;
                    int total = 0;
                    while ((read = input.read(buffer)) != -1) {
                        total += read;
                        if (total > 6 * 1024 * 1024) return "";
                        output.write(buffer, 0, read);
                    }
                    String mime = connection.getContentType();
                    if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
                    return "data:" + mime + ";base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
                }
            } catch (Exception ignored) {
                return "";
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        @JavascriptInterface public void saveImage(String filename, String dataUrl) {
            runOnUiThread(() -> {
                try {
                    String safeName = filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                    String payload = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = Base64.decode(payload, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Combo Forge");
                    android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("Could not create image");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                    Toast.makeText(MainActivity.this, "Saved to Pictures/Combo Forge", Toast.LENGTH_LONG).show();
                } catch (Exception error) {
                    Toast.makeText(MainActivity.this, "Could not save image", Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
