
(function () {
  var A = document.getElementById('app');
  var DB = [];
  var DB_READY = false;
  var DB_LOADING = false;
  var DB_ERROR = '';
  var searchTimer = null;

  var TYPE = {
    MONSTER:1, SPELL:2, TRAP:4, NORMAL:16, EFFECT:32, FUSION:64, RITUAL:128,
    SPIRIT:512, UNION:1024, GEMINI:2048, TUNER:4096, SYNCHRO:8192,
    QUICKPLAY:65536, CONTINUOUS:131072, EQUIP:262144, FIELD:524288,
    COUNTER:1048576, FLIP:2097152, TOON:4194304, XYZ:8388608,
    PENDULUM:16777216, SPSUMMON:33554432, LINK:67108864
  };

  var ATTR = {1:'EARTH',2:'WATER',4:'FIRE',8:'WIND',16:'LIGHT',32:'DARK',64:'DIVINE'};
  var RACE = {
    1:'Warrior',2:'Spellcaster',4:'Fairy',8:'Fiend',16:'Zombie',32:'Machine',
    64:'Aqua',128:'Pyro',256:'Rock',512:'Winged Beast',1024:'Plant',2048:'Insect',
    4096:'Thunder',8192:'Dragon',16384:'Beast',32768:'Beast-Warrior',65536:'Dinosaur',
    131072:'Fish',262144:'Sea Serpent',524288:'Reptile',1048576:'Psychic',
    2097152:'Divine-Beast',4194304:'Creator God',8388608:'Wyrm',16777216:'Cyberse',
    33554432:'Illusion'
  };

  function fail(msg) {
    if (!A) return;
    A.innerHTML =
      '<div style="height:100%;display:grid;place-items:center;padding:8vw;text-align:center;color:white;font-family:Arial,sans-serif">' +
      '<div><div style="font-size:5vh;font-weight:800;letter-spacing:.2em">COMBO FORGE</div>' +
      '<p style="color:#ff9aa8">Client boot error</p><pre style="white-space:pre-wrap;text-align:left;max-width:80vw">' +
      esc(msg) + '</pre><button id="resetBtn" style="padding:12px 20px">RESET LOCAL DATA</button></div></div>';
    var b=document.getElementById('resetBtn');
    if(b)b.onclick=function(){try{localStorage.clear();}catch(e){} location.reload();};
  }

  window.onerror=function(message,source,line,col){
    fail(String(message)+'\n'+String(source||'')+':'+String(line||0)+':'+String(col||0));
    return true;
  };

  function esc(s){
    return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function bridge(name){
    try{
      if(!window.AndroidBridge)return 'UNAVAILABLE';
      var fn=window.AndroidBridge[name];
      if(typeof fn!=='function')return 'UNAVAILABLE';
      return fn.call(window.AndroidBridge);
    }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e);}
  }
  function img(code){return 'https://images.ygoprodeck.com/images/cards/'+code+'.jpg';}
  function has(v,b){return (v & b)!==0;}
  function isExtra(c){return has(c.type,TYPE.FUSION)||has(c.type,TYPE.SYNCHRO)||has(c.type,TYPE.XYZ)||has(c.type,TYPE.LINK);}
  function isMonster(c){return has(c.type,TYPE.MONSTER);}
  function typeLine(c){
    if(has(c.type,TYPE.SPELL)){
      if(has(c.type,TYPE.QUICKPLAY))return 'Quick-Play Spell';
      if(has(c.type,TYPE.FIELD))return 'Field Spell';
      if(has(c.type,TYPE.EQUIP))return 'Equip Spell';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Spell';
      return 'Spell';
    }
    if(has(c.type,TYPE.TRAP)){
      if(has(c.type,TYPE.COUNTER))return 'Counter Trap';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Trap';
      return 'Trap';
    }
    var a=[];
    if(has(c.type,TYPE.FUSION))a.push('Fusion');
    if(has(c.type,TYPE.SYNCHRO))a.push('Synchro');
    if(has(c.type,TYPE.XYZ))a.push('Xyz');
    if(has(c.type,TYPE.LINK))a.push('Link');
    if(has(c.type,TYPE.RITUAL))a.push('Ritual');
    if(has(c.type,TYPE.PENDULUM))a.push('Pendulum');
    if(has(c.type,TYPE.TUNER))a.push('Tuner');
    if(has(c.type,TYPE.FLIP))a.push('Flip');
    if(has(c.type,TYPE.NORMAL))a.push('Normal');
    else if(has(c.type,TYPE.EFFECT))a.push('Effect');
    return a.join(' / ')+' Monster';
  }

  var state={screen:'home',decks:[],active:null,engine:'checking',selected:null,editorQuery:'',
    editorDraft:null,editorDirty:false,
    appUpdate:{checking:false,available:false,versionName:'',apkUrl:'',notes:'',message:'Not checked'},
    dataUpdate:{checking:false,available:false,db:false,scripts:false,message:'Not checked'}};
  var combo={deckIndex:0,handPick:[],started:false,selectedCode:0,field:null,idle:null,prompt:null,promptObj:null,phase:'MAIN 1',turn:1,log:[],steps:[],viewFlow:null};

  try{
    var raw=localStorage.getItem('cf54_decks') || localStorage.getItem('cf53_decks');
    if(raw){
      var parsed=JSON.parse(raw);
      if(Object.prototype.toString.call(parsed)==='[object Array]')state.decks=parsed;
    }
  }catch(e){try{localStorage.removeItem('cf54_decks');}catch(_){}}

  function persistDecks(){
    try{localStorage.setItem('cf54_decks',JSON.stringify(state.decks));return true;}catch(e){return false;}
  }
  function markDirty(){state.editorDirty=true;updateSaveBadge();}
  function updateSaveBadge(){
    var b=document.getElementById('saveDeckBtn');
    if(b){b.textContent=state.editorDirty?'SAVE DECK *':'SAVE DECK';b.className=state.editorDirty?'savebtn dirty':'savebtn';}
  }
  function saveCurrentDeck(){
    if(state.active==null||!state.editorDraft)return;
    state.decks[state.active]=JSON.parse(JSON.stringify(state.editorDraft));
    if(persistDecks()){state.editorDirty=false;updateSaveBadge();toast('Deck saved');}
    else toast('Could not save deck');
  }
  function normalizeDeck(d){
    if(!d.main)d.main=[];
    if(!d.extra)d.extra=[];
    if(!d.side)d.side=[];
    return d;
  }

  function top(title,back){
    return '<div class="topbar"><button class="iconbtn" data-go="'+(back||'home')+'">✕</button>'+
      '<button class="iconbtn" data-go="home">⌂</button><div class="title">'+esc(title)+'</div>'+
      '<button class="iconbtn" data-go="settings">⚙</button></div>';
  }
  function bindNav(){
    var n=document.querySelectorAll('[data-go]'),i;
    for(i=0;i<n.length;i++)n[i].onclick=function(){
      var next=this.getAttribute('data-go');
      if(state.screen==='editor'&&state.editorDirty){
        if(!confirm('You have unsaved deck changes. Leave without saving?'))return;
        state.editorDraft=null;state.editorDirty=false;
      }
      state.screen=next;render();
    };
  }

  function renderHome(){
    A.innerHTML='<div class="screen home"><div class="brand"><div class="brandmark">CF</div>'+
      '<h1>COMBO FORGE</h1><div class="home-menu"><button id="comboBtn">COMBO LAB</button>'+
      '<button id="deckBtn">DECK MANAGER</button><button id="settingsBtn">SETTINGS</button></div></div>'+
      '<div class="version">v6.2 · Engine '+esc(state.engine)+'</div></div>';
    document.getElementById('comboBtn').onclick=function(){state.screen='duel';render();};
    document.getElementById('deckBtn').onclick=function(){state.screen='manager';render();};
    document.getElementById('settingsBtn').onclick=function(){state.screen='settings';render();};
  }

  function deckCover(d){
    var code=(d.main&&d.main[0])||(d.extra&&d.extra[0])||0;
    return code?'<img src="'+img(code)+'" onerror="this.style.visibility=\'hidden\'">':'<div class="emptycover">CF</div>';
  }

  function renderManager(){
    var tiles='',i,d;
    for(i=0;i<state.decks.length;i++){
      d=normalizeDeck(state.decks[i]);
      tiles+='<div class="decktile" data-deck="'+i+'">'+deckCover(d)+
        '<div class="deckname">'+esc(d.name||('Deck '+(i+1)))+'</div>'+
        '<div class="deckcounts">'+d.main.length+' / '+d.extra.length+' / '+d.side.length+'</div></div>';
    }
    A.innerHTML='<div class="screen">'+top('DECK MANAGER','home')+
      '<div class="manager"><div class="deckgrid">'+tiles+'</div><div class="sidepanel">'+
      '<button class="action full" id="newDeckBtn">CREATE DECK</button>'+
      '<button class="action full" id="dupDeckBtn">DUPLICATE SELECTED</button>'+
      '<button class="dangerbtn full" id="deleteDeckBtn">DELETE SELECTED</button>'+
      '<div class="managerhint">Tap a deck to open it.<br>Main / Extra / Side counts appear under each deck.</div>'+
      '</div></div></div>';
    bindNav();
    document.getElementById('newDeckBtn').onclick=function(){
      state.decks.push({name:'Deck '+(state.decks.length+1),main:[],extra:[],side:[]});
      state.active=state.decks.length-1; persistDecks(); state.editorDraft=JSON.parse(JSON.stringify(state.decks[state.active])); state.editorDirty=false; state.screen='editor'; render();
    };
    var cards=document.querySelectorAll('[data-deck]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){
      state.active=parseInt(this.getAttribute('data-deck'),10);
        state.editorDraft=JSON.parse(JSON.stringify(normalizeDeck(state.decks[state.active])));
        state.editorDirty=false;state.screen='editor';render();
    };
    document.getElementById('dupDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      var copy=JSON.parse(JSON.stringify(state.decks[state.active]));
      copy.name=(copy.name||'Deck')+' Copy';state.decks.push(copy);persistDecks();renderManager();
    };
    document.getElementById('deleteDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      state.decks.splice(state.active,1);state.active=null;persistDecks();renderManager();
    };
  }

  function loadDB(done){
    if(DB_READY){done();return;}
    if(DB_LOADING){setTimeout(function(){loadDB(done);},250);return;}
    DB_LOADING=true; DB_ERROR='';
    var assetText = '';
    try {
      if (window.AndroidBridge && typeof window.AndroidBridge.readAssetText === 'function') {
        assetText = window.AndroidBridge.readAssetText('engine/db/cards.tsv') || '';
      }
    } catch (e) {}
    var source = assetText
      ? Promise.resolve(assetText)
      : fetch('engine/db/cards.tsv').then(function(r){
          if(!r.ok)throw new Error('cards.tsv HTTP '+r.status);
          return r.text();
        });
    source.then(function(text){
      var lines=text.split('\n'),i,cols,cards=[];
      for(i=0;i<lines.length;i++){
        if(!lines[i]||lines[i].charAt(0)==='#')continue;
        cols=lines[i].split('\t');
        if(cols.length<11)continue;
        cards.push({
          id:parseInt(cols[0],10)||0,alias:parseInt(cols[1],10)||0,setcode:cols[2]||'0',
          type:parseInt(cols[3],10)||0,atk:parseInt(cols[4],10)||0,def:parseInt(cols[5],10)||0,
          level:parseInt(cols[6],10)||0,race:parseInt(cols[7],10)||0,attribute:parseInt(cols[8],10)||0,
          name:unescapeField(cols[9]),desc:unescapeField(cols.slice(10).join('\t'))
        });
      }
      DB=cards;DB_READY=true;DB_LOADING=false;done();
    }).catch(function(e){
      DB_ERROR=String(e&&e.message?e.message:e);DB_LOADING=false;done();
    });
  }

  function unescapeField(s){
    return String(s||'').replace(/\\n/g,'\n').replace(/\\t/g,'\t').replace(/\\\\/g,'\\');
  }
  function byId(id){
    var i;
    for(i=0;i<DB.length;i++)if(DB[i].id===id)return DB[i];
    return {id:id,name:'Card '+id,desc:'',type:0,atk:0,def:0,level:0,race:0,attribute:0};
  }
  function copies(d,id){
    var n=0,i,z,arrs=[d.main,d.extra,d.side];
    for(z=0;z<arrs.length;z++)for(i=0;i<arrs[z].length;i++)if(arrs[z][i]===id)n++;
    return n;
  }
  function addCardToDeck(d,c,zone){
    if(copies(d,c.id)>=3){toast('Maximum 3 copies');return false;}
    if(zone==='side'){
      if(d.side.length>=15){toast('Side Deck is full');return false;}
      d.side.push(c.id);
    }else if(isExtra(c)){
      if(d.extra.length>=15){toast('Extra Deck is full');return false;}
      d.extra.push(c.id);
    }else{
      if(d.main.length>=60){toast('Main Deck is full');return false;}
      d.main.push(c.id);
    }
    markDirty();return true;
  }
  function removeOne(d,zone,index){
    if(d[zone]&&index>=0&&index<d[zone].length){d[zone].splice(index,1);markDirty();}
  }
  function toast(msg){
    var old=document.getElementById('toast');if(old&&old.parentNode)old.parentNode.removeChild(old);
    var t=document.createElement('div');t.id='toast';t.className='toast';t.textContent=msg;
    document.body.appendChild(t);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},1400);
  }

  function cardHtml(id,zone,index){
    var c=byId(id);
    return '<div class="deckcard" data-card="'+id+'" data-zone="'+zone+'" data-index="'+index+'" title="'+esc(c.name)+'">'+
      '<img src="'+img(id)+'" onerror="this.className=\'imgfail\'"></div>';
  }
  function zoneCards(arr,zone){
    var out='',i;
    for(i=0;i<arr.length;i++)out+=cardHtml(arr[i],zone,i);
    return out;
  }
  function filterOptions(map){
    var out='<option value="">Any</option>',k;
    for(k in map)if(map.hasOwnProperty(k))out+='<option value="'+k+'">'+esc(map[k])+'</option>';
    return out;
  }
  function monsterKindOptions(){
    return '<option value="">Any monster</option><option value="normal">Normal</option><option value="effect">Effect</option>'+
      '<option value="ritual">Ritual</option><option value="fusion">Fusion</option><option value="synchro">Synchro</option>'+
      '<option value="xyz">Xyz</option><option value="link">Link</option><option value="pendulum">Pendulum</option>'+
      '<option value="tuner">Tuner</option>';
  }

  function renderEditor(){
    var original=state.decks[state.active];
    if(!original){state.screen='manager';render();return;}
    if(!state.editorDraft)state.editorDraft=JSON.parse(JSON.stringify(normalizeDeck(original)));
    var d=state.editorDraft;
    normalizeDeck(d);
    A.innerHTML='<div class="screen">'+top('DECK EDITOR','manager')+
      '<div class="editor">'+
        '<div class="preview" id="preview">'+previewHtml(state.selected?byId(state.selected):null,d)+'</div>'+
        '<div class="decks">'+
          '<div class="zonebox mainzone"><div class="zonehead"><span>MAIN</span><b>'+d.main.length+'</b></div><div class="zonecards" id="mainCards">'+zoneCards(d.main,'main')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>EXTRA</span><b>'+d.extra.length+'</b></div><div class="zonecards" id="extraCards">'+zoneCards(d.extra,'extra')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>SIDE</span><b>'+d.side.length+'</b></div><div class="zonecards" id="sideCards">'+zoneCards(d.side,'side')+'</div></div>'+
        '</div>'+
        '<div class="searchpanel">'+
          '<input class="search" id="q" placeholder="Search card name or text…" value="'+esc(state.editorQuery)+'">'+
          '<div class="filters">'+
            '<select id="cat"><option value="">All cards</option><option value="monster">Monster</option><option value="spell">Spell</option><option value="trap">Trap</option></select>'+
            '<select id="kind">'+monsterKindOptions()+'</select>'+
            '<select id="attr">'+filterOptions(ATTR)+'</select>'+
            '<select id="race">'+filterOptions(RACE)+'</select>'+
            '<input id="level" type="number" min="0" max="13" placeholder="Level / Rank">'+
            '<input id="atk" type="number" placeholder="ATK ≥">'+
            '<input id="def" type="number" placeholder="DEF ≥">'+
            '<select id="sort"><option value="name">Name A–Z</option><option value="nameDesc">Name Z–A</option><option value="atk">ATK High → Low</option><option value="atkAsc">ATK Low → High</option><option value="def">DEF High → Low</option><option value="level">Level/Rank High → Low</option><option value="levelAsc">Level/Rank Low → High</option><option value="type">Card Type</option></select>'+
          '</div>'+
          '<div class="filterbuttons"><button id="clearFilters">CLEAR</button><span id="dbStatus">'+(DB_READY?(DB.length+' cards'):(DB_ERROR?'DB error':'Loading card database…'))+'</span></div>'+
          '<div class="results" id="results"></div>'+
        '</div>'+
      '</div>'+
      '<div class="decktitlebar"><input id="deckName" value="'+esc(d.name||'Deck')+'">'+
      '<button id="saveDeckBtn" class="savebtn">SAVE DECK</button>'+
      '<span>Tap result = add · Hold = Side · Double-tap deck card = remove</span></div>'+
      '</div>';
    bindNav();
    bindDeckCards(d);
    document.getElementById('deckName').oninput=function(){d.name=this.value||d.name;markDirty();};
    document.getElementById('saveDeckBtn').onclick=saveCurrentDeck;
    updateSaveBadge();
    bindSearch(d);
    loadDB(function(){
      if(state.screen==='editor'){
        var s=document.getElementById('dbStatus');
        if(s)s.textContent=DB_ERROR?('DB error: '+DB_ERROR):(DB.length+' cards');
        refreshResults(d);
        refreshPreview(d);
      }
    });
  }

  function previewHtml(c,d){
    if(!c)return '<div class="previewempty"><div>SELECT A CARD</div><small>Tap a card to view details.</small></div>';
    var stat='';
    if(isMonster(c)){
      stat='<div class="cardstats">'+(ATTR[c.attribute]||'')+' · '+(RACE[c.race]||'')+' · '+
        (has(c.type,TYPE.LINK)?('LINK-'+((c.level)&255)):('LV '+((c.level)&255)))+
        '<br>ATK '+c.atk+(has(c.type,TYPE.LINK)?'':(' / DEF '+c.def))+'</div>';
    }
    return '<img class="bigcard" src="'+img(c.id)+'"><h3>'+esc(c.name)+'</h3>'+
      '<div class="typeline">'+esc(typeLine(c))+'</div>'+stat+
      '<p>'+esc(c.desc).replace(/\n/g,'<br>')+'</p>'+
      '<div class="previewbuttons"><button id="addMain">ADD</button><button id="addSide">SIDE +</button><button id="removeCopy">REMOVE 1</button></div>'+
      '<div class="copies">Copies in deck: '+copies(d,c.id)+'</div>';
  }
  function refreshPreview(d){
    var p=document.getElementById('preview');if(!p)return;
    p.innerHTML=previewHtml(state.selected?byId(state.selected):null,d);
    bindPreviewButtons(d);
  }
  function bindPreviewButtons(d){
    var c=state.selected?byId(state.selected):null;if(!c)return;
    var a=document.getElementById('addMain'),s=document.getElementById('addSide'),r=document.getElementById('removeCopy');
    if(a)a.onclick=function(){if(addCardToDeck(d,c,'main'))renderEditor();};
    if(s)s.onclick=function(){if(addCardToDeck(d,c,'side'))renderEditor();};
    if(r)r.onclick=function(){
      var zones=['side','extra','main'],z,i;
      for(z=0;z<zones.length;z++){
        for(i=d[zones[z]].length-1;i>=0;i--)if(d[zones[z]][i]===c.id){d[zones[z]].splice(i,1);markDirty();renderEditor();return;}
      }
    };
  }
  function bindDeckCards(d){
    var nodes=document.querySelectorAll('.deckcard'),i,timer;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){state.selected=parseInt(this.getAttribute('data-card'),10);refreshPreview(d);};
      nodes[i].ondblclick=function(){
        removeOne(d,this.getAttribute('data-zone'),parseInt(this.getAttribute('data-index'),10));renderEditor();
      };
    }
    bindPreviewButtons(d);
  }

  function kindMatch(c,k){
    if(!k)return true;
    if(k==='normal')return has(c.type,TYPE.NORMAL);
    if(k==='effect')return has(c.type,TYPE.EFFECT);
    if(k==='ritual')return has(c.type,TYPE.RITUAL);
    if(k==='fusion')return has(c.type,TYPE.FUSION);
    if(k==='synchro')return has(c.type,TYPE.SYNCHRO);
    if(k==='xyz')return has(c.type,TYPE.XYZ);
    if(k==='link')return has(c.type,TYPE.LINK);
    if(k==='pendulum')return has(c.type,TYPE.PENDULUM);
    if(k==='tuner')return has(c.type,TYPE.TUNER);
    return true;
  }

  function bindSearch(d){
    var ids=['q','cat','kind','attr','race','level','atk','def','sort'],i,el;
    for(i=0;i<ids.length;i++){
      el=document.getElementById(ids[i]);
      if(!el)continue;
      el.oninput=el.onchange=function(){
        if(this.id==='q')state.editorQuery=this.value;
        clearTimeout(searchTimer);searchTimer=setTimeout(function(){refreshResults(d);},120);
      };
    }
    document.getElementById('clearFilters').onclick=function(){
      for(i=0;i<ids.length;i++){el=document.getElementById(ids[i]);if(el)el.value=(ids[i]==='sort'?'name':'');}
      state.editorQuery='';refreshResults(d);
    };
  }

  function refreshResults(d){
    var box=document.getElementById('results');if(!box)return;
    if(!DB_READY){box.innerHTML='<div class="resultmsg">'+(DB_ERROR?esc(DB_ERROR):'Loading card database…')+'</div>';return;}
    var q=(document.getElementById('q').value||'').toLowerCase().trim();
    var cat=document.getElementById('cat').value,kind=document.getElementById('kind').value;
    var attr=parseInt(document.getElementById('attr').value,10)||0;
    var race=parseInt(document.getElementById('race').value,10)||0;
    var level=document.getElementById('level').value;
    var atk=document.getElementById('atk').value,def=document.getElementById('def').value;
    var sort=document.getElementById('sort').value;
    var out=[],i,c,lvl;
    for(i=0;i<DB.length;i++){
      c=DB[i];
      if(q && c.name.toLowerCase().indexOf(q)<0 && c.desc.toLowerCase().indexOf(q)<0)continue;
      if(cat==='monster'&&!has(c.type,TYPE.MONSTER))continue;
      if(cat==='spell'&&!has(c.type,TYPE.SPELL))continue;
      if(cat==='trap'&&!has(c.type,TYPE.TRAP))continue;
      if(kind&&!kindMatch(c,kind))continue;
      if(attr&&c.attribute!==attr)continue;
      if(race&&c.race!==race)continue;
      lvl=(c.level&255);
      if(level!==''&&lvl!==parseInt(level,10))continue;
      if(atk!==''&&c.atk<parseInt(atk,10))continue;
      if(def!==''&&c.def<parseInt(def,10))continue;
      out.push(c);
      if(out.length>600&&q==='')break;
    }
    if(sort==='atk')out.sort(function(a,b){return b.atk-a.atk || a.name.localeCompare(b.name);});
    else if(sort==='atkAsc')out.sort(function(a,b){return a.atk-b.atk || a.name.localeCompare(b.name);});
    else if(sort==='def')out.sort(function(a,b){return b.def-a.def || a.name.localeCompare(b.name);});
    else if(sort==='level')out.sort(function(a,b){return (b.level&255)-(a.level&255) || a.name.localeCompare(b.name);});
    else if(sort==='levelAsc')out.sort(function(a,b){return (a.level&255)-(b.level&255) || a.name.localeCompare(b.name);});
    else if(sort==='nameDesc')out.sort(function(a,b){return b.name.localeCompare(a.name);});
    else if(sort==='type')out.sort(function(a,b){return typeLine(a).localeCompare(typeLine(b)) || a.name.localeCompare(b.name);});
    else out.sort(function(a,b){return a.name.localeCompare(b.name);});
    if(out.length>160)out=out.slice(0,160);
    var html='';
    for(i=0;i<out.length;i++){
      c=out[i];
      html+='<div class="result" data-result="'+c.id+'"><img loading="lazy" src="'+img(c.id)+'" onerror="this.className=\'imgfail\'">'+
        '<div class="resultname">'+esc(c.name)+'</div><span>'+copies(d,c.id)+'</span></div>';
    }
    if(!html)html='<div class="resultmsg">No cards match those filters.</div>';
    box.innerHTML=html;
    var nodes=box.querySelectorAll('[data-result]'),pressTimer,longFired=false;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){
        if(this.getAttribute('data-long')==='1'){this.setAttribute('data-long','0');return;}
        var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'main'))renderEditor();else refreshPreview(d);
      };
      nodes[i].oncontextmenu=function(e){
        e.preventDefault();var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'side'))renderEditor();return false;
      };
      nodes[i].ontouchstart=function(){
        var self=this;self.setAttribute('data-long','0');
        pressTimer=setTimeout(function(){
          self.setAttribute('data-long','1');
          var c=byId(parseInt(self.getAttribute('data-result'),10));state.selected=c.id;
          if(addCardToDeck(d,c,'side'))renderEditor();
        },550);
      };
      nodes[i].ontouchend=function(){clearTimeout(pressTimer);};
      nodes[i].ontouchmove=function(){clearTimeout(pressTimer);};
    }
  }

  var LOC={DECK:1,HAND:2,MZONE:4,SZONE:8,GRAVE:16,REMOVED:32,EXTRA:64,OVERLAY:128};
  var POS={FU_ATTACK:1,FD_ATTACK:2,FU_DEF:4,FD_DEF:8};
  var MSGN={1:'RETRY',2:'HINT',3:'WAITING',4:'START',5:'WIN',6:'UPDATE_DATA',7:'UPDATE_CARD',8:'REQUEST_DECK',
    10:'SELECT_BATTLECMD',11:'SELECT_IDLECMD',12:'SELECT_EFFECTYN',13:'SELECT_YESNO',14:'SELECT_OPTION',15:'SELECT_CARD',
    16:'SELECT_CHAIN',18:'SELECT_PLACE',19:'SELECT_POSITION',20:'SELECT_TRIBUTE',21:'SORT_CHAIN',22:'SELECT_COUNTER',
    23:'SELECT_SUM',24:'SELECT_DISFIELD',25:'SORT_CARD',26:'SELECT_UNSELECT_CARD',30:'CONFIRM_DECKTOP',31:'CONFIRM_CARDS',
    32:'SHUFFLE_DECK',33:'SHUFFLE_HAND',34:'REFRESH_DECK',35:'SWAP_GRAVE_DECK',36:'SHUFFLE_SET_CARD',37:'REVERSE_DECK',
    38:'DECK_TOP',39:'SHUFFLE_EXTRA',40:'NEW_TURN',41:'NEW_PHASE',42:'CONFIRM_EXTRATOP',50:'MOVE',53:'POS_CHANGE',
    54:'SET',55:'SWAP',56:'FIELD_DISABLED',60:'SUMMONING',61:'SUMMONED',62:'SPSUMMONING',63:'SPSUMMONED',
    64:'FLIPSUMMONING',65:'FLIPSUMMONED',70:'CHAINING',71:'CHAINED',72:'CHAIN_SOLVING',73:'CHAIN_SOLVED',74:'CHAIN_END',
    75:'CHAIN_NEGATED',76:'CHAIN_DISABLED',80:'CARD_SELECTED',81:'RANDOM_SELECTED',83:'BECOME_TARGET',90:'DRAW',91:'DAMAGE',
    92:'RECOVER',93:'EQUIP',94:'LPUPDATE',95:'UNEQUIP',96:'CARD_TARGET',97:'CANCEL_TARGET',100:'PAY_LPCOST',
    101:'ADD_COUNTER',102:'REMOVE_COUNTER',110:'ATTACK',111:'BATTLE',112:'ATTACK_DISABLED',113:'DAMAGE_STEP_START',
    114:'DAMAGE_STEP_END',120:'MISSED_EFFECT',121:'BE_CHAIN_TARGET',122:'CREATE_RELATION',123:'RELEASE_RELATION',
    130:'TOSS_COIN',131:'TOSS_DICE',132:'ROCK_PAPER_SCISSORS',133:'HAND_RES',140:'ANNOUNCE_RACE',141:'ANNOUNCE_ATTRIB',
    142:'ANNOUNCE_CARD',143:'ANNOUNCE_NUMBER',160:'CARD_HINT',161:'TAG_SWAP',162:'RELOAD_FIELD',163:'AI_NAME',
    164:'SHOW_HINT',165:'PLAYER_HINT',170:'MATCH_KILL',180:'CUSTOM_MSG',190:'REMOVE_CARDS'};

  function bridgeCall(name,args){
    try{
      if(!window.AndroidBridge)return 'FAIL|NO_BRIDGE';
      var fn=window.AndroidBridge[name];
      if(typeof fn!=='function')return 'FAIL|NO_'+name;
      return fn.apply(window.AndroidBridge,args||[]);
    }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e);}
  }
  function le32hex(n){
    n=(Number(n)>>>0);
    var a=[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255],s='',i;
    for(i=0;i<a.length;i++)s+=('0'+a[i].toString(16)).slice(-2);
    return s;
  }
  function bytesHex(a){var s='',i;for(i=0;i<a.length;i++)s+=('0'+(a[i]&255).toString(16)).slice(-2);return s;}
  function wordsHex(a){var s='',i;for(i=0;i<a.length;i++)s+=le32hex(a[i]);return s;}
  function hexBytes(hex){var out=[],i;hex=String(hex||'');for(i=0;i+1<hex.length;i+=2)out.push(parseInt(hex.substr(i,2),16)||0);return out;}
  function Reader(bytes){this.b=bytes;this.o=0;}
  Reader.prototype.left=function(){return this.b.length-this.o;};
  Reader.prototype.u8=function(){return this.o<this.b.length?this.b[this.o++]:0;};
  Reader.prototype.u16=function(){var b=this.b,o=this.o;this.o+=2;return ((b[o]||0)|((b[o+1]||0)<<8))>>>0;};
  Reader.prototype.u32=function(){var b=this.b,o=this.o;this.o+=4;return ((b[o]||0)|((b[o+1]||0)<<8)|((b[o+2]||0)<<16)|((b[o+3]||0)<<24))>>>0;};
  Reader.prototype.u64=function(){var lo=this.u32(),hi=this.u32();return hi*4294967296+lo;};
  Reader.prototype.skip=function(n){this.o=Math.min(this.b.length,this.o+n);};

  function parsePackets(hex){
    var b=hexBytes(hex),r=new Reader(b),out=[],size,msg,payload;
    while(r.left()>=5){
      size=r.u32();if(size<1||size>r.left())break;
      msg=r.u8();payload=r.b.slice(r.o,r.o+size-1);r.o+=size-1;
      out.push({msg:msg,name:MSGN[msg]||('MSG_'+msg),payload:payload});
    }
    return out;
  }
  function frameResult(raw){
    raw=String(raw||'');
    var sm=/status=(\d+)/.exec(raw),hm=/hex=([0-9a-fA-F]*)/.exec(raw),lm=/log=([^|]*)/.exec(raw);
    return {ok:raw.indexOf('OK|')===0,status:sm?parseInt(sm[1],10):-1,hex:hm?hm[1]:'',log:lm?lm[1]:'',raw:raw};
  }
  function readLoc(r){return {con:r.u8(),loc:r.u8(),seq:r.u32(),pos:r.u32()};}
  function locName(l){return l===LOC.HAND?'Hand':l===LOC.DECK?'Deck':l===LOC.MZONE?'Monster Zone':l===LOC.SZONE?'Spell/Trap Zone':l===LOC.GRAVE?'GY':l===LOC.REMOVED?'Banished':l===LOC.EXTRA?'Extra Deck':'Zone '+l;}
  function cardName(code){var c=byId(code);return c&&c.name?c.name:('Card '+code);}
  function descLabel(desc){return desc?'Effect '+desc:'Effect';}

  function comboDeck(){return state.decks[combo.deckIndex]||null;}
  function loadFlows(){try{var x=JSON.parse(localStorage.getItem('cf_combo_flows')||'[]');return Object.prototype.toString.call(x)==='[object Array]'?x:[];}catch(e){return [];}}
  function saveFlows(x){try{localStorage.setItem('cf_combo_flows',JSON.stringify(x));}catch(e){}}
  function recordStep(kind,text,code,extra){
    if(!combo.started)return;
    combo.steps.push({n:combo.steps.length+1,kind:kind,text:text,code:code||0,extra:extra||'',phase:combo.phase,turn:combo.turn,time:Date.now()});
  }
  function saveCurrentFlow(){
    if(!combo.steps.length){toast('No combo actions recorded yet');return;}
    var flows=loadFlows(),d=comboDeck(),name=(d&&d.name?d.name:'Combo')+' Flow '+(flows.length+1);
    flows.push({id:Date.now(),name:name,deck:d&&d.name?d.name:'',created:new Date().toISOString(),steps:JSON.parse(JSON.stringify(combo.steps))});
    saveFlows(flows);toast('Flow chart saved');
  }
  function flowMermaid(flow){
    var s='flowchart TD\n',i,st,label;
    for(i=0;i<flow.steps.length;i++){
      st=flow.steps[i];label=String(st.text||st.kind).replace(/"/g,"'").replace(/\n/g,' ');
      s+='  N'+i+'["'+(i+1)+'. '+label+'"]\n';if(i>0)s+='  N'+(i-1)+' --> N'+i+'\n';
    }
    return s;
  }

  function parseIdle(payload){
    var r=new Reader(payload),out={type:'idle',player:r.u8(),actions:[],canBP:false,canEP:false,canShuffle:false},i,n,c;
    function cand(kind,cmd,longSeq){
      n=r.u32();
      for(i=0;i<n;i++){c={code:r.u32(),con:r.u8(),loc:r.u8(),seq:longSeq?r.u32():r.u8(),kind:kind,cmd:cmd,index:i};out.actions.push(c);}
    }
    cand('Normal Summon',0,true);cand('Special Summon',1,true);cand('Change Position',2,false);cand('Set Monster',3,true);cand('Set Spell/Trap',4,true);
    n=r.u32();
    for(i=0;i<n;i++)out.actions.push({code:r.u32(),con:r.u8(),loc:r.u8(),seq:r.u32(),desc:r.u64(),flag:r.u8(),kind:'Activate',cmd:5,index:i});
    out.canBP=!!r.u8();out.canEP=!!r.u8();out.canShuffle=!!r.u8();
    return out;
  }
  function parseEffectYN(payload){
    var r=new Reader(payload);return {type:'yesno',effect:true,player:r.u8(),code:r.u32(),loc:readLoc(r),desc:r.u64(),title:'Activate effect?'};
  }
  function parseYesNo(payload){var r=new Reader(payload);return {type:'yesno',player:r.u8(),desc:r.u64(),title:'Continue?'};}
  function parseOption(payload){
    var r=new Reader(payload),o={type:'option',player:r.u8(),options:[]},n=r.u8(),i;
    for(i=0;i<n;i++)o.options.push({index:i,desc:r.u64()});
    o.trailing=r.left();
    return o;
  }
  function parseSelectCard(payload,type){
    var r=new Reader(payload),o={type:type||'cards',player:r.u8(),selected:[],cards:[]},i,n,c;
    o.cancelable=!!r.u8();o.min=r.u32();o.max=r.u32();n=r.u32();
    for(i=0;i<n;i++){c={index:i,code:r.u32(),loc:readLoc(r)};o.cards.push(c);}
    return o;
  }
  function parseTribute(payload){
    var r=new Reader(payload),o={type:'tribute',player:r.u8(),selected:[],cards:[]},i,n,c;
    o.cancelable=!!r.u8();o.min=r.u32();o.max=r.u32();n=r.u32();
    for(i=0;i<n;i++){
      c={index:i,code:r.u32(),loc:{con:r.u8(),loc:r.u8(),seq:r.u32(),pos:0},tributeValue:r.u8()};
      o.cards.push(c);
    }
    o.trailing=r.left();
    return o;
  }
  function parseUnselect(payload){
    var r=new Reader(payload),o={type:'unselect',player:r.u8(),selected:[],cards:[]},i,n,n2,c;
    o.finishable=!!r.u8();o.cancelable=!!r.u8();o.min=r.u32();o.max=r.u32();
    n=r.u32();
    for(i=0;i<n;i++){
      c={index:i,code:r.u32(),loc:readLoc(r),currentlySelected:false};
      o.cards.push(c);
    }
    n2=r.u32();
    for(i=0;i<n2;i++){
      c={index:n+i,code:r.u32(),loc:readLoc(r),currentlySelected:true};
      o.cards.push(c);
    }
    o.trailing=r.left();
    return o;
  }
  function parseChain(payload){
    var r=new Reader(payload),o={type:'chain',player:r.u8(),cards:[]},i,n,c;
    o.specount=r.u8();o.forced=!!r.u8();o.hint0=r.u32();o.hint1=r.u32();n=r.u32();
    for(i=0;i<n;i++){
      c={index:i,code:r.u32(),loc:readLoc(r),desc:r.u64(),flag:r.u8()};
      o.cards.push(c);
    }
    o.trailing=r.left();
    return o;
  }
  function parsePlace(payload){
    var r=new Reader(payload),o={type:'place',player:r.u8(),places:[]},i,avail;
    o.min=Math.max(1,r.u8());o.flag=r.u32();avail=(~o.flag)>>>0;
    for(i=0;i<7;i++)if(avail&(1<<i))o.places.push({con:0,loc:LOC.MZONE,seq:i,label:'Monster Zone '+(i+1)});
    for(i=0;i<5;i++)if(avail&(1<<(8+i)))o.places.push({con:0,loc:LOC.SZONE,seq:i,label:'Spell/Trap Zone '+(i+1)});
    if(avail&(1<<14))o.places.push({con:0,loc:LOC.SZONE,seq:6,label:'Left Pendulum Zone'});
    if(avail&(1<<15))o.places.push({con:0,loc:LOC.SZONE,seq:7,label:'Right Pendulum Zone'});
    for(i=0;i<7;i++)if(avail&(1<<(16+i)))o.places.push({con:1,loc:LOC.MZONE,seq:i,label:'Opponent Monster Zone '+(i+1)});
    for(i=0;i<5;i++)if(avail&(1<<(24+i)))o.places.push({con:1,loc:LOC.SZONE,seq:i,label:'Opponent Spell/Trap '+(i+1)});
    return o;
  }
  function parsePosition(payload){
    var r=new Reader(payload),o={type:'position',player:r.u8(),code:r.u32(),positions:[]},p=r.u8();
    if(p&POS.FU_ATTACK)o.positions.push({v:POS.FU_ATTACK,label:'Face-up Attack'});
    if(p&POS.FD_ATTACK)o.positions.push({v:POS.FD_ATTACK,label:'Face-down Attack'});
    if(p&POS.FU_DEF)o.positions.push({v:POS.FU_DEF,label:'Face-up Defense'});
    if(p&POS.FD_DEF)o.positions.push({v:POS.FD_DEF,label:'Face-down Defense'});
    return o;
  }
  function parseSelectSum(payload){
    var r=new Reader(payload),o={type:'sum',player:r.u8(),cards:[],selected:[]},i,n,c;
    o.mode=r.u8();o.sum=r.u32();o.min=r.u32();o.max=r.u32();o.mustCount=r.u32();
    for(i=0;i<o.mustCount;i++){
      c={index:-(i+1),selectSeq:-1,code:r.u32(),loc:readLoc(r),opParam:r.u32(),must:true};
      o.cards.push(c);
    }
    n=r.u32();
    for(i=0;i<n;i++){
      c={index:i,selectSeq:i,code:r.u32(),loc:readLoc(r),opParam:r.u32(),must:false};
      o.cards.push(c);
    }
    o.trailing=r.left();
    return o;
  }
  function parseCounter(payload){
    var r=new Reader(payload),o={type:'counter',player:r.u8(),cards:[],alloc:[]},i,n,c;
    o.counterType=r.u16();o.count=r.u16();n=r.u32();
    for(i=0;i<n;i++){
      c={index:i,code:r.u32(),loc:{con:r.u8(),loc:r.u8(),seq:r.u8(),pos:0},available:r.u16()};
      o.cards.push(c);o.alloc.push(0);
    }
    o.trailing=r.left();
    return o;
  }
  function parseSort(payload){
    var r=new Reader(payload),o={type:'sort',player:r.u8(),cards:[],order:[]},i,n=r.u32();
    for(i=0;i<n;i++){o.cards.push({index:i,code:r.u32(),con:r.u8(),loc:r.u32(),seq:r.u32()});o.order.push(i);}
    return o;
  }

  function zoneArray(loc){
    if(!combo.field)return null;
    if(loc===LOC.HAND)return combo.field.hand;if(loc===LOC.DECK)return combo.field.deck;if(loc===LOC.EXTRA)return combo.field.extra;
    if(loc===LOC.GRAVE)return combo.field.grave;if(loc===LOC.REMOVED)return combo.field.banished;return null;
  }
  function removeCode(arr,code,seq){
    if(!arr)return 0;var i;
    if(typeof seq==='number'&&seq>=0&&seq<arr.length&&(arr[seq]===code||code===0))return arr.splice(seq,1)[0];
    for(i=0;i<arr.length;i++)if(arr[i]===code)return arr.splice(i,1)[0];
    return code;
  }
  function applyMove(payload){
    if(!combo.field)return;
    var r=new Reader(payload),code=r.u32(),from=readLoc(r),to=readLoc(r),reason=r.u32(),moved=code;
    if(from.loc===LOC.MZONE){moved=combo.field.mz[from.seq]||code;combo.field.mz[from.seq]=null;}
    else if(from.loc===LOC.SZONE){moved=combo.field.sz[from.seq]||code;combo.field.sz[from.seq]=null;}
    else moved=removeCode(zoneArray(from.loc),code,from.seq)||code;
    if(to.loc===LOC.MZONE)combo.field.mz[to.seq]=moved;
    else if(to.loc===LOC.SZONE)combo.field.sz[to.seq]=moved;
    else {var arr=zoneArray(to.loc);if(arr)arr.push(moved);}
    logCore('MOVE '+cardName(moved)+' · '+locName(from.loc)+' → '+locName(to.loc));
  }
  function applyPosChange(payload){
    var r=new Reader(payload),code=r.u32(),loc=readLoc(r);r.u32();var newPos=r.u32();
    logCore('POSITION '+cardName(code)+' → '+newPos);
  }
  function applyDraw(payload){
    var r=new Reader(payload),player=r.u8(),n=r.u32(),i,code;
    for(i=0;i<n;i++){code=r.u32();if(player===0&&combo.field){removeCode(combo.field.deck,code,-1);combo.field.hand.push(code);}}
    logCore('DRAW '+n);
  }
  function logCore(s){combo.log.push(s);if(combo.log.length>120)combo.log.shift();}
  function validatePrompt(o,name){
    if(o&&typeof o.trailing==='number'&&o.trailing!==0)logCore('DECODER '+name+' trailing='+o.trailing+' bytes');
    return o;
  }

  function setPrompt(o,title){
    combo.promptObj=o;combo.prompt=title||o.type;renderDuel();
  }
  function handlePackets(hex){
    var ps=parsePackets(hex),i,p,r,phase,o;
    for(i=0;i<ps.length;i++){
      p=ps[i];logCore(p.name+' · '+p.payload.length+'b');
      if(p.msg===11){combo.idle=parseIdle(p.payload);combo.promptObj=null;combo.prompt='Choose a legal action';}
      else if(p.msg===12){o=parseEffectYN(p.payload);setPrompt(o,'Activate this effect?');return {stop:true};}
      else if(p.msg===13){setPrompt(parseYesNo(p.payload),'Choose yes or no');return {stop:true};}
      else if(p.msg===14){o=validatePrompt(parseOption(p.payload),'SELECT_OPTION');setPrompt(o,'Choose an option');return {stop:true};}
      else if(p.msg===15){o=parseSelectCard(p.payload,'cards');setPrompt(o,'Select card'+(o.max>1?'s':''));return {stop:true};}
      else if(p.msg===16){o=validatePrompt(parseChain(p.payload),'SELECT_CHAIN');setPrompt(o,'Chain response');return {stop:true};}
      else if(p.msg===18||p.msg===24){setPrompt(parsePlace(p.payload),'Choose a zone');return {stop:true};}
      else if(p.msg===19){o=parsePosition(p.payload);if(o.positions.length===1)return {respond:le32hex(o.positions[0].v)};setPrompt(o,'Choose battle position');return {stop:true};}
      else if(p.msg===20){o=validatePrompt(parseTribute(p.payload),'SELECT_TRIBUTE');setPrompt(o,'Select tribute');return {stop:true};}
      else if(p.msg===21||p.msg===25){setPrompt(parseSort(p.payload),'Choose order');return {stop:true};}
      else if(p.msg===22){o=validatePrompt(parseCounter(p.payload),'SELECT_COUNTER');setPrompt(o,'Select counters');return {stop:true};}
      else if(p.msg===23){o=validatePrompt(parseSelectSum(p.payload),'SELECT_SUM');setPrompt(o,'Select materials');return {stop:true};}
      else if(p.msg===26){o=validatePrompt(parseUnselect(p.payload),'SELECT_UNSELECT_CARD');setPrompt(o,'Select / unselect card');return {stop:true};}
      else if(p.msg===40){combo.turn++;combo.prompt='Turn '+combo.turn;}
      else if(p.msg===41){r=new Reader(p.payload);phase=r.u32();combo.phase=phase===1?'DRAW':phase===2?'STANDBY':phase===4?'MAIN 1':phase===128?'BATTLE':phase===256?'MAIN 2':phase===512?'END':('PHASE '+phase);}
      else if(p.msg===50)applyMove(p.payload);
      else if(p.msg===53)applyPosChange(p.payload);
      else if(p.msg===90)applyDraw(p.payload);
      else if(p.msg===61||p.msg===63||p.msg===65||p.msg===74){combo.prompt=p.name;}
      else if(p.msg===5){combo.prompt='Duel complete';recordStep('end','Duel complete');}
      else if(p.msg===1){combo.prompt='Engine requested retry';logCore('RETRY: last response was invalid');}
    }
    return null;
  }
  function pumpFrame(raw,depth){
    depth=depth||0;var f=frameResult(raw),auto;
    if(!f.ok){logCore(f.raw);combo.prompt=f.raw;renderDuel();return;}
    if(f.log)logCore('CORE: '+f.log);
    auto=handlePackets(f.hex);
    if(auto&&auto.respond&&depth<20){pumpFrame(bridgeCall('respond',[auto.respond]),depth+1);return;}
    if(auto&&auto.stop)return;
    if(f.status===2&&depth<20){pumpFrame(bridgeCall('process',[]),depth+1);return;}
    renderDuel();
  }
  function sendResponse(hex,recordText,code){
    if(recordText)recordStep('choice',recordText,code||0);
    combo.promptObj=null;combo.idle=null;combo.prompt='Resolving…';
    pumpFrame(bridgeCall('respond',[hex]),0);
  }
  function selectionResponse(indices){
    var i,max=0,size=indices.length,mode,bytes=[],byteLen,bit;
    for(i=0;i<size;i++)if(indices[i]>max)max=indices[i];
    // Mirrors EDOPro ClientField::SetResponseSelectedCards / GetSuitableReturn.
    if(max<255){
      mode=(max>=size*8)?2:3;
    }else if(max<65535){
      mode=(max>=size*16)?1:3;
    }else{
      mode=(max>=size*32)?0:3;
    }
    function push32(v){bytes.push(v&255,(v>>>8)&255,(v>>>16)&255,(v>>>24)&255);}
    push32(mode);
    if(mode===3){
      byteLen=4+Math.ceil((max+1)/8);
      while(bytes.length<byteLen)bytes.push(0);
      for(i=0;i<size;i++){bit=indices[i];bytes[4+(bit>>3)]|=(1<<(bit&7));}
    }else{
      push32(size);
      if(mode===2){for(i=0;i<size;i++)bytes.push(indices[i]&255);}
      else if(mode===1){for(i=0;i<size;i++)bytes.push(indices[i]&255,(indices[i]>>>8)&255);}
      else{for(i=0;i<size;i++)push32(indices[i]>>>0);}
    }
    return bytesHex(bytes);
  }
  function unselectResponse(index){return wordsHex([1,index>>>0]);}
  function comboSelectedCardFromPrompt(o,idx){var i;for(i=0;i<o.cards.length;i++)if(o.cards[i].index===idx)return o.cards[i];return null;}

  function setupCard(code,index,selected){
    var c=byId(code);
    return '<div class="setupcard '+(selected?'picked':'')+'" data-pick="'+index+'" title="'+esc(c.name)+'"><img src="'+img(code)+'"><span>'+esc(c.name)+'</span></div>';
  }
  function cardThumb(c,idx,selected){
    return '<div class="promptCard '+(selected?'selected':'')+'" data-prompt-index="'+idx+'"><img src="'+img(c.code)+'"><span>'+esc(cardName(c.code))+'</span><small>'+esc(locName(c.loc&&c.loc.loc||c.loc||0))+'</small></div>';
  }

  function renderFlowLibrary(){
    var flows=loadFlows(),i,rows='';
    for(i=0;i<flows.length;i++)rows+='<button class="flowRow" data-flow="'+i+'"><b>'+esc(flows[i].name)+'</b><span>'+flows[i].steps.length+' steps</span></button>';
    return '<div class="flowLibrary"><h3>SAVED COMBO FLOW CHARTS</h3>'+(rows||'<div class="noactions">No saved combo flows yet.</div>')+'</div>';
  }
  function renderFlowView(){
    var flows=loadFlows(),f=flows[combo.viewFlow],i,nodes='';
    if(!f){combo.viewFlow=null;renderDuel();return;}
    for(i=0;i<f.steps.length;i++)nodes+='<div class="flowNode"><span>'+(i+1)+'</span><div><b>'+esc(f.steps[i].text)+'</b><small>Turn '+f.steps[i].turn+' · '+esc(f.steps[i].phase)+'</small></div></div>'+(i<f.steps.length-1?'<div class="flowArrow">↓</div>':'');
    A.innerHTML='<div class="screen">'+top('COMBO FLOW','duel')+'<div class="flowView"><div class="flowViewHead"><h2>'+esc(f.name)+'</h2>'+
      '<button class="action" id="copyMermaid">COPY FLOW CHART TEXT</button><button class="dangerbtn" id="deleteFlow">DELETE</button></div>'+
      '<div class="flowCanvas">'+nodes+'</div></div></div>';
    bindNav();
    document.getElementById('copyMermaid').onclick=function(){var txt=flowMermaid(f);if(navigator.clipboard)navigator.clipboard.writeText(txt);toast('Flow chart copied');};
    document.getElementById('deleteFlow').onclick=function(){flows.splice(combo.viewFlow,1);saveFlows(flows);combo.viewFlow=null;renderDuel();};
  }

  function renderComboSetup(){
    if(combo.viewFlow!=null){renderFlowView();return;}
    var d=comboDeck(),opts='',i,grid='',hand='',flows=loadFlows();
    for(i=0;i<state.decks.length;i++)opts+='<option value="'+i+'" '+(i===combo.deckIndex?'selected':'')+'>'+esc(state.decks[i].name||('Deck '+(i+1)))+'</option>';
    if(d){normalizeDeck(d);for(i=0;i<d.main.length;i++)grid+=setupCard(d.main[i],i,combo.handPick.indexOf(i)>=0);for(i=0;i<combo.handPick.length;i++)hand+=cardHtml(d.main[combo.handPick[i]],'combohand',i);}
    A.innerHTML='<div class="screen">'+top('COMBO LAB','home')+
      '<div class="comboSetup"><div class="comboSetupTop"><label>DECK <select id="comboDeckSelect">'+opts+'</select></label>'+
      '<button class="action" id="randomHand">RANDOM 5</button><button class="action" id="clearHand">CLEAR HAND</button>'+
      '<button class="action comboStart" id="startCombo" '+(!d||combo.handPick.length!==5?'disabled':'')+'>START REAL DUEL</button>'+
      '<span class="badge">Engine '+esc(state.engine)+'</span></div>'+
      '<div class="comboSetupBody"><div class="setupDeck"><div class="zonehead"><span>CHOOSE EXACT STARTING HAND</span><b>'+combo.handPick.length+'/5</b></div>'+
      '<div class="setupGrid">'+(grid||'<div class="resultmsg">Create and save a deck first.</div>')+'</div></div>'+
      '<div class="setupSide"><h3>STARTING HAND</h3><div class="startingHand">'+hand+'</div>'+
      '<p>Tap five individual cards. Combo Forge loads that exact hand into the real Project Ignis/ygopro-core duel engine.</p>'+
      renderFlowLibrary()+'</div></div></div></div>';
    bindNav();
    var sel=document.getElementById('comboDeckSelect');if(sel)sel.onchange=function(){combo.deckIndex=parseInt(this.value,10)||0;combo.handPick=[];renderDuel();};
    var cards=document.querySelectorAll('[data-pick]');for(i=0;i<cards.length;i++)cards[i].onclick=function(){var x=parseInt(this.getAttribute('data-pick'),10),at=combo.handPick.indexOf(x);if(at>=0)combo.handPick.splice(at,1);else if(combo.handPick.length<5)combo.handPick.push(x);renderDuel();};
    var rh=document.getElementById('randomHand');if(rh)rh.onclick=function(){if(!d||d.main.length<5)return;var a=[],j;for(j=0;j<d.main.length;j++)a.push(j);for(j=a.length-1;j>0;j--){var k=Math.floor(Math.random()*(j+1)),t=a[j];a[j]=a[k];a[k]=t;}combo.handPick=a.slice(0,5);renderDuel();};
    var ch=document.getElementById('clearHand');if(ch)ch.onclick=function(){combo.handPick=[];renderDuel();};
    var st=document.getElementById('startCombo');if(st)st.onclick=startComboEngine;
    var fr=document.querySelectorAll('[data-flow]');for(i=0;i<fr.length;i++)fr[i].onclick=function(){combo.viewFlow=parseInt(this.getAttribute('data-flow'),10);renderDuel();};
  }

  function startComboEngine(){
    var d=comboDeck();if(!d||combo.handPick.length!==5)return;
    var create=bridgeCall('sessionCreate',[]);if(String(create).indexOf('PASS|')!==0){combo.prompt=create;combo.started=true;renderDuel();return;}
    var picked={},i,code;
    for(i=0;i<combo.handPick.length;i++)picked[combo.handPick[i]]=true;
    combo.field={hand:[],deck:[],extra:d.extra.slice(),grave:[],banished:[],mz:[null,null,null,null,null,null,null],sz:[null,null,null,null,null,null,null,null]};
    for(i=0;i<d.main.length;i++){code=d.main[i];if(picked[i]){combo.field.hand.push(code);bridgeCall('addCard',[code,0,0,LOC.HAND,0,POS.FU_ATTACK]);}else{combo.field.deck.push(code);bridgeCall('addCard',[code,0,0,LOC.DECK,0,POS.FD_DEF]);}}
    for(i=0;i<d.extra.length;i++)bridgeCall('addCard',[d.extra[i],0,0,LOC.EXTRA,0,POS.FD_DEF]);
    combo.started=true;combo.idle=null;combo.promptObj=null;combo.prompt='Starting ygopro-core…';combo.log=[];combo.steps=[];combo.selectedCode=combo.field.hand[0]||0;combo.phase='MAIN 1';combo.turn=1;
    recordStep('start','Starting hand: '+combo.field.hand.map(cardName).join(' · '));
    pumpFrame(bridgeCall('start',[]),0);
  }

  function duelCard(code,where,seq){
    if(!code)return '<div class="duelzone empty" data-fieldzone="'+where+'" data-seq="'+seq+'"></div>';
    return '<div class="duelzone cardzone" data-duelcard="'+code+'" data-where="'+where+'" data-seq="'+seq+'"><img src="'+img(code)+'"></div>';
  }
  function actionForSelected(){
    if(!combo.idle||!combo.selectedCode)return '';
    var acts=[],i,a,out='';
    for(i=0;i<combo.idle.actions.length;i++){a=combo.idle.actions[i];if(a.code===combo.selectedCode)acts.push(a);}
    for(i=0;i<acts.length;i++)out+='<button class="coreAction" data-cmd="'+acts[i].cmd+'" data-idx="'+acts[i].index+'" data-code="'+acts[i].code+'">'+esc(acts[i].kind)+(acts[i].desc?' · '+esc(descLabel(acts[i].desc)):'')+'</button>';
    if(combo.idle.canBP)out+='<button class="coreAction" data-cmd="6" data-idx="0">Battle Phase</button>';
    if(combo.idle.canEP)out+='<button class="coreAction" data-cmd="7" data-idx="0">End Phase</button>';
    return out||'<div class="noactions">Select a card with a legal engine action.</div>';
  }
  function promptOverlay(){
    var o=combo.promptObj;if(!o)return '';var body='',i,c,sel;
    if(o.type==='yesno'){
      body='<div class="promptQuestion">'+(o.code?'<img src="'+img(o.code)+'">':'')+'<h2>'+esc(o.title||'Choose')+'</h2>'+(o.code?'<b>'+esc(cardName(o.code))+'</b>':'')+'</div>'+
        '<div class="promptButtons"><button class="action" data-prompt-simple="yes">YES</button><button class="dangerbtn" data-prompt-simple="no">NO</button></div>';
    }else if(o.type==='option'){
      for(i=0;i<o.options.length;i++)body+='<button class="optionBtn" data-option="'+i+'">Option '+(i+1)+' · '+esc(descLabel(o.options[i].desc))+'</button>';
    }else if(o.type==='chain'){
      for(i=0;i<o.cards.length;i++){c=o.cards[i];body+='<button class="chainChoice" data-chain="'+c.index+'"><img src="'+img(c.code)+'"><span><b>'+esc(cardName(c.code))+'</b><small>'+esc(descLabel(c.desc))+' · '+esc(locName(c.loc.loc))+'</small></span></button>';}
      if(!o.forced)body+='<button class="dangerbtn full" data-chain="-1">DO NOT CHAIN</button>';
    }else if(o.type==='place'){
      for(i=0;i<o.places.length;i++)body+='<button class="zoneChoice" data-place="'+i+'">'+esc(o.places[i].label)+'</button>';
    }else if(o.type==='position'){
      for(i=0;i<o.positions.length;i++)body+='<button class="optionBtn" data-position="'+o.positions[i].v+'">'+esc(o.positions[i].label)+'</button>';
    }else if(o.type==='sort'){
      for(i=0;i<o.cards.length;i++)body+='<div class="sortItem"><span>'+(i+1)+'</span><img src="'+img(o.cards[i].code)+'"><b>'+esc(cardName(o.cards[i].code))+'</b><button data-sort-up="'+i+'">↑</button><button data-sort-down="'+i+'">↓</button></div>';
      body+='<button class="action full" data-finish-sort="1">CONFIRM ORDER</button>';
    }else if(o.type==='counter'){
      body+='<div class="counterNeed">Place '+o.count+' counter'+(o.count===1?'':'s')+'</div>';
      for(i=0;i<o.cards.length;i++){c=o.cards[i];body+='<button class="counterChoice" data-counter="'+i+'"><img src="'+img(c.code)+'"><span><b>'+esc(cardName(c.code))+'</b><small>'+o.alloc[i]+' / '+c.available+' selected</small></span></button>';}
      body+='<button class="action full" data-finish-counter="1">CONFIRM COUNTERS</button>';
    }else{
      for(i=0;i<o.cards.length;i++){
        c=o.cards[i];sel=(c.must===true)||(o.selected&&o.selected.indexOf(c.index)>=0);
        body+=cardThumb(c,c.index,sel).replace('class="promptCard ','class="promptCard '+(c.must?'mustCard ':''));
      }
      body='<div class="promptCardGrid">'+body+'</div><div class="promptSelectFooter"><span>'+(o.selected?o.selected.length:0)+' selected'+(o.min!=null?' · need '+o.min+(o.max!==o.min?'–'+o.max:''):'')+'</span>'+
        '<button class="action" data-finish-cards="1">CONFIRM</button>'+(o.cancelable?'<button class="dangerbtn" data-cancel-cards="1">CANCEL</button>':'')+'</div>';
    }
    return '<div class="enginePrompt"><div class="enginePromptBox"><div class="promptTitle"><span>YGOPRO-CORE</span><b>'+esc(combo.prompt||'Engine choice')+'</b></div>'+body+'</div></div>';
  }

  function renderActiveDuel(){
    var f=combo.field||{hand:[],deck:[],extra:[],grave:[],banished:[],mz:[],sz:[]},i,mz='',sz='',hand='',oppmz='',oppsz='',phaseBtns='',selName='',selCard=combo.selectedCode?byId(combo.selectedCode):null;
    for(i=0;i<7;i++)mz+=duelCard(f.mz[i],'mz',i);
    for(i=0;i<5;i++)sz+=duelCard(f.sz[i],'sz',i);
    for(i=0;i<7;i++)oppmz+='<div class="duelzone oppZone empty"></div>';
    for(i=0;i<5;i++)oppsz+='<div class="duelzone oppZone empty"></div>';
    for(i=0;i<f.hand.length;i++){
      hand+='<div class="handcard '+(f.hand[i]===combo.selectedCode?'selected':'')+'" data-duelcard="'+f.hand[i]+'" style="--hand-index:'+i+';--hand-count:'+f.hand.length+'"><img src="'+img(f.hand[i])+'"></div>';
    }
    if(combo.idle&&combo.idle.canBP)phaseBtns+='<button class="phaseBtn" data-cmd="6" data-idx="0">BP</button>';
    if(combo.idle&&combo.idle.canEP)phaseBtns+='<button class="phaseBtn" data-cmd="7" data-idx="0">EP</button>';
    if(selCard)selName=selCard.name||('Card '+combo.selectedCode);

    A.innerHTML='<div class="screen duelScreen">'+top('COMBO LAB','home')+
      '<div class="omegaDuel">'+
        '<div class="duelUtility">'+
          '<button class="utilityBtn" id="saveFlow" title="Save combo flow">FLOW</button>'+
          '<button class="utilityBtn" id="processCore" title="Process engine">CORE</button>'+
          '<button class="utilityBtn dangerMini" id="resetCombo" title="Restart combo">RESET</button>'+
        '</div>'+
        '<div class="oppNameplate">OPPONENT</div>'+
        '<div class="oppBackrow">'+oppsz+'</div>'+
        '<div class="oppMonsters">'+oppmz+'</div>'+
        '<div class="centerLine">'+
          '<div class="phaseRail"><button class="phaseStatic active">'+esc(combo.phase)+'</button>'+phaseBtns+'</div>'+
          '<div class="engineStatus"><span>TURN '+combo.turn+'</span><b>'+esc(combo.prompt||'Waiting for engine')+'</b></div>'+
        '</div>'+
        '<div class="playerMonsters">'+mz+'</div>'+
        '<div class="playerBackrow">'+sz+'</div>'+
        '<div class="pileSpot extraSpot" data-pile="extra"><div class="pileStack">'+(f.extra.length?'<img src="'+img(f.extra[f.extra.length-1])+'">':'')+'</div><span>EXTRA</span><b>'+f.extra.length+'</b></div>'+
        '<div class="pileSpot deckSpot" data-pile="deck"><div class="cardBackMini"></div><span>DECK</span><b>'+f.deck.length+'</b></div>'+
        '<div class="pileSpot graveSpot" data-pile="grave"><div class="pileStack">'+(f.grave.length?'<img src="'+img(f.grave[f.grave.length-1])+'">':'')+'</div><span>GY</span><b>'+f.grave.length+'</b></div>'+
        '<div class="pileSpot banishSpot" data-pile="banished"><div class="pileStack">'+(f.banished.length?'<img src="'+img(f.banished[f.banished.length-1])+'">':'')+'</div><span>BANISHED</span><b>'+f.banished.length+'</b></div>'+
        '<div class="handFan">'+hand+'</div>'+
        '<div class="selectedCardStrip">'+
          (combo.selectedCode?'<img src="'+img(combo.selectedCode)+'"><div><b>'+esc(selName)+'</b><div class="inlineActions">'+actionForSelected()+'</div></div>':'<div class="tapHint">Tap a card to see legal engine actions</div>')+
        '</div>'+
        '<button class="debugToggle" id="debugToggle">DEBUG</button>'+
        '<div class="debugDrawer" id="debugDrawer">'+
          '<div class="debugHead"><b>CORE TRACE</b><span>'+combo.steps.length+' flow steps</span></div>'+
          '<div class="flowMini">'+combo.steps.slice(-6).map(function(x){return '<span>'+esc(x.n+'. '+x.text)+'</span>';}).join('')+'</div>'+
          '<div class="coreLog">'+esc(combo.log.slice(-30).join('\n'))+'</div>'+
        '</div>'+
      '</div>'+
      promptOverlay()+
    '</div>';

    bindNav();

    var cards=document.querySelectorAll('[data-duelcard]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){
      combo.selectedCode=parseInt(this.getAttribute('data-duelcard'),10)||0;
      renderDuel();
    };

    var acts=document.querySelectorAll('[data-cmd]');
    for(i=0;i<acts.length;i++)acts[i].onclick=function(){
      var cmd=parseInt(this.getAttribute('data-cmd'),10)||0,idx=parseInt(this.getAttribute('data-idx'),10)||0,code=parseInt(this.getAttribute('data-code'),10)||0;
      var label=cmd===0?'Normal Summon':cmd===1?'Special Summon':cmd===2?'Change Position':cmd===3?'Set Monster':cmd===4?'Set Spell/Trap':cmd===5?'Activate':cmd===6?'Battle Phase':'End Phase';
      recordStep('action',label+(code?' '+cardName(code):''),code);
      combo.idle=null;combo.prompt='Resolving '+label+'…';
      pumpFrame(bridgeCall('respond',[le32hex(((idx<<16)>>>0)+cmd)]),0);
    };

    bindPromptHandlers();

    var sf=document.getElementById('saveFlow');if(sf)sf.onclick=saveCurrentFlow;
    var pc=document.getElementById('processCore');if(pc)pc.onclick=function(){pumpFrame(bridgeCall('process',[]),0);};
    var rc=document.getElementById('resetCombo');if(rc)rc.onclick=function(){
      try{bridgeCall('destroy',[]);}catch(e){}
      combo.started=false;combo.idle=null;combo.promptObj=null;combo.prompt=null;combo.field=null;combo.handPick=[];renderDuel();
    };
    var dt=document.getElementById('debugToggle'),dd=document.getElementById('debugDrawer');
    if(dt&&dd)dt.onclick=function(){dd.classList.toggle('open');};
  }

  function bindPromptHandlers(){
    var o=combo.promptObj;if(!o)return;var i,els;
    els=document.querySelectorAll('[data-prompt-simple]');for(i=0;i<els.length;i++)els[i].onclick=function(){var yes=this.getAttribute('data-prompt-simple')==='yes';sendResponse(le32hex(yes?1:0),yes?'Yes':'No',o.code||0);};
    els=document.querySelectorAll('[data-option]');for(i=0;i<els.length;i++)els[i].onclick=function(){var x=parseInt(this.getAttribute('data-option'),10)||0;sendResponse(le32hex(x),'Choose option '+(x+1));};
    els=document.querySelectorAll('[data-chain]');for(i=0;i<els.length;i++)els[i].onclick=function(){var x=parseInt(this.getAttribute('data-chain'),10),c=x>=0?o.cards[x]:null;sendResponse(le32hex(x),'Chain '+(c?cardName(c.code):'nothing'),c?c.code:0);};
    els=document.querySelectorAll('[data-place]');for(i=0;i<els.length;i++)els[i].onclick=function(){var x=parseInt(this.getAttribute('data-place'),10)||0,p=o.places[x];sendResponse(bytesHex([p.con,p.loc,p.seq]),'Choose '+p.label);};
    els=document.querySelectorAll('[data-position]');for(i=0;i<els.length;i++)els[i].onclick=function(){var v=parseInt(this.getAttribute('data-position'),10)||1;sendResponse(le32hex(v),'Choose '+this.textContent);};
    els=document.querySelectorAll('[data-prompt-index]');for(i=0;i<els.length;i++)els[i].onclick=function(){
      var x=parseInt(this.getAttribute('data-prompt-index'),10),at=o.selected.indexOf(x),c=comboSelectedCardFromPrompt(o,x);
      if(c&&c.must){toast('This material is required');return;}
      if(o.type==='unselect'){sendResponse(unselectResponse(x),'Select '+(c?cardName(c.code):'card'),c?c.code:0);return;}
      if(at>=0)o.selected.splice(at,1);else if(o.max==null||o.selected.length<o.max)o.selected.push(x);renderDuel();
    };
    var fin=document.querySelector('[data-finish-cards]');if(fin)fin.onclick=function(){
      var tributeTotal=0,names=[],j,c;
      if(o.type==='tribute'){
        if(o.selected.length>o.max){toast('Select no more than '+o.max+' tributes');return;}
        for(j=0;j<o.selected.length;j++){c=comboSelectedCardFromPrompt(o,o.selected[j]);if(c)tributeTotal+=c.tributeValue||0;}
        if(tributeTotal<o.min){toast('Not enough tribute value');return;}
      }else{
        if(o.min!=null&&o.type!=='sum'&&o.selected.length<o.min){toast('Select at least '+o.min);return;}
        if(o.max!=null&&o.type!=='sum'&&o.selected.length>o.max){toast('Select no more than '+o.max);return;}
      }
      for(j=0;j<o.selected.length;j++){c=comboSelectedCardFromPrompt(o,o.selected[j]);if(c)names.push(cardName(c.code));}
      sendResponse(selectionResponse(o.selected),'Select '+names.join(' + '),o.selected.length===1&&comboSelectedCardFromPrompt(o,o.selected[0])?comboSelectedCardFromPrompt(o,o.selected[0]).code:0);
    };
    var can=document.querySelector('[data-cancel-cards]');if(can)can.onclick=function(){sendResponse(le32hex(0xffffffff),'Cancel selection');};
    els=document.querySelectorAll('[data-sort-up]');for(i=0;i<els.length;i++)els[i].onclick=function(){var x=parseInt(this.getAttribute('data-sort-up'),10);if(x>0){var t=o.cards[x-1];o.cards[x-1]=o.cards[x];o.cards[x]=t;renderDuel();}};
    els=document.querySelectorAll('[data-sort-down]');for(i=0;i<els.length;i++)els[i].onclick=function(){var x=parseInt(this.getAttribute('data-sort-down'),10);if(x<o.cards.length-1){var t=o.cards[x+1];o.cards[x+1]=o.cards[x];o.cards[x]=t;renderDuel();}};
    var sf=document.querySelector('[data-finish-sort]');if(sf)sf.onclick=function(){var arr=[],j;for(j=0;j<o.cards.length;j++)arr.push(o.cards[j].index);sendResponse(selectionResponse(arr),'Confirm card order');};
    els=document.querySelectorAll('[data-counter]');for(i=0;i<els.length;i++)els[i].onclick=function(){
      var x=parseInt(this.getAttribute('data-counter'),10)||0,total=0,j;
      for(j=0;j<o.alloc.length;j++)total+=o.alloc[j];
      if(total>=o.count){toast('Required counter count reached');return;}
      if(o.alloc[x]<(o.cards[x].available||0)){o.alloc[x]++;renderDuel();}
    };
    var fc=document.querySelector('[data-finish-counter]');if(fc)fc.onclick=function(){
      var total=0,j,bytes=[];for(j=0;j<o.alloc.length;j++)total+=o.alloc[j];
      if(total!==o.count){toast('Select exactly '+o.count+' counters');return;}
      for(j=0;j<o.alloc.length;j++){bytes.push(o.alloc[j]&255,(o.alloc[j]>>>8)&255);}
      sendResponse(bytesHex(bytes),'Place '+o.count+' counters');
    };
  }

  function renderDuel(){if(!combo.started)renderComboSetup();else renderActiveDuel();}

  function removeAppUpdateModal(){
    var m=document.getElementById('appUpdateModal');if(m&&m.parentNode)m.parentNode.removeChild(m);
  }
  function showAppUpdateModal(){
    var u=state.appUpdate;if(!u.available||!u.apkUrl)return;
    removeAppUpdateModal();
    var m=document.createElement('div');m.id='appUpdateModal';m.className='updateModal';
    m.innerHTML='<div class="updateDialog"><div class="updateEyebrow">COMBO FORGE UPDATE</div>'+
      '<h2>Version '+esc(u.versionName||'new')+' is ready</h2>'+
      '<p>'+esc(u.notes||'A newer Combo Forge build is available.')+'</p>'+
      '<div id="appUpdateModalStatus" class="updatesmall">Download it here and Android will open the installer for you.</div>'+
      '<div class="updateActions"><button class="action" id="installAppUpdate">UPDATE NOW</button>'+
      '<button class="dangerbtn" id="laterAppUpdate">LATER</button></div></div>';
    document.body.appendChild(m);
    document.getElementById('laterAppUpdate').onclick=removeAppUpdateModal;
    document.getElementById('installAppUpdate').onclick=function(){
      var b=this;b.disabled=true;b.textContent='DOWNLOADING…';
      try{window.AndroidBridge.downloadAppUpdate(u.apkUrl);}catch(e){
        b.disabled=false;b.textContent='UPDATE NOW';
        var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent='Update failed: '+e.message;
      }
    };
  }
  function checkAppUpdate(showStatus){
    try{
      if(!window.AndroidBridge||typeof window.AndroidBridge.checkAppUpdate!=='function'){
        if(showStatus)toast('App updates are available in the Android app');
        return;
      }
      state.appUpdate.checking=true;state.appUpdate.message='Checking for a newer app build…';
      if(state.screen==='settings')renderSettings();
      window.AndroidBridge.checkAppUpdate();
    }catch(e){
      state.appUpdate.checking=false;state.appUpdate.message='Check failed: '+e.message;
      if(state.screen==='settings')renderSettings();
    }
  }
  window.comboAppUpdateResult=function(r){
    state.appUpdate.checking=false;
    if(!r||!r.ok){
      state.appUpdate.available=false;
      state.appUpdate.message='Could not check right now'+(r&&r.error?': '+r.error:'');
    }else if(r.available){
      state.appUpdate.available=true;
      state.appUpdate.versionName=r.versionName||'';
      state.appUpdate.apkUrl=r.apkUrl||'';
      state.appUpdate.notes=r.notes||'';
      state.appUpdate.message='Version '+state.appUpdate.versionName+' available';
      showAppUpdateModal();
    }else{
      state.appUpdate.available=false;
      state.appUpdate.message='Combo Forge is up to date';
    }
    if(state.screen==='settings')renderSettings();
  };
  window.comboAppUpdateProgress=function(msg){
    state.appUpdate.message=msg||'Updating…';
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    if(state.screen==='settings'){
      var x=document.getElementById('appBuildStatus');if(x)x.textContent=state.appUpdate.message;
    }
  };
  window.comboAppUpdateNeedsPermission=function(){
    state.appUpdate.message='Allow “Install unknown apps” for Combo Forge, return here, then tap INSTALL DOWNLOADED UPDATE.';
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    var b=document.getElementById('installAppUpdate');
    if(b){b.disabled=false;b.textContent='INSTALL DOWNLOADED UPDATE';b.onclick=function(){window.AndroidBridge.installDownloadedUpdate();};}
    if(state.screen==='settings')renderSettings();
  };
  window.comboAppUpdateFinished=function(r){
    if(r&&r.ok){state.appUpdate.message='Installer opened';}
    else state.appUpdate.message='Update failed'+(r&&r.error?': '+r.error:'');
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    if(state.screen==='settings')renderSettings();
  };

  function renderSettings(){
    var u=state.dataUpdate,au=state.appUpdate;
    var status=u.checking?'Checking for updates…':u.message;
    var appStatus=au.checking?'Checking for a newer app build…':au.message;
    A.innerHTML='<div class="screen">'+top('SETTINGS','home')+
      '<div class="settingsbox"><h2>Combo Forge v6.2</h2>'+
      '<p>Landscape simulator client.</p><p>Engine: <b>'+esc(state.engine)+'</b></p>'+
      '<div class="updatebox"><h3>COMBO FORGE APP</h3>'+
      '<div id="appBuildStatus" class="'+(au.available?'warn':'green')+'">'+esc(appStatus)+'</div>'+
      '<p class="updatesmall">The app checks this automatically when it opens. New APKs download inside Combo Forge, then Android asks you to confirm installation.</p>'+
      '<button class="action" id="checkAppBuild">CHECK APP UPDATE</button> '+
      (au.available?'<button class="action" id="installAppBuild">UPDATE TO '+esc(au.versionName)+'</button>':'')+
      '</div>'+
      '<p>Card database: <b>'+(DB_READY?(DB.length+' loaded'):'bundled + downloadable updates')+'</b></p>'+
      '<div class="updatebox"><h3>PROJECT IGNIS DATA</h3>'+
      '<div id="updateStatus" class="'+(u.available?'warn':'green')+'">'+esc(status)+'</div>'+
      '<p class="updatesmall">The APK ships with the complete BabelCDB card database and Project Ignis CardScripts. '+
      'Combo Forge checks for newer Project Ignis data and can download it without reinstalling the APK. '+
      'Downloaded card scripts are used by ygopro-core on the next duel session.</p>'+
      '<button class="action" id="checkUpdates">CHECK FOR UPDATES</button> '+
      '<button class="action" id="updateData" '+(u.checking?'disabled':'')+'>UPDATE CARD DATA + SCRIPTS</button> '+
      '<button class="dangerbtn" id="clearUpdates">USE BUNDLED DATA</button></div>'+
      '<button class="dangerbtn" id="resetData">RESET LOCAL DECK DATA</button></div></div>';
    bindNav();
    document.getElementById('resetData').onclick=function(){try{localStorage.clear();}catch(e){}location.reload();};
    document.getElementById('checkAppBuild').onclick=function(){checkAppUpdate(true);};
    var iab=document.getElementById('installAppBuild');
    if(iab)iab.onclick=function(){showAppUpdateModal();};
    document.getElementById('checkUpdates').onclick=function(){checkDataUpdates(true);};
    document.getElementById('updateData').onclick=function(){
      if(!window.AndroidBridge||typeof window.AndroidBridge.updateAllData!=='function'){toast('Updater only runs in the Android app');return;}
      state.dataUpdate.checking=true;state.dataUpdate.message='Starting update…';renderSettings();
      try{window.AndroidBridge.updateAllData();}catch(e){state.dataUpdate.checking=false;state.dataUpdate.message='Update failed: '+e.message;renderSettings();}
    };
    document.getElementById('clearUpdates').onclick=function(){
      try{if(window.AndroidBridge&&typeof window.AndroidBridge.clearDownloadedData==='function')window.AndroidBridge.clearDownloadedData();}catch(e){}
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      state.dataUpdate={checking:false,available:false,db:false,scripts:false,message:'Using bundled data'};
      toast('Downloaded updates cleared');
      renderSettings();
    };
  }

  window.comboDataUpdateResult=function(r){
    state.dataUpdate.checking=false;
    if(!r||!r.ok){
      state.dataUpdate.available=false;
      state.dataUpdate.message='Could not check right now'+(r&&r.error?': '+r.error:'');
    }else{
      state.dataUpdate.db=!!r.db;state.dataUpdate.scripts=!!r.scripts;
      state.dataUpdate.available=!!(r.db||r.scripts);
      state.dataUpdate.message=state.dataUpdate.available
        ? ('Update available'+(r.db?' · card database':'')+(r.scripts?' · scripts':''))
        : 'Card database and scripts are current';
    }
    if(state.screen==='settings')renderSettings();
  };

  window.comboDataUpdateProgress=function(msg){
    state.dataUpdate.checking=true;state.dataUpdate.message=msg||'Updating…';
    if(state.screen==='settings'){
      var s=document.getElementById('updateStatus');if(s)s.textContent=state.dataUpdate.message;
    }
  };

  window.comboDataUpdateFinished=function(r){
    state.dataUpdate.checking=false;
    if(r&&r.ok){
      state.dataUpdate.available=false;state.dataUpdate.db=false;state.dataUpdate.scripts=false;
      state.dataUpdate.message='Update installed · reload Deck Editor to use the new database';
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      toast('Project Ignis data updated');
    }else{
      state.dataUpdate.message='Update failed'+(r&&r.error?': '+r.error:'');
    }
    if(state.screen==='settings')renderSettings();
  };

  function checkDataUpdates(showStatus){
    try{
      if(!window.AndroidBridge||typeof window.AndroidBridge.checkDataUpdates!=='function'){
        if(showStatus)toast('Update checks run in the Android app');
        return;
      }
      state.dataUpdate.checking=true;state.dataUpdate.message='Checking Project Ignis…';
      if(state.screen==='settings')renderSettings();
      window.AndroidBridge.checkDataUpdates();
    }catch(e){
      state.dataUpdate.checking=false;state.dataUpdate.message='Check failed: '+e.message;
      if(state.screen==='settings')renderSettings();
    }
  }

  function render(){
    if(state.screen==='home')renderHome();
    else if(state.screen==='manager')renderManager();
    else if(state.screen==='editor')renderEditor();
    else if(state.screen==='duel')renderDuel();
    else renderSettings();
  }

  render();
  setTimeout(function(){
    state.engine=bridge('engineVersion');
    if(!state.engine||state.engine==='UNAVAILABLE'||String(state.engine).indexOf('FAIL|')===0)state.engine='offline';
    if(state.screen==='home')renderHome();
  },800);
  setTimeout(function(){checkAppUpdate(false);},1400);
  setTimeout(function(){checkDataUpdates(false);},2800);
})();
