const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const legacyDeck=load('cfg_deck');
const storedDecks=load('cfg_decks')||[];
if(!storedDecks.length&&legacyDeck)storedDecks.push({...legacyDeck,id:legacyDeck.id||`deck-${Date.now()}`});
const state = {
  decks:storedDecks,
  deck: clone(storedDecks[0]||freshDeck()),
  combo: load('cfg_combo') || freshCombo(),
  currentZone:'hand', installPrompt:null
};
const fallbackCards=[
  {id:46986414,name:'Dark Magician',type:'Normal Monster',level:7,race:'Spellcaster',attribute:'DARK',atk:2500,def:2100,desc:'The ultimate wizard in terms of attack and defense.',card_images:[{image_url:'https://images.ygoprodeck.com/images/cards/46986414.jpg'}]},
  {id:74677422,name:'Ash Blossom & Joyous Spring',type:'Tuner Monster',level:3,race:'Zombie',attribute:'FIRE',atk:0,def:1800,desc:'Quick Effect hand trap.',card_images:[{image_url:'https://images.ygoprodeck.com/images/cards/14558127.jpg'}]},
  {id:41999284,name:'Linkuriboh',type:'Link Monster',linkval:1,race:'Cyberse',attribute:'DARK',atk:300,desc:'1 Level 1 monster',card_images:[{image_url:'https://images.ygoprodeck.com/images/cards/41999284.jpg'}]},
  {id:44095762,name:'Polymerization',type:'Spell Card',race:'Normal',desc:'Fusion Summon 1 Fusion Monster from your Extra Deck.',card_images:[{image_url:'https://images.ygoprodeck.com/images/cards/24094653.jpg'}]}
];
function freshCombo(){return {name:'New Combo',starting:[],started:false,hand:[],deck:[],extra:[],gy:[],banished:[],field:Array(5).fill(null),spells:Array(5).fill(null),steps:[],summons:0,normalUsed:false,finished:false}}
function freshDeck(){return {id:`deck-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,name:'New Deck',main:[],extra:[],side:[]}}
function load(k){try{return JSON.parse(localStorage.getItem(k))}catch{return null}}
function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function clone(v){return JSON.parse(JSON.stringify(v))}
function isExtra(c){return /Fusion|Synchro|XYZ|Xyz|Link/.test(c.type||'')}
function img(c){const id=String(c?.id||'').replace(/\D/g,'');if(id)return `https://images.ygoprodeck.com/images/cards/${id}.jpg`;return (c?.card_images?.[0]?.image_url||'').replace(/^http:/,'https:')}
function cardKey(c){return String(c.id||c.name)}
function persistDeck(){state.deck.name=$('#deckName')?.value.trim()||state.deck.name||'My Deck';const i=state.decks.findIndex(d=>d.id===state.deck.id);if(i>=0)state.decks[i]=clone(state.deck);else state.decks.push(clone(state.deck));save('cfg_decks',state.decks);save('cfg_deck',state.deck)}
function openDeck(id){persistDeck();const selected=state.decks.find(d=>d.id===id);if(!selected)return;state.deck=clone(selected);state.combo=freshCombo();save('cfg_deck',state.deck);save('cfg_combo',state.combo);renderDeck();renderCombo()}
function addTo(section,c){
  if(section==='main' && isExtra(c)) section='extra';
  if(section==='extra' && !isExtra(c)) return alert('That card belongs in the Main Deck, not the Extra Deck.');
  const total=['main','extra','side'].flatMap(s=>state.deck[s]).filter(x=>cardKey(x.card)===cardKey(c)).reduce((n,x)=>n+x.qty,0);
  if(total>=3) return alert('Maximum 3 total copies across Main, Extra, and Side Deck.');
  const arr=state.deck[section], found=arr.find(x=>cardKey(x.card)===cardKey(c));
  if(found) found.qty++; else arr.push({card:clone(c),qty:1,order:arr.length});
  persistDeck(); renderDeck();
}
function removeFrom(section,c){const arr=state.deck[section],i=arr.findIndex(x=>cardKey(x.card)===cardKey(c)); if(i<0)return; if(arr[i].qty>1)arr[i].qty--;else arr.splice(i,1); persistDeck(); renderDeck()}
function sortDeck(section,mode){const arr=state.deck[section]; const rank=c=>/Monster/.test(c.type)?0:/Spell/.test(c.type)?1:2; const ex=c=>/Fusion/.test(c.type)?0:/Synchro/.test(c.type)?1:/XYZ|Xyz/.test(c.type)?2:/Link/.test(c.type)?3:4; arr.sort((a,b)=>{const A=a.card,B=b.card; if(mode==='alpha')return A.name.localeCompare(B.name); if(mode==='type')return (section==='extra'?ex(A)-ex(B):rank(A)-rank(B))||A.name.localeCompare(B.name); if(mode==='level')return ((A.level||A.linkval||0)-(B.level||B.linkval||0))||A.name.localeCompare(B.name); if(mode==='atk')return (B.atk||0)-(A.atk||0); return 0}); persistDeck(); renderDeck()}
function deckCount(section){return state.deck[section].reduce((n,x)=>n+x.qty,0)}
function cardMarkup(c, section, qty=1){return `<div class="card" data-card='${encodeURIComponent(JSON.stringify(c))}'><span class="qty">${qty}</span><img src="${img(c)}" alt="${c.name}" referrerpolicy="no-referrer"><div class="card-name">${c.name}</div>${section?`<div class="card-actions"><button data-add="${section}">+</button><button data-remove="${section}">−</button></div>`:''}</div>`}
function renderDeck(){
  $('#deckName').value=state.deck.name;
  $('#deckPicker').innerHTML=state.decks.map(d=>`<option value="${d.id}" ${d.id===state.deck.id?'selected':''}>${d.name}</option>`).join('')||`<option value="${state.deck.id}">${state.deck.name}</option>`;
  const configs=[['main','Main Deck',60],['extra','Extra Deck',15],['side','Side Deck',15]];
  $('#deckSections').innerHTML=configs.map(([key,label,max])=>`<div class="panel deck-section"><div class="deck-section-header"><h3>${label} ${deckCount(key)} / ${max}</h3><select data-sort="${key}" style="width:auto"><option value="">Sort…</option><option value="type">Card Type</option><option value="alpha">Alphabetical</option><option value="level">Level / Rank / Link</option><option value="atk">ATK</option></select></div><div class="card-grid">${state.deck[key].map(x=>cardMarkup(x.card,key,x.qty)).join('')||'<span class="muted tiny">No cards yet.</span>'}</div></div>`).join('');
  $$('[data-sort]').forEach(s=>s.onchange=e=>{if(e.target.value)sortDeck(e.target.dataset.sort,e.target.value)});
  $('#deckSections').onclick=e=>{const btn=e.target.closest('button'); if(!btn)return; const wrap=btn.closest('.card'); const c=JSON.parse(decodeURIComponent(wrap.dataset.card)); if(btn.dataset.add)addTo(btn.dataset.add,c); if(btn.dataset.remove)removeFrom(btn.dataset.remove,c)};
  $('#deckPicker').onchange=e=>openDeck(e.target.value);
  renderStarterPicker();
}
async function searchCards(){
  const q=$('#cardSearch').value.trim(); if(!q)return;
  $('#searchStatus').textContent='Searching…';
  try{
    const r=await fetch(`https://db.ygoprodeck.com/api/v7/cardinfo.php?fname=${encodeURIComponent(q)}`); const d=await r.json(); renderSearch((d.data||[]).slice(0,30)); $('#searchStatus').textContent=`${(d.data||[]).length} match(es)`;
  }catch(err){const matches=fallbackCards.filter(c=>c.name.toLowerCase().includes(q.toLowerCase())); renderSearch(matches); $('#searchStatus').textContent='Offline fallback results';}
}
function renderSearch(cards){$('#searchResults').innerHTML=cards.map(c=>`<div class="card" data-card='${encodeURIComponent(JSON.stringify(c))}'><img src="${img(c)}" alt="${c.name}"><div class="card-name">${c.name}</div><div class="card-actions"><button data-target="${isExtra(c)?'extra':'main'}">+ ${isExtra(c)?'Extra':'Main'}</button><button data-target="side">+ Side</button></div></div>`).join(''); $('#searchResults').onclick=e=>{const b=e.target.closest('button'); if(!b)return; const c=JSON.parse(decodeURIComponent(b.closest('.card').dataset.card)); addTo(b.dataset.target,c)}}
function expanded(section){return state.deck[section].flatMap(x=>Array.from({length:x.qty},()=>clone(x.card)))}
function renderStarterPicker(){const cards=expanded('main'); $('#starterPicker').innerHTML=cards.map(c=>`<div class="card" data-starter='${encodeURIComponent(JSON.stringify(c))}'><img src="${img(c)}" alt="${c.name}"><div class="card-name">${c.name}</div></div>`).join('')||'<span class="muted tiny">Add cards to your Main Deck first.</span>'; $('#starterPicker').onclick=e=>{const el=e.target.closest('[data-starter]'); if(!el||state.combo.starting.length>=5)return; const c=JSON.parse(decodeURIComponent(el.dataset.starter)); const available=cards.filter(x=>cardKey(x)===cardKey(c)).length; const chosen=state.combo.starting.filter(x=>cardKey(x)===cardKey(c)).length; if(chosen>=available)return; state.combo.starting.push(c); renderStartingHand()}}
function renderStartingHand(){const h=state.combo.starting; $('#handCount').textContent=`${h.length} / 5`; $('#startingHand').innerHTML=Array.from({length:5},(_,i)=>{const c=h[i]; return `<div class="hand-slot" data-index="${i}">${c?(c.any?'<span>Any Card</span>':`<img src="${img(c)}" alt="${c.name}">`):'<span>Empty</span>'}</div>`}).join(''); $('#startingHand').onclick=e=>{const slot=e.target.closest('.hand-slot'); const i=+slot.dataset.index; if(i<h.length){h.splice(i,1);renderStartingHand()}}}
function startCombo(){if(state.combo.starting.length!==5)return alert('Starting hand must contain 5 cards. Use “Fill Any” for unknown/non-engine cards.'); const main=expanded('main'), extra=expanded('extra'); const exact=state.combo.starting.filter(c=>!c.any); for(const c of exact){const i=main.findIndex(x=>cardKey(x)===cardKey(c)); if(i>=0)main.splice(i,1)} state.combo={...freshCombo(),name:$('#comboName').value||'New Combo',starting:clone(state.combo.starting),started:true,hand:clone(state.combo.starting),deck:main,extra}; save('cfg_combo',state.combo); renderCombo()}
function recordStep(title,card=null,note='',kind='manual'){state.combo.steps.push({title,card:card?clone(card):null,note,kind,snapshot:clone({...state.combo,steps:undefined})}); save('cfg_combo',state.combo); renderCombo()}
function summonFromHand(c){
  if(!c||c.any)return;
  const lvl=c.level||0;
  if(lvl>=5)return alert(`THIS STEP DOESN'T WORK\n${c.name} is Level ${lvl} and this MVP requires Tribute Summon handling for Level 5+ Normal Summons.`);
  if(state.combo.normalUsed)return alert('THIS STEP DOESN\'T WORK\nYou already used your Normal Summon this turn.');
  const z=state.combo.field.findIndex(x=>!x); if(z<0)return alert('No open Monster Zone.');
  state.combo.hand.splice(state.combo.hand.findIndex(x=>cardKey(x)===cardKey(c)),1); state.combo.field[z]=c; state.combo.normalUsed=true; state.combo.summons++; recordStep(`Normal Summon ${c.name}`,c,'Validated by basic summon rules.','validated');
}
function sendCostSelfSummonRule(c){
  const text=(c?.desc||'').replace(/[“”]/g,'"').replace(/\s+/g,' ');
  const match=text.match(/send 1 other "([^"]+)" card from your hand or face-up field to the GY;\s*Special Summon this card/i);
  return match?{archetype:match[1],text}:null;
}
function specialFromHand(c){
  if(!c||c.any)return;
  const rule=sendCostSelfSummonRule(c);
  if(!rule)return manualSpecialFromHand(c);
  const summonIndex=state.combo.hand.findIndex(x=>x===c||cardKey(x)===cardKey(c));
  const eligible=[];
  state.combo.hand.forEach((card,index)=>{if(index!==summonIndex&&!card.any&&(card.name||'').toLowerCase().includes(rule.archetype.toLowerCase()))eligible.push({card,zone:'hand',index,label:'Hand'})});
  state.combo.field.forEach((card,index)=>{if(card&&(card.name||'').toLowerCase().includes(rule.archetype.toLowerCase()))eligible.push({card,zone:'field',index,label:`Field M${index+1}`})});
  if(!eligible.length)return alert(`THIS STEP DOESN'T WORK\n${c.name} must send 1 other “${rule.archetype}” card from your hand or face-up field to the GY as cost.`);
  if(state.combo.field.every(Boolean)&&!eligible.some(x=>x.zone==='field'))return alert('THIS STEP DOESN\'T WORK\nThere is no open Monster Zone for the Special Summon.');
  openSheet(`<h3>Pay ${c.name}'s cost</h3><p class="muted tiny">Choose 1 other “${rule.archetype}” card to send to the GY:</p><div class="sheet-buttons effect-picker">${eligible.map((x,i)=>`<button data-cost-card="${i}"><strong>${x.card.name}</strong><span>${x.label} · Send to GY as COST</span></button>`).join('')}</div>`);
  $$('[data-cost-card]').forEach(button=>button.onclick=()=>{
    const cost=eligible[+button.dataset.costCard];
    const liveSummonIndex=state.combo.hand.findIndex(x=>cardKey(x)===cardKey(c));
    if(liveSummonIndex<0)return;
    if(cost.zone==='hand'){
      let costIndex=cost.index;
      if(costIndex>liveSummonIndex)costIndex--;
      state.combo.hand.splice(liveSummonIndex,1);
      const paid=state.combo.hand.splice(costIndex,1)[0];
      if(!paid)return alert('The selected cost card is no longer in your hand.');
      state.combo.gy.push(paid);
    }else{
      const paid=state.combo.field[cost.index];
      if(!paid)return alert('The selected cost card is no longer on the field.');
      state.combo.field[cost.index]=null;
      state.combo.gy.push(paid);
      state.combo.hand.splice(liveSummonIndex,1);
    }
    const z=state.combo.field.findIndex(x=>!x);
    if(z<0)return alert('No open Monster Zone.');
    state.combo.field[z]=c;
    state.combo.summons++;
    closeSheet();
    recordStep(`Send ${cost.card.name} to GY as cost → Special Summon ${c.name}`,c,`VALIDATED COST: Sent ${cost.card.name} from ${cost.label}. EFFECT: Special Summoned ${c.name}.`,'validated');
  });
}
function manualSpecialFromHand(c){const z=state.combo.field.findIndex(x=>!x); if(z<0)return alert('No open Monster Zone.'); state.combo.hand.splice(state.combo.hand.findIndex(x=>cardKey(x)===cardKey(c)),1); state.combo.field[z]=c; state.combo.summons++; recordStep(`Special Summon ${c.name}`,c,'Manual/unvalidated special summon.','manual')}
function sendCard(c,from,to){const source=state.combo[from]; if(Array.isArray(source)){const i=source.findIndex(x=>x&&cardKey(x)===cardKey(c)); if(i>=0){if(['field','spells'].includes(from))source[i]=null;else source.splice(i,1)}} if(to==='gy')state.combo.gy.push(c); if(to==='banished')state.combo.banished.push(c); recordStep(`${to==='gy'?'Send':'Banish'} ${c.name} ${to==='gy'?'to GY':''}`,c,'Manual action.','manual')}
function showCardActions(c,zone){let buttons=[]; if(zone==='hand'){buttons=[['Normal Summon',()=>summonFromHand(c)],['Special Summon',()=>specialFromHand(c)],['Activate / Resolve Effect',()=>manualEffect(c)],['Send to GY',()=>sendCard(c,'hand','gy')],['Banish',()=>sendCard(c,'hand','banished')]]} else if(zone==='field'){buttons=[['Activate Effect',()=>manualEffect(c)],['Send to GY',()=>sendCard(c,'field','gy')],['Banish',()=>sendCard(c,'field','banished')]]} else if(zone==='gy'){buttons=[['Activate Effect',()=>manualEffect(c)],['Special Summon',()=>manualMove(c,'gy','field',`Special Summon ${c.name} from GY`)],['Banish',()=>sendCard(c,'gy','banished')]]} else if(zone==='extra'){buttons=[['Summon from Extra Deck',()=>extraSummon(c)]]}
  openSheet(`<h3>${c.name}</h3><div class="sheet-buttons">${buttons.map((x,i)=>`<button data-sheet-action="${i}">${x[0]}</button>`).join('')}</div>`); $$('[data-sheet-action]').forEach(b=>b.onclick=()=>{closeSheet();buttons[+b.dataset.sheetAction][1]()})
}
function cardEffects(c){
  const raw=(c.desc||'').replace(/\r/g,'').trim();
  if(!raw)return [];
  let text=raw.replace(/\n+/g,' ');
  const pendulum=text.match(/\[ Pendulum Effect \](.*?)(?:\[ Monster Effect \]|$)/i);
  const monster=text.match(/\[ Monster Effect \](.*)$/i);
  if(pendulum||monster)text=[pendulum?.[1]&&`Pendulum Effect: ${pendulum[1].trim()}`,monster?.[1]&&`Monster Effect: ${monster[1].trim()}`].filter(Boolean).join(' ● ');
  const parts=text
    .split(/\s*●\s*|(?<=\.)\s+(?=(?:If|When|During|At the|Once per turn|You can|While|Each time|This card)[A-Z\s])/i)
    .map(x=>x.trim()).filter(Boolean);
  const restrictions=[];
  const effects=[];
  parts.forEach(part=>{
    if(/^(?:You can only use|You can only activate|You may only use|Once per turn, during the End Phase)/i.test(part))restrictions.push(part);
    else effects.push(part);
  });
  if(restrictions.length&&effects.length)effects[effects.length-1]+=` ${restrictions.join(' ')}`;
  return effects.length?effects:[raw];
}
function effectSummary(text){
  const core=(text.split(';').pop()||text).replace(/^(?:then|and if you do),?\s*/i,'').trim();
  return core.split(/\.(?:\s|$)/)[0].replace(/\.$/,'').slice(0,110);
}
function manualEffect(c){
  const effects=cardEffects(c);
  openSheet(`<h3>${c.name}</h3><p class="muted tiny">Choose the effect being used:</p><div class="sheet-buttons effect-picker">${effects.map((effect,i)=>`<button data-effect="${i}"><strong>Effect ${i+1}</strong><span>${effect}</span></button>`).join('')}<button id="customEffect"><strong>Custom / unsupported effect</strong><span>Type a manual description instead.</span></button></div>`);
  $$('[data-effect]').forEach(b=>b.onclick=()=>{const effect=effects[+b.dataset.effect];closeSheet();recordStep(`Activate ${c.name} — ${effectSummary(effect)}`,c,effect,'manual')});
  $('#customEffect').onclick=()=>{const text=prompt(`Describe what ${c.name}'s effect does in this combo:`,`Activate ${c.name}'s effect`);if(text){closeSheet();recordStep(text,c,'Manually entered — not rule validated.','manual')}};
}
function manualMove(c,from,to,title){const src=state.combo[from],i=src.findIndex(x=>x&&cardKey(x)===cardKey(c)); if(i>=0){if(['field','spells'].includes(from))src[i]=null; else src.splice(i,1)} if(to==='field'){const z=state.combo.field.findIndex(x=>!x); if(z<0)return alert('No open Monster Zone.');state.combo.field[z]=c;state.combo.summons++} recordStep(title,c,'Manual action.','manual')}
function extraSummon(c){const z=state.combo.field.findIndex(x=>!x); if(z<0)return alert('No open Monster Zone.'); const i=state.combo.extra.findIndex(x=>cardKey(x)===cardKey(c)); if(i<0)return; state.combo.extra.splice(i,1);state.combo.field[z]=c;state.combo.summons++;recordStep(`Summon ${c.name} from the Extra Deck`,c,'Manual/unvalidated material selection in MVP.','manual')}
function openManual(){openSheet(`<h3>Add Manual Action</h3><textarea id="manualText" rows="4" placeholder="Example: Search Elfnote card and add it to hand"></textarea><button id="saveManual" class="primary full">Add Step</button>`); $('#saveManual').onclick=()=>{const t=$('#manualText').value.trim();if(t){closeSheet();recordStep(t,null,'Manually entered — not rule validated.','manual')}}}
function undo(){if(!state.combo.steps.length)return; state.combo.steps.pop(); const snap=state.combo.steps.length?state.combo.steps[state.combo.steps.length-1].snapshot:{...freshCombo(),name:state.combo.name,starting:clone(state.combo.starting),started:true,hand:clone(state.combo.starting),deck:expanded('main'),extra:expanded('extra')}; const steps=clone(state.combo.steps); state.combo={...clone(snap),steps}; save('cfg_combo',state.combo);renderCombo()}
function renderCombo(){
  $('#comboName').value=state.combo.name; renderStartingHand(); $('#liveCombo').classList.toggle('hidden',!state.combo.started); $('#comboReview').classList.toggle('hidden',!state.combo.finished);
  if(!state.combo.started)return;
  $('#stepNum').textContent=state.combo.steps.length;$('#deckRemaining').textContent=state.combo.deck.length;$('#extraRemaining').textContent=state.combo.extra.length;$('#summonCount').textContent=state.combo.summons;$('#nibiruBanner').classList.toggle('hidden',state.combo.summons<5);
  $('#currentHand').innerHTML=state.combo.hand.map(c=>c.any?`<div class="hand-slot"><span>Any Card</span></div>`:`<div class="card" data-hand='${encodeURIComponent(JSON.stringify(c))}'><img src="${img(c)}"><div class="card-name">${c.name}</div></div>`).join(''); $('#currentHand').onclick=e=>{const el=e.target.closest('[data-hand]');if(el)showCardActions(JSON.parse(decodeURIComponent(el.dataset.hand)),'hand')};
  $('#fieldZones').innerHTML=state.combo.field.map((c,i)=>`<div class="zone" data-field="${i}">${c?`<img src="${img(c)}">`:`M${i+1}`}</div>`).join(''); $('#fieldZones').onclick=e=>{const z=e.target.closest('[data-field]'),c=state.combo.field[+z.dataset.field];if(c)showCardActions(c,'field')};
  $('#spellZones').innerHTML=state.combo.spells.map((c,i)=>`<div class="zone">${c?`<img src="${img(c)}">`:`S/T ${i+1}`}</div>`).join('');
  const zones=[['hand',`Hand ${state.combo.hand.length}`],['deck',`Deck ${state.combo.deck.length}`],['extra',`Extra ${state.combo.extra.length}`],['gy',`GY ${state.combo.gy.length}`],['banished',`Banished ${state.combo.banished.length}`]]; $('#zoneTabs').innerHTML=zones.map(([k,l])=>`<button data-zone="${k}" class="${state.currentZone===k?'active':''}">${l}</button>`).join(''); $('#zoneTabs').onclick=e=>{const b=e.target.closest('[data-zone]'); if(b){state.currentZone=b.dataset.zone;renderCombo()}}; const zoneArr=state.combo[state.currentZone]||[]; $('#zoneCards').innerHTML=zoneArr.filter(Boolean).map(c=>c.any?'<div class="hand-slot">Any Card</div>':`<div class="card" data-zone-card='${encodeURIComponent(JSON.stringify(c))}'><img src="${img(c)}"><div class="card-name">${c.name}</div></div>`).join('')||'<span class="muted tiny">No cards here.</span>'; $('#zoneCards').onclick=e=>{const el=e.target.closest('[data-zone-card]');if(el)showCardActions(JSON.parse(decodeURIComponent(el.dataset.zoneCard)),state.currentZone)};
  $('#comboSteps').innerHTML=state.combo.steps.map((s,i)=>`<div class="step"><div class="step-num">${i+1}</div>${s.card?`<img src="${img(s.card)}">`:'<div></div>'}<div><div class="step-title">${s.title}</div><div class="step-note">${s.kind==='validated'?'VALIDATED':'MANUAL / NOT RULE-VALIDATED'}${s.note?' · '+s.note:''}</div></div></div>`).join('')||'<span class="muted tiny">No steps yet.</span>';
  if(state.combo.finished)renderReview();
}
function renderReview(){
  $('#exportFlow').innerHTML=`<div class="export-head"><h2>${state.combo.name}</h2><div>Starting Hand</div><div class="export-starting-hand">${state.combo.starting.map(c=>c.any?'<div class="export-any">Any Card</div>':`<div class="export-hand-card"><img src="${img(c)}" referrerpolicy="no-referrer"><div>${c.name}</div></div>`).join('')}</div></div>`+state.combo.steps.map((s,i)=>`${i?'<div class="arrow">↓</div>':''}<div class="export-card-step">${s.card?`<img src="${img(s.card)}" referrerpolicy="no-referrer">`:''}<div><strong>Step ${i+1}</strong><div>${s.title}</div><small>${s.kind==='validated'?'Validated':'Manual / unvalidated'}</small></div></div>`).join('')+`<div class="arrow">↓</div><div class="export-card-step"><div><strong>End Board</strong><div>${state.combo.field.filter(Boolean).map(c=>c.name).join(' · ')||'No monsters'}</div><small>${state.combo.hand.length} cards remaining in hand · ${state.combo.summons} summons</small></div></div>`;
  $('#endBoard').innerHTML=`<div class="end-board-grid">${state.combo.field.map(c=>`<div class="zone">${c?`<img src="${img(c)}">`:''}</div>`).join('')}</div><p class="muted tiny">Hand: ${state.combo.hand.length} · GY: ${state.combo.gy.length} · Banished: ${state.combo.banished.length} · Extra remaining: ${state.combo.extra.length}</p>`;
}
function finishCombo(){state.combo.finished=true; save('cfg_combo',state.combo); const saved=load('cfg_saved_combos')||[]; saved.unshift({...clone(state.combo),id:Date.now()}); save('cfg_saved_combos',saved.slice(0,50));renderCombo();setTimeout(()=>$('#comboReview').scrollIntoView({behavior:'smooth'}),50)}
async function prepareNativeExportImages(node){if(!window.AndroidBridge?.imageAsDataUrl)return;for(const im of node.querySelectorAll('img')){if(!/^https:\/\/images\.ygoprodeck\.com\//i.test(im.src))continue;const data=window.AndroidBridge.imageAsDataUrl(im.src);if(data){im.src=data;await new Promise(resolve=>{if(im.complete)return resolve();im.onload=im.onerror=resolve})}}}
async function exportNode(node,filename){if(typeof html2canvas==='undefined')return alert('Image export library did not load.'); try{await prepareNativeExportImages(node);await Promise.all([...node.querySelectorAll('img')].map(im=>im.complete?Promise.resolve():new Promise(r=>{im.onload=im.onerror=r}))); const canvas=await html2canvas(node,{backgroundColor:'#f2f3f6',useCORS:true,scale:2,windowWidth:node.scrollWidth,windowHeight:node.scrollHeight}); const dataUrl=canvas.toDataURL('image/png'); if(window.AndroidBridge?.saveImage){window.AndroidBridge.saveImage(filename,dataUrl)}else{const a=document.createElement('a');a.download=filename;a.href=dataUrl;a.click()}}catch(e){alert('Export failed while preparing card images. The combo is still saved.') }}
function exportDeck(){const box=document.createElement('div');box.style.cssText='position:fixed;left:-9999px;top:0;width:1080px;background:#f3f4f7;color:#111;padding:40px;z-index:-1'; box.innerHTML=`<h1>${state.deck.name}</h1>${[['main','MAIN DECK'],['extra','EXTRA DECK'],['side','SIDE DECK']].map(([k,l])=>`<h2>${l} (${deckCount(k)})</h2><div style="display:grid;grid-template-columns:repeat(10,1fr);gap:8px">${state.deck[k].flatMap(x=>Array.from({length:x.qty},()=>`<img src="${img(x.card)}" referrerpolicy="no-referrer" style="width:92px">`)).join('')}</div>`).join('')}`; document.body.appendChild(box); exportNode(box,`${state.deck.name.replace(/\W+/g,'_')}_deck.png`).finally(()=>box.remove())}
function renderSaved(){const combos=load('cfg_saved_combos')||[];$('#savedContent').innerHTML=`<div class="panel deck-library"><h3>My Decks</h3><div class="deck-tiles">${state.decks.map(d=>{const cover=d.main[0]?.card||d.extra[0]?.card;return `<button class="deck-tile" data-load-deck="${d.id}">${cover?`<img src="${img(cover)}" referrerpolicy="no-referrer">`:'<div class="deck-cover-empty">＋</div>'}<strong>${d.name}</strong><span>${d.main.reduce((n,x)=>n+x.qty,0)} Main · ${d.extra.reduce((n,x)=>n+x.qty,0)} Extra · ${d.side.reduce((n,x)=>n+x.qty,0)} Side</span></button>`}).join('')||'<span class="muted tiny">No saved decks yet.</span>'}</div></div><div class="panel"><h3>Saved Combos</h3>${combos.map(c=>`<div class="saved-card"><div><strong>${c.name}</strong><div class="muted tiny">${c.steps.length} steps · ${c.summons} summons</div></div><button data-load-combo="${c.id}" class="ghost">Open</button></div>`).join('')||'<span class="muted tiny">No saved combos yet.</span>'}</div>`;$('#savedContent').onclick=e=>{const deckButton=e.target.closest('[data-load-deck]');if(deckButton){openDeck(deckButton.dataset.loadDeck);switchView('deckView');return}const b=e.target.closest('[data-load-combo]');if(b){const c=combos.find(x=>String(x.id)===b.dataset.loadCombo);if(c){state.combo=clone(c);save('cfg_combo',state.combo);switchView('comboView');renderCombo()}}}}
function openSheet(html){$('#sheetContent').innerHTML=html;$('#sheetBackdrop').classList.remove('hidden');$('#actionSheet').classList.remove('hidden')}
function closeSheet(){$('#sheetBackdrop').classList.add('hidden');$('#actionSheet').classList.add('hidden')}
function switchView(id){$$('.view').forEach(v=>v.classList.toggle('active',v.id===id));$$('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===id));if(id==='savedView')renderSaved()}

$('#searchBtn').onclick=searchCards;$('#cardSearch').onkeydown=e=>{if(e.key==='Enter')searchCards()};$('#saveDeckBtn').onclick=()=>{state.deck.name=$('#deckName').value.trim()||'My Deck';save('cfg_deck',state.deck);alert('Deck saved locally.');renderDeck()};$('#newDeckBtn').onclick=()=>{if(confirm('Start a new deck?')){state.deck={name:'My Deck',main:[],extra:[],side:[]};save('cfg_deck',state.deck);renderDeck()}};$('#fillAnyBtn').onclick=()=>{while(state.combo.starting.length<5)state.combo.starting.push({id:`any-${state.combo.starting.length}`,name:'Any Card',any:true});renderStartingHand()};$('#startComboBtn').onclick=startCombo;$('#resetComboBtn').onclick=()=>{if(confirm('Reset current combo?')){state.combo=freshCombo();save('cfg_combo',state.combo);renderCombo()}};$('#addManualBtn').onclick=openManual;$('#undoBtn').onclick=undo;$('#finishComboBtn').onclick=finishCombo;$('#exportComboBtn').onclick=()=>exportNode($('#exportFlow'),`${state.combo.name.replace(/\W+/g,'_')}_combo.png`);$('#exportDeckBtn').onclick=exportDeck;$('#sheetBackdrop').onclick=closeSheet;$$('.bottom-nav button').forEach(b=>b.onclick=()=>switchView(b.dataset.view));
// Override the legacy single-deck handlers with the multi-deck library behavior.
$('#saveDeckBtn').onclick=()=>{persistDeck();alert('Deck saved locally.');renderDeck()};
$('#newDeckBtn').onclick=()=>{persistDeck();state.deck=freshDeck();state.combo=freshCombo();save('cfg_deck',state.deck);save('cfg_combo',state.combo);renderDeck();renderCombo()};
renderDeck();renderStartingHand();renderCombo();
