
(function () {
  var A = document.getElementById('app');

  function fail(msg) {
    if (!A) { return; }
    A.innerHTML =
      '<div style="height:100%;display:grid;place-items:center;padding:8vw;text-align:center;color:white;font-family:Arial,sans-serif">' +
      '<div><div style="font-size:5vh;font-weight:800;letter-spacing:.2em">COMBO FORGE</div>' +
      '<p style="color:#ff9aa8">Client boot error</p>' +
      '<pre style="white-space:pre-wrap;text-align:left;max-width:80vw">' + String(msg) + '</pre>' +
      '<button id="resetBtn" style="padding:12px 20px">RESET LOCAL DATA</button></div></div>';
    var b = document.getElementById('resetBtn');
    if (b) {
      b.onclick = function () {
        try { localStorage.clear(); } catch (e) {}
        location.reload();
      };
    }
  }

  window.onerror = function (message, source, lineno, colno) {
    fail(String(message) + '\n' + String(source || '') + ':' + String(lineno || 0) + ':' + String(colno || 0));
    return true;
  };

  try {
    // Paint something immediately. If this appears, external JS is executing.
    A.innerHTML =
      '<div class="screen home">' +
        '<div class="brand">' +
          '<div class="brandmark">CF</div>' +
          '<h1>COMBO FORGE</h1>' +
          '<div class="home-menu">' +
            '<button id="comboBtn">COMBO LAB</button>' +
            '<button id="deckBtn">DECK MANAGER</button>' +
            '<button id="settingsBtn">SETTINGS</button>' +
          '</div>' +
        '</div>' +
        '<div class="version" id="versionText">v5.3 · client online</div>' +
      '</div>';
  } catch (e) {
    fail(e && e.message ? e.message : e);
    return;
  }

  var state = {
    screen: 'home',
    decks: [],
    active: null,
    engine: 'checking'
  };

  try {
    var raw = localStorage.getItem('cf53_decks');
    if (raw) {
      var parsed = JSON.parse(raw);
      if (Object.prototype.toString.call(parsed) === '[object Array]') {
        state.decks = parsed;
      }
    }
  } catch (e) {
    try { localStorage.removeItem('cf53_decks'); } catch (_) {}
  }

  function save() {
    try { localStorage.setItem('cf53_decks', JSON.stringify(state.decks)); } catch (e) {}
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function bridge(name) {
    try {
      if (!window.AndroidBridge) { return 'UNAVAILABLE'; }
      var fn = window.AndroidBridge[name];
      if (typeof fn !== 'function') { return 'UNAVAILABLE'; }
      return fn.call(window.AndroidBridge);
    } catch (e) {
      return 'FAIL|' + String(e && e.message ? e.message : e);
    }
  }

  function top(title, back) {
    return '<div class="topbar">' +
      '<button class="iconbtn" data-go="' + (back || 'home') + '">✕</button>' +
      '<button class="iconbtn" data-go="home">⌂</button>' +
      '<div class="title">' + esc(title) + '</div>' +
      '<button class="iconbtn" data-go="settings">⚙</button>' +
      '</div>';
  }

  function bindNav() {
    var nodes = document.querySelectorAll('[data-go]');
    var i;
    for (i = 0; i < nodes.length; i++) {
      nodes[i].onclick = function () {
        state.screen = this.getAttribute('data-go');
        render();
      };
    }
  }

  function renderHome() {
    A.innerHTML =
      '<div class="screen home"><div class="brand">' +
      '<div class="brandmark">CF</div><h1>COMBO FORGE</h1>' +
      '<div class="home-menu">' +
      '<button id="comboBtn">COMBO LAB</button>' +
      '<button id="deckBtn">DECK MANAGER</button>' +
      '<button id="settingsBtn">SETTINGS</button>' +
      '</div></div>' +
      '<div class="version">v5.3 · Engine ' + esc(state.engine) + '</div></div>';

    document.getElementById('comboBtn').onclick = function () { state.screen = 'duel'; render(); };
    document.getElementById('deckBtn').onclick = function () { state.screen = 'manager'; render(); };
    document.getElementById('settingsBtn').onclick = function () { state.screen = 'settings'; render(); };
  }

  function renderManager() {
    var tiles = '';
    var i, d;
    for (i = 0; i < state.decks.length; i++) {
      d = state.decks[i];
      tiles += '<div class="decktile" data-deck="' + i + '">' +
        '<div style="height:18vh;display:grid;place-items:center;background:#151c35;font-size:3vh">CF</div>' +
        '<div>' + esc(d.name) + '</div></div>';
    }

    A.innerHTML =
      '<div class="screen">' + top('DECK MANAGER', 'home') +
      '<div class="manager"><div class="deckgrid">' + tiles + '</div>' +
      '<div class="sidepanel"><button class="action" id="newDeckBtn">CREATE DECK</button>' +
      '<p style="color:var(--muted);font-size:1.4vh">Fresh local deck storage.</p></div></div></div>';

    bindNav();
    document.getElementById('newDeckBtn').onclick = function () {
      state.decks.push({ name: 'Deck ' + (state.decks.length + 1), main: [], extra: [], side: [] });
      state.active = state.decks.length - 1;
      save();
      state.screen = 'editor';
      render();
    };

    var cards = document.querySelectorAll('[data-deck]');
    for (i = 0; i < cards.length; i++) {
      cards[i].onclick = function () {
        state.active = parseInt(this.getAttribute('data-deck'), 10);
        state.screen = 'editor';
        render();
      };
    }
  }

  function renderEditor() {
    var d = state.decks[state.active];
    if (!d) {
      state.screen = 'manager';
      render();
      return;
    }
    A.innerHTML =
      '<div class="screen">' + top('DECK EDITOR', 'manager') +
      '<div style="padding:3vh 4vw">' +
      '<input class="search" id="deckName" value="' + esc(d.name) + '">' +
      '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1vw;margin-top:2vh">' +
      '<div class="zonebox"><div class="zonehead">MAIN</div><div style="padding:2vh;color:var(--muted)">Card database loads after the client shell is stable.</div></div>' +
      '<div class="zonebox"><div class="zonehead">EXTRA</div></div>' +
      '<div class="zonebox"><div class="zonehead">SIDE</div></div>' +
      '</div></div></div>';
    bindNav();
    document.getElementById('deckName').onchange = function () {
      d.name = this.value || d.name;
      save();
    };
  }

  function slots(label) {
    var out = '', i;
    for (i = 0; i < 7; i++) {
      out += '<div class="slot">' + label + ' ' + (i + 1) + '</div>';
    }
    return out;
  }

  function renderDuel() {
    A.innerHTML =
      '<div class="screen">' + top('COMBO LAB', 'home') +
      '<div class="duel">' +
        '<div class="field">' +
          '<div class="half"><div class="row">' + slots('OPP ST') + '</div><div class="row">' + slots('OPP MON') + '</div></div>' +
          '<div class="half"><div class="row">' + slots('MON') + '</div><div class="row">' + slots('ST') + '</div></div>' +
        '</div>' +
        '<div class="hud"><h3>CORE DUEL</h3>' +
          '<span class="badge">Engine ' + esc(state.engine) + '</span>' +
          '<button class="action" id="checkEngineBtn">CHECK ENGINE</button>' +
          '<div class="status" id="coreStatus">UI shell is running. Native engine is isolated from startup.</div>' +
        '</div>' +
      '</div></div>';
    bindNav();
    document.getElementById('checkEngineBtn').onclick = function () {
      document.getElementById('coreStatus').textContent = bridge('engineVersion');
    };
  }

  function renderSettings() {
    A.innerHTML =
      '<div class="screen">' + top('SETTINGS', 'home') +
      '<div style="padding:4vh 5vw"><h2>Combo Forge v5.3</h2>' +
      '<p>Landscape client shell.</p><p>Engine: <b>' + esc(state.engine) + '</b></p>' +
      '<button class="action" id="resetData">RESET LOCAL DATA</button></div></div>';
    bindNav();
    document.getElementById('resetData').onclick = function () {
      try { localStorage.clear(); } catch (e) {}
      location.reload();
    };
  }

  function render() {
    if (state.screen === 'home') { renderHome(); }
    else if (state.screen === 'manager') { renderManager(); }
    else if (state.screen === 'editor') { renderEditor(); }
    else if (state.screen === 'duel') { renderDuel(); }
    else { renderSettings(); }
  }

  // Do not touch native code until after the UI is already visible.
  setTimeout(function () {
    state.engine = bridge('engineVersion');
    if (!state.engine || state.engine === 'UNAVAILABLE' || String(state.engine).indexOf('FAIL|') === 0) {
      state.engine = 'offline';
    }
    render();
  }, 800);
})();
