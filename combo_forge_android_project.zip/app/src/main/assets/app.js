const A=document.getElementById('app');
function safeDeckLoad(){
  try{
    const raw=localStorage.getItem('cf5_decks');
    if(!raw) return [];
    const value=JSON.parse(raw);
    return Array.isArray(value)?value:[];
  }catch(e){
    try{ localStorage.removeItem('cf5_decks'); }catch(_){}
    return [];
  }
}
const state={screen:'home',cards:[],loaded:false,decks:safeDeckLoad(),active:null,preview:null,engine:'unknown'};
window.addEventListener('error',ev=>{
  if(!A) return;
  A.innerHTML=`<div style="height:100%;display:grid;place-items:center;padding:8vw;text-align:center;color:white"><div><h1>COMBO FORGE</h1><p>UI startup error</p><pre style="white-space:pre-wrap;color:#ff9aa8">${String(ev.message||'Unknown JavaScript error')}</pre><button onclick="localStorage.clear();location.reload()" style="padding:12px 20px">RESET LOCAL DATA</button></div></div>`;
});
const img=id=>`https://images.ygoprodeck.com/images/cards/${id}.jpg`;
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function bridge(name){
  try{
    if(!window.AndroidBridge || typeof window.AndroidBridge[name] !== 'function') return 'UNAVAILABLE';
    var args=Array.prototype.slice.call(arguments,1);
    return window.AndroidBridge[name].apply(window.AndroidBridge,args);
  }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e)}
}
function top(title,back='home'){return `<div class="topbar"><button class="iconbtn" onclick="go('${back}')">✕</button><button class="iconbtn" onclick="go('home')">⌂</button><div class="title">${title}</div><button class="iconbtn" onclick="go('settings')">⚙</button></div>`}
function go(s){state.screen=s;render()}
function save(){localStorage.setItem('cf5_decks',JSON.stringify(state.decks))}
async function loadCards(){if(state.loaded)return;try{const t=await fetch('engine/db/cards.tsv').then(r=>r.text());state.cards=t.split('\n').filter(x=>x&&!x.startsWith('#')).map(line=>{const p=line.split('\t');return{id:+p[0],alias:+p[1],setcode:+p[2],type:+p[3],atk:+p[4],def:+p[5],level:(+p[6]&255),race:+p[7],attribute:+p[8],name:(p[9]||'').replace(/\\t/g,'\t').replace(/\\n/g,'\n').replace(/\\\\/g,'\\'),desc:(p[10]||'').replace(/\\t/g,'\t').replace(/\\n/g,'\n').replace(/\\\\/g,'\\')}});state.loaded=true;render()}catch(e){console.error(e)}}
function home(){return `<div class="screen home"><div class="brand"><div class="brandmark">CF</div><h1>COMBO FORGE</h1><div class="home-menu"><button onclick="go('duel')">COMBO LAB</button><button onclick="go('manager')">DECK MANAGER</button><button onclick="go('settings')">SETTINGS</button></div></div><div class="version">Fresh rebuild · Engine ${esc(state.engine)}</div></div>`}
function manager(){const decks=state.decks.map((d,i)=>`<div class="decktile" onclick="editDeck(${i})"><img src="${d.cover?img(d.cover):''}" onerror="this.removeAttribute('src')"><div>${esc(d.name)}</div></div>`).join('');return `<div class="screen">${top('DECK MANAGER')}<div class="manager"><div class="deckgrid">${decks}</div><div class="sidepanel"><input class="search" placeholder="Search decks" oninput="filterDeckTiles(this.value)"><p style="color:var(--muted);font-size:1.4vh">Decks are saved locally on this device.</p></div></div><div class="bottom-actions"><button class="action" onclick="newDeck()">CREATE</button><button class="action" onclick="alert('YDK import is next')">IMPORT</button><button class="action" onclick="alert('YDK export is next')">EXPORT</button></div></div>`}
function filterDeckTiles(v){document.querySelectorAll('.decktile').forEach(x=>x.style.display=x.innerText.toLowerCase().includes(v.toLowerCase())?'':'none')}
function newDeck(){const d={name:`Deck ${state.decks.length+1}`,main:[],extra:[],side:[],cover:0};state.decks.push(d);state.active=state.decks.length-1;save();go('editor')}
function editDeck(i){state.active=i;go('editor')}
function selectedDeck(){if(state.active==null||!state.decks[state.active])return null;return state.decks[state.active]}
function zone(name,list){return `<div class="zonebox"><div class="zonehead">${name}<span style="margin-left:auto">${list.length}</span></div><div class="zonecards">${list.map((id,i)=>`<img class="mini" src="${img(id)}" onclick="previewCard(${id})" ondblclick="removeCard('${name.toLowerCase()}',${i})">`).join('')}</div></div>`}
function editor(){const d=selectedDeck();if(!d){setTimeout(()=>go('manager'));return ''}const c=state.preview||state.cards.find(x=>x.id===d.cover);return `<div class="screen">${top('DECK EDITOR','manager')}<div class="editor"><div class="preview"><input class="search" value="${esc(d.name)}" onchange="renameDeck(this.value)">${c?`<h3>${esc(c.name)}</h3><img src="${img(c.id)}"><p>${esc(c.desc)}</p>`:`<div style="height:60vh;display:grid;place-items:center;color:var(--muted)">Select a card</div>`}</div><div class="decks">${zone('MAIN',d.main)}${zone('EXTRA',d.extra)}${zone('SIDE',d.side)}</div><div class="searchpanel"><input class="search" id="q" placeholder="Search cards" oninput="searchCards()"><div class="filters"><select id="kind" onchange="searchCards()"><option value="">Card Type</option><option value="monster">Monster</option><option value="spell">Spell</option><option value="trap">Trap</option></select><select id="sort" onchange="searchCards()"><option value="name">Name</option><option value="atk">ATK</option><option value="level">Level/Rank</option></select><input id="atk" type="number" placeholder="Min ATK" oninput="searchCards()"><input id="lvl" type="number" placeholder="Level/Rank" oninput="searchCards()"></div><div class="results" id="results"></div></div></div></div>`}
function renameDeck(v){const d=selectedDeck();d.name=v||d.name;save()}
function previewCard(id){state.preview=state.cards.find(x=>x.id===id);render()}
function cardKind(c){if(c.type&1)return'monster';if(c.type&2)return'spell';if(c.type&4)return'trap';return''}
function isExtra(c){return !!(c.type&(0x40|0x2000|0x800000|0x4000000))}
function searchCards(){const q=(document.getElementById('q')?.value||'').toLowerCase(),kind=document.getElementById('kind')?.value||'',minAtk=+(document.getElementById('atk')?.value||-99999),lvl=+(document.getElementById('lvl')?.value||0),sort=document.getElementById('sort')?.value||'name';let a=state.cards.filter(c=>(!q||c.name.toLowerCase().includes(q))&&(!kind||cardKind(c)===kind)&&(c.atk>=minAtk)&&(!lvl||c.level===lvl)).slice(0,120);a.sort((x,y)=>sort==='atk'?y.atk-x.atk:sort==='level'?y.level-x.level:x.name.localeCompare(y.name));const r=document.getElementById('results');if(r)r.innerHTML=a.map(c=>`<div class="result" title="${esc(c.name)}"><img src="${img(c.id)}" onclick="previewCard(${c.id})" ondblclick="addCard(${c.id})"><span>${c.atk>=0?c.atk:''}</span></div>`).join('')}
function addCard(id){const d=selectedDeck(),c=state.cards.find(x=>x.id===id);if(!d||!c)return;const z=isExtra(c)?d.extra:d.main;if(z.length<(isExtra(c)?15:60))z.push(id);if(!d.cover)d.cover=id;save();render();setTimeout(searchCards)}
function removeCard(zoneName,i){const d=selectedDeck();const key=zoneName==='main'?'main':zoneName==='extra'?'extra':'side';d[key].splice(i,1);save();render();setTimeout(searchCards)}
function duel(){const d=selectedDeck()||state.decks[0];return `<div class="screen">${top('COMBO LAB')}<div class="duel"><div class="field"><div class="half"><div class="row">${slots('OPP ST',7)}</div><div class="row">${slots('OPP MON',7)}</div></div><div class="half"><div class="row">${slots('MON',7)}</div><div class="row">${slots('ST',7)}</div></div><div class="hand" id="hand"></div></div><div class="hud"><h3>CORE DUEL</h3><span class="badge">OCGCORE ${esc(state.engine)}</span><button class="action" onclick="startCore()">START CORE SESSION</button><button class="action" onclick="processCore()">PROCESS</button><button class="action" onclick="seedActiveDeck()">SEED ACTIVE DECK</button><div class="status" id="coreStatus">Fresh engine transport. Protocol decoder is the next layer.</div></div></div></div>`}
function slots(t,n){return Array.from({length:n},(_,i)=>`<div class="slot">${t} ${i+1}</div>`).join('')}
function setStatus(s){const e=document.getElementById('coreStatus');if(e)e.textContent=s}
function startCore(){setStatus(bridge('sessionCreate'))}
function seedActiveDeck(){const d=selectedDeck()||state.decks[0];if(!d)return setStatus('No deck selected.');let s=bridge('sessionCreate');if(!String(s).startsWith('PASS'))return setStatus(s);d.main.forEach((id,i)=>bridge('addCard',id,0,0,0x01,i,0x1));d.extra.forEach((id,i)=>bridge('addCard',id,0,0,0x40,i,0x1));setStatus(`Seeded ${d.main.length} Main / ${d.extra.length} Extra\n`+bridge('start'))}
function processCore(){setStatus(bridge('process'))}
function settings(){return `<div class="screen">${top('SETTINGS')}<div style="padding:4vh 5vw"><h2>Fresh rebuild</h2><p>Landscape-only Android client.</p><p>Engine: <b>${esc(state.engine)}</b></p><p>Authoritative data sources are Project Ignis CardScripts, BabelCDB and LFLists. EDOPro source is used as the open client protocol reference.</p></div></div>`}
function render(){A.innerHTML=state.screen==='home'?home():state.screen==='manager'?manager():state.screen==='editor'?editor():state.screen==='duel'?duel():settings();if(state.screen==='editor')setTimeout(searchCards)}
// Boot UI first. Native/core initialization must never block the home screen.
try {
  state.engine='initializing';
  render();
} catch(e) {
  if(A) A.innerHTML='<div style="height:100%;display:grid;place-items:center;color:white"><div><h1>COMBO FORGE</h1><p>Render failed</p><pre>'+esc(String(e))+'</pre></div></div>';
}
setTimeout(function(){
  try {
    var v=bridge('engineVersion');
    if(v && v!=='UNAVAILABLE' && String(v).indexOf('FAIL|')!==0) state.engine=String(v);
    else state.engine='offline';
    render();
  } catch(e) { state.engine='offline'; try{render()}catch(_){} }
},250);
setTimeout(function(){ loadCards(); },500);
