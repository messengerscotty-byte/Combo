
(function () {
  var A = document.getElementById('app');
  var DB = [];
  var DB_READY = false;
  var DB_LOADING = false;
  var DB_ERROR = '';
  var searchTimer = null;

  var TYPE = {
    MONSTER:1, SPELL:2, TRAP:4, NORMAL:16, EFFECT:32, FUSION:64, RITUAL:128,
    SPIRIT:512, UNION:1024, GEMINI:2048, TUNER:4096, SYNCHRO:8192,
    QUICKPLAY:65536, CONTINUOUS:131072, EQUIP:262144, FIELD:524288,
    COUNTER:1048576, FLIP:2097152, TOON:4194304, XYZ:8388608,
    PENDULUM:16777216, SPSUMMON:33554432, LINK:67108864
  };

  var ATTR = {1:'EARTH',2:'WATER',4:'FIRE',8:'WIND',16:'LIGHT',32:'DARK',64:'DIVINE'};
  var RACE = {
    1:'Warrior',2:'Spellcaster',4:'Fairy',8:'Fiend',16:'Zombie',32:'Machine',
    64:'Aqua',128:'Pyro',256:'Rock',512:'Winged Beast',1024:'Plant',2048:'Insect',
    4096:'Thunder',8192:'Dragon',16384:'Beast',32768:'Beast-Warrior',65536:'Dinosaur',
    131072:'Fish',262144:'Sea Serpent',524288:'Reptile',1048576:'Psychic',
    2097152:'Divine-Beast',4194304:'Creator God',8388608:'Wyrm',16777216:'Cyberse',
    33554432:'Illusion'
  };

  function fail(msg) {
    if (!A) return;
    A.innerHTML =
      '<div style="height:100%;display:grid;place-items:center;padding:8vw;text-align:center;color:white;font-family:Arial,sans-serif">' +
      '<div><div style="font-size:5vh;font-weight:800;letter-spacing:.2em">COMBO FORGE</div>' +
      '<p style="color:#ff9aa8">Client boot error</p><pre style="white-space:pre-wrap;text-align:left;max-width:80vw">' +
      esc(msg) + '</pre><button id="resetBtn" style="padding:12px 20px">RESET LOCAL DATA</button></div></div>';
    var b=document.getElementById('resetBtn');
    if(b)b.onclick=function(){try{localStorage.clear();}catch(e){} location.reload();};
  }

  window.onerror=function(message,source,line,col){
    fail(String(message)+'\n'+String(source||'')+':'+String(line||0)+':'+String(col||0));
    return true;
  };

  function esc(s){
    return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function bridge(name){
    try{
      if(!window.AndroidBridge)return 'UNAVAILABLE';
      var fn=window.AndroidBridge[name];
      if(typeof fn!=='function')return 'UNAVAILABLE';
      return fn.call(window.AndroidBridge);
    }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e);}
  }
  function img(code){return 'https://images.ygoprodeck.com/images/cards/'+code+'.jpg';}
  function has(v,b){return (v & b)!==0;}
  function isExtra(c){return has(c.type,TYPE.FUSION)||has(c.type,TYPE.SYNCHRO)||has(c.type,TYPE.XYZ)||has(c.type,TYPE.LINK);}
  function isMonster(c){return has(c.type,TYPE.MONSTER);}
  function typeLine(c){
    if(has(c.type,TYPE.SPELL)){
      if(has(c.type,TYPE.QUICKPLAY))return 'Quick-Play Spell';
      if(has(c.type,TYPE.FIELD))return 'Field Spell';
      if(has(c.type,TYPE.EQUIP))return 'Equip Spell';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Spell';
      return 'Spell';
    }
    if(has(c.type,TYPE.TRAP)){
      if(has(c.type,TYPE.COUNTER))return 'Counter Trap';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Trap';
      return 'Trap';
    }
    var a=[];
    if(has(c.type,TYPE.FUSION))a.push('Fusion');
    if(has(c.type,TYPE.SYNCHRO))a.push('Synchro');
    if(has(c.type,TYPE.XYZ))a.push('Xyz');
    if(has(c.type,TYPE.LINK))a.push('Link');
    if(has(c.type,TYPE.RITUAL))a.push('Ritual');
    if(has(c.type,TYPE.PENDULUM))a.push('Pendulum');
    if(has(c.type,TYPE.TUNER))a.push('Tuner');
    if(has(c.type,TYPE.FLIP))a.push('Flip');
    if(has(c.type,TYPE.NORMAL))a.push('Normal');
    else if(has(c.type,TYPE.EFFECT))a.push('Effect');
    return a.join(' / ')+' Monster';
  }

  var state={screen:'home',decks:[],active:null,engine:'checking',selected:null,editorQuery:'',
    dataUpdate:{checking:false,available:false,db:false,scripts:false,message:'Not checked'}};
  try{
    var raw=localStorage.getItem('cf54_decks') || localStorage.getItem('cf53_decks');
    if(raw){
      var parsed=JSON.parse(raw);
      if(Object.prototype.toString.call(parsed)==='[object Array]')state.decks=parsed;
    }
  }catch(e){try{localStorage.removeItem('cf54_decks');}catch(_){}}

  function save(){try{localStorage.setItem('cf54_decks',JSON.stringify(state.decks));}catch(e){}}
  function normalizeDeck(d){
    if(!d.main)d.main=[];
    if(!d.extra)d.extra=[];
    if(!d.side)d.side=[];
    return d;
  }

  function top(title,back){
    return '<div class="topbar"><button class="iconbtn" data-go="'+(back||'home')+'">✕</button>'+
      '<button class="iconbtn" data-go="home">⌂</button><div class="title">'+esc(title)+'</div>'+
      '<button class="iconbtn" data-go="settings">⚙</button></div>';
  }
  function bindNav(){
    var n=document.querySelectorAll('[data-go]'),i;
    for(i=0;i<n.length;i++)n[i].onclick=function(){state.screen=this.getAttribute('data-go');render();};
  }

  function renderHome(){
    A.innerHTML='<div class="screen home"><div class="brand"><div class="brandmark">CF</div>'+
      '<h1>COMBO FORGE</h1><div class="home-menu"><button id="comboBtn">COMBO LAB</button>'+
      '<button id="deckBtn">DECK MANAGER</button><button id="settingsBtn">SETTINGS</button></div></div>'+
      '<div class="version">v5.6 · Engine '+esc(state.engine)+'</div></div>';
    document.getElementById('comboBtn').onclick=function(){state.screen='duel';render();};
    document.getElementById('deckBtn').onclick=function(){state.screen='manager';render();};
    document.getElementById('settingsBtn').onclick=function(){state.screen='settings';render();};
  }

  function deckCover(d){
    var code=(d.main&&d.main[0])||(d.extra&&d.extra[0])||0;
    return code?'<img src="'+img(code)+'" onerror="this.style.visibility=\'hidden\'">':'<div class="emptycover">CF</div>';
  }

  function renderManager(){
    var tiles='',i,d;
    for(i=0;i<state.decks.length;i++){
      d=normalizeDeck(state.decks[i]);
      tiles+='<div class="decktile" data-deck="'+i+'">'+deckCover(d)+
        '<div class="deckname">'+esc(d.name||('Deck '+(i+1)))+'</div>'+
        '<div class="deckcounts">'+d.main.length+' / '+d.extra.length+' / '+d.side.length+'</div></div>';
    }
    A.innerHTML='<div class="screen">'+top('DECK MANAGER','home')+
      '<div class="manager"><div class="deckgrid">'+tiles+'</div><div class="sidepanel">'+
      '<button class="action full" id="newDeckBtn">CREATE DECK</button>'+
      '<button class="action full" id="dupDeckBtn">DUPLICATE SELECTED</button>'+
      '<button class="dangerbtn full" id="deleteDeckBtn">DELETE SELECTED</button>'+
      '<div class="managerhint">Tap a deck to open it.<br>Main / Extra / Side counts appear under each deck.</div>'+
      '</div></div></div>';
    bindNav();
    document.getElementById('newDeckBtn').onclick=function(){
      state.decks.push({name:'Deck '+(state.decks.length+1),main:[],extra:[],side:[]});
      state.active=state.decks.length-1; save(); state.screen='editor'; render();
    };
    var cards=document.querySelectorAll('[data-deck]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){
      state.active=parseInt(this.getAttribute('data-deck'),10);state.screen='editor';render();
    };
    document.getElementById('dupDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      var copy=JSON.parse(JSON.stringify(state.decks[state.active]));
      copy.name=(copy.name||'Deck')+' Copy';state.decks.push(copy);save();renderManager();
    };
    document.getElementById('deleteDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      state.decks.splice(state.active,1);state.active=null;save();renderManager();
    };
  }

  function loadDB(done){
    if(DB_READY){done();return;}
    if(DB_LOADING){setTimeout(function(){loadDB(done);},250);return;}
    DB_LOADING=true; DB_ERROR='';
    var assetText = '';
    try {
      if (window.AndroidBridge && typeof window.AndroidBridge.readAssetText === 'function') {
        assetText = window.AndroidBridge.readAssetText('engine/db/cards.tsv') || '';
      }
    } catch (e) {}
    var source = assetText
      ? Promise.resolve(assetText)
      : fetch('engine/db/cards.tsv').then(function(r){
          if(!r.ok)throw new Error('cards.tsv HTTP '+r.status);
          return r.text();
        });
    source.then(function(text){
      var lines=text.split('\n'),i,cols,cards=[];
      for(i=0;i<lines.length;i++){
        if(!lines[i]||lines[i].charAt(0)==='#')continue;
        cols=lines[i].split('\t');
        if(cols.length<11)continue;
        cards.push({
          id:parseInt(cols[0],10)||0,alias:parseInt(cols[1],10)||0,setcode:cols[2]||'0',
          type:parseInt(cols[3],10)||0,atk:parseInt(cols[4],10)||0,def:parseInt(cols[5],10)||0,
          level:parseInt(cols[6],10)||0,race:parseInt(cols[7],10)||0,attribute:parseInt(cols[8],10)||0,
          name:unescapeField(cols[9]),desc:unescapeField(cols.slice(10).join('\t'))
        });
      }
      DB=cards;DB_READY=true;DB_LOADING=false;done();
    }).catch(function(e){
      DB_ERROR=String(e&&e.message?e.message:e);DB_LOADING=false;done();
    });
  }

  function unescapeField(s){
    return String(s||'').replace(/\\n/g,'\n').replace(/\\t/g,'\t').replace(/\\\\/g,'\\');
  }
  function byId(id){
    var i;
    for(i=0;i<DB.length;i++)if(DB[i].id===id)return DB[i];
    return {id:id,name:'Card '+id,desc:'',type:0,atk:0,def:0,level:0,race:0,attribute:0};
  }
  function copies(d,id){
    var n=0,i,z,arrs=[d.main,d.extra,d.side];
    for(z=0;z<arrs.length;z++)for(i=0;i<arrs[z].length;i++)if(arrs[z][i]===id)n++;
    return n;
  }
  function addCardToDeck(d,c,zone){
    if(copies(d,c.id)>=3){toast('Maximum 3 copies');return false;}
    if(zone==='side'){
      if(d.side.length>=15){toast('Side Deck is full');return false;}
      d.side.push(c.id);
    }else if(isExtra(c)){
      if(d.extra.length>=15){toast('Extra Deck is full');return false;}
      d.extra.push(c.id);
    }else{
      if(d.main.length>=60){toast('Main Deck is full');return false;}
      d.main.push(c.id);
    }
    save();return true;
  }
  function removeOne(d,zone,index){
    if(d[zone]&&index>=0&&index<d[zone].length){d[zone].splice(index,1);save();}
  }
  function toast(msg){
    var old=document.getElementById('toast');if(old&&old.parentNode)old.parentNode.removeChild(old);
    var t=document.createElement('div');t.id='toast';t.className='toast';t.textContent=msg;
    document.body.appendChild(t);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},1400);
  }

  function cardHtml(id,zone,index){
    var c=byId(id);
    return '<div class="deckcard" data-card="'+id+'" data-zone="'+zone+'" data-index="'+index+'" title="'+esc(c.name)+'">'+
      '<img src="'+img(id)+'" onerror="this.className=\'imgfail\'"></div>';
  }
  function zoneCards(arr,zone){
    var out='',i;
    for(i=0;i<arr.length;i++)out+=cardHtml(arr[i],zone,i);
    return out;
  }
  function filterOptions(map){
    var out='<option value="">Any</option>',k;
    for(k in map)if(map.hasOwnProperty(k))out+='<option value="'+k+'">'+esc(map[k])+'</option>';
    return out;
  }
  function monsterKindOptions(){
    return '<option value="">Any monster</option><option value="normal">Normal</option><option value="effect">Effect</option>'+
      '<option value="ritual">Ritual</option><option value="fusion">Fusion</option><option value="synchro">Synchro</option>'+
      '<option value="xyz">Xyz</option><option value="link">Link</option><option value="pendulum">Pendulum</option>'+
      '<option value="tuner">Tuner</option>';
  }

  function renderEditor(){
    var d=state.decks[state.active];
    if(!d){state.screen='manager';render();return;}
    normalizeDeck(d);
    A.innerHTML='<div class="screen">'+top('DECK EDITOR','manager')+
      '<div class="editor">'+
        '<div class="preview" id="preview">'+previewHtml(state.selected?byId(state.selected):null,d)+'</div>'+
        '<div class="decks">'+
          '<div class="zonebox mainzone"><div class="zonehead"><span>MAIN</span><b>'+d.main.length+'</b></div><div class="zonecards" id="mainCards">'+zoneCards(d.main,'main')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>EXTRA</span><b>'+d.extra.length+'</b></div><div class="zonecards" id="extraCards">'+zoneCards(d.extra,'extra')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>SIDE</span><b>'+d.side.length+'</b></div><div class="zonecards" id="sideCards">'+zoneCards(d.side,'side')+'</div></div>'+
        '</div>'+
        '<div class="searchpanel">'+
          '<input class="search" id="q" placeholder="Search card name or text…" value="'+esc(state.editorQuery)+'">'+
          '<div class="filters">'+
            '<select id="cat"><option value="">All cards</option><option value="monster">Monster</option><option value="spell">Spell</option><option value="trap">Trap</option></select>'+
            '<select id="kind">'+monsterKindOptions()+'</select>'+
            '<select id="attr">'+filterOptions(ATTR)+'</select>'+
            '<select id="race">'+filterOptions(RACE)+'</select>'+
            '<input id="level" type="number" min="0" max="13" placeholder="Level / Rank">'+
            '<input id="atk" type="number" placeholder="ATK ≥">'+
            '<input id="def" type="number" placeholder="DEF ≥">'+
            '<select id="sort"><option value="name">Name A–Z</option><option value="atk">ATK high</option><option value="level">Level high</option></select>'+
          '</div>'+
          '<div class="filterbuttons"><button id="clearFilters">CLEAR</button><span id="dbStatus">'+(DB_READY?(DB.length+' cards'):(DB_ERROR?'DB error':'Loading card database…'))+'</span></div>'+
          '<div class="results" id="results"></div>'+
        '</div>'+
      '</div>'+
      '<div class="decktitlebar"><input id="deckName" value="'+esc(d.name||'Deck')+'"><span>Tap search result = add · Hold = Side · Double-tap deck card = remove</span></div>'+
      '</div>';
    bindNav();
    bindDeckCards(d);
    document.getElementById('deckName').onchange=function(){d.name=this.value||d.name;save();};
    bindSearch(d);
    loadDB(function(){
      if(state.screen==='editor'){
        var s=document.getElementById('dbStatus');
        if(s)s.textContent=DB_ERROR?('DB error: '+DB_ERROR):(DB.length+' cards');
        refreshResults(d);
        refreshPreview(d);
      }
    });
  }

  function previewHtml(c,d){
    if(!c)return '<div class="previewempty"><div>SELECT A CARD</div><small>Tap a card to view details.</small></div>';
    var stat='';
    if(isMonster(c)){
      stat='<div class="cardstats">'+(ATTR[c.attribute]||'')+' · '+(RACE[c.race]||'')+' · '+
        (has(c.type,TYPE.LINK)?('LINK-'+((c.level)&255)):('LV '+((c.level)&255)))+
        '<br>ATK '+c.atk+(has(c.type,TYPE.LINK)?'':(' / DEF '+c.def))+'</div>';
    }
    return '<img class="bigcard" src="'+img(c.id)+'"><h3>'+esc(c.name)+'</h3>'+
      '<div class="typeline">'+esc(typeLine(c))+'</div>'+stat+
      '<p>'+esc(c.desc).replace(/\n/g,'<br>')+'</p>'+
      '<div class="previewbuttons"><button id="addMain">ADD</button><button id="addSide">SIDE +</button><button id="removeCopy">REMOVE 1</button></div>'+
      '<div class="copies">Copies in deck: '+copies(d,c.id)+'</div>';
  }
  function refreshPreview(d){
    var p=document.getElementById('preview');if(!p)return;
    p.innerHTML=previewHtml(state.selected?byId(state.selected):null,d);
    bindPreviewButtons(d);
  }
  function bindPreviewButtons(d){
    var c=state.selected?byId(state.selected):null;if(!c)return;
    var a=document.getElementById('addMain'),s=document.getElementById('addSide'),r=document.getElementById('removeCopy');
    if(a)a.onclick=function(){if(addCardToDeck(d,c,'main'))renderEditor();};
    if(s)s.onclick=function(){if(addCardToDeck(d,c,'side'))renderEditor();};
    if(r)r.onclick=function(){
      var zones=['side','extra','main'],z,i;
      for(z=0;z<zones.length;z++){
        for(i=d[zones[z]].length-1;i>=0;i--)if(d[zones[z]][i]===c.id){d[zones[z]].splice(i,1);save();renderEditor();return;}
      }
    };
  }
  function bindDeckCards(d){
    var nodes=document.querySelectorAll('.deckcard'),i,timer;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){state.selected=parseInt(this.getAttribute('data-card'),10);refreshPreview(d);};
      nodes[i].ondblclick=function(){
        removeOne(d,this.getAttribute('data-zone'),parseInt(this.getAttribute('data-index'),10));renderEditor();
      };
    }
    bindPreviewButtons(d);
  }

  function kindMatch(c,k){
    if(!k)return true;
    if(k==='normal')return has(c.type,TYPE.NORMAL);
    if(k==='effect')return has(c.type,TYPE.EFFECT);
    if(k==='ritual')return has(c.type,TYPE.RITUAL);
    if(k==='fusion')return has(c.type,TYPE.FUSION);
    if(k==='synchro')return has(c.type,TYPE.SYNCHRO);
    if(k==='xyz')return has(c.type,TYPE.XYZ);
    if(k==='link')return has(c.type,TYPE.LINK);
    if(k==='pendulum')return has(c.type,TYPE.PENDULUM);
    if(k==='tuner')return has(c.type,TYPE.TUNER);
    return true;
  }

  function bindSearch(d){
    var ids=['q','cat','kind','attr','race','level','atk','def','sort'],i,el;
    for(i=0;i<ids.length;i++){
      el=document.getElementById(ids[i]);
      if(!el)continue;
      el.oninput=el.onchange=function(){
        if(this.id==='q')state.editorQuery=this.value;
        clearTimeout(searchTimer);searchTimer=setTimeout(function(){refreshResults(d);},120);
      };
    }
    document.getElementById('clearFilters').onclick=function(){
      for(i=0;i<ids.length;i++){el=document.getElementById(ids[i]);if(el)el.value=(ids[i]==='sort'?'name':'');}
      state.editorQuery='';refreshResults(d);
    };
  }

  function refreshResults(d){
    var box=document.getElementById('results');if(!box)return;
    if(!DB_READY){box.innerHTML='<div class="resultmsg">'+(DB_ERROR?esc(DB_ERROR):'Loading card database…')+'</div>';return;}
    var q=(document.getElementById('q').value||'').toLowerCase().trim();
    var cat=document.getElementById('cat').value,kind=document.getElementById('kind').value;
    var attr=parseInt(document.getElementById('attr').value,10)||0;
    var race=parseInt(document.getElementById('race').value,10)||0;
    var level=document.getElementById('level').value;
    var atk=document.getElementById('atk').value,def=document.getElementById('def').value;
    var sort=document.getElementById('sort').value;
    var out=[],i,c,lvl;
    for(i=0;i<DB.length;i++){
      c=DB[i];
      if(q && c.name.toLowerCase().indexOf(q)<0 && c.desc.toLowerCase().indexOf(q)<0)continue;
      if(cat==='monster'&&!has(c.type,TYPE.MONSTER))continue;
      if(cat==='spell'&&!has(c.type,TYPE.SPELL))continue;
      if(cat==='trap'&&!has(c.type,TYPE.TRAP))continue;
      if(kind&&!kindMatch(c,kind))continue;
      if(attr&&c.attribute!==attr)continue;
      if(race&&c.race!==race)continue;
      lvl=(c.level&255);
      if(level!==''&&lvl!==parseInt(level,10))continue;
      if(atk!==''&&c.atk<parseInt(atk,10))continue;
      if(def!==''&&c.def<parseInt(def,10))continue;
      out.push(c);
      if(out.length>600&&q==='')break;
    }
    if(sort==='atk')out.sort(function(a,b){return b.atk-a.atk;});
    else if(sort==='level')out.sort(function(a,b){return (b.level&255)-(a.level&255);});
    else out.sort(function(a,b){return a.name.localeCompare(b.name);});
    if(out.length>160)out=out.slice(0,160);
    var html='';
    for(i=0;i<out.length;i++){
      c=out[i];
      html+='<div class="result" data-result="'+c.id+'"><img loading="lazy" src="'+img(c.id)+'" onerror="this.className=\'imgfail\'">'+
        '<div class="resultname">'+esc(c.name)+'</div><span>'+copies(d,c.id)+'</span></div>';
    }
    if(!html)html='<div class="resultmsg">No cards match those filters.</div>';
    box.innerHTML=html;
    var nodes=box.querySelectorAll('[data-result]'),pressTimer,longFired=false;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){
        if(this.getAttribute('data-long')==='1'){this.setAttribute('data-long','0');return;}
        var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'main'))renderEditor();else refreshPreview(d);
      };
      nodes[i].oncontextmenu=function(e){
        e.preventDefault();var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'side'))renderEditor();return false;
      };
      nodes[i].ontouchstart=function(){
        var self=this;self.setAttribute('data-long','0');
        pressTimer=setTimeout(function(){
          self.setAttribute('data-long','1');
          var c=byId(parseInt(self.getAttribute('data-result'),10));state.selected=c.id;
          if(addCardToDeck(d,c,'side'))renderEditor();
        },550);
      };
      nodes[i].ontouchend=function(){clearTimeout(pressTimer);};
      nodes[i].ontouchmove=function(){clearTimeout(pressTimer);};
    }
  }

  function slots(label){var out='',i;for(i=0;i<7;i++)out+='<div class="slot">'+label+' '+(i+1)+'</div>';return out;}
  function renderDuel(){
    A.innerHTML='<div class="screen">'+top('COMBO LAB','home')+'<div class="duel"><div class="field">'+
      '<div class="half"><div class="row">'+slots('OPP ST')+'</div><div class="row">'+slots('OPP MON')+'</div></div>'+
      '<div class="half"><div class="row">'+slots('MON')+'</div><div class="row">'+slots('ST')+'</div></div></div>'+
      '<div class="hud"><h3>CORE DUEL</h3><span class="badge">Engine '+esc(state.engine)+'</span>'+
      '<button class="action" id="checkEngineBtn">CHECK ENGINE</button>'+
      '<div class="status" id="coreStatus">Deck Editor is live. Engine protocol automation comes next.</div></div></div></div>';
    bindNav();document.getElementById('checkEngineBtn').onclick=function(){document.getElementById('coreStatus').textContent=bridge('engineVersion');};
  }

  function renderSettings(){
    var u=state.dataUpdate;
    var status=u.checking?'Checking for updates…':u.message;
    A.innerHTML='<div class="screen">'+top('SETTINGS','home')+
      '<div class="settingsbox"><h2>Combo Forge v5.6</h2>'+
      '<p>Landscape simulator client.</p><p>Engine: <b>'+esc(state.engine)+'</b></p>'+
      '<p>Card database: <b>'+(DB_READY?(DB.length+' loaded'):'bundled + downloadable updates')+'</b></p>'+
      '<div class="updatebox"><h3>PROJECT IGNIS DATA</h3>'+
      '<div id="updateStatus" class="'+(u.available?'warn':'green')+'">'+esc(status)+'</div>'+
      '<p class="updatesmall">The APK ships with the complete BabelCDB card database and Project Ignis CardScripts. '+
      'Combo Forge checks for newer Project Ignis data and can download it without reinstalling the APK. '+
      'Downloaded card scripts are used by ygopro-core on the next duel session.</p>'+
      '<button class="action" id="checkUpdates">CHECK FOR UPDATES</button> '+
      '<button class="action" id="updateData" '+(u.checking?'disabled':'')+'>UPDATE CARD DATA + SCRIPTS</button> '+
      '<button class="dangerbtn" id="clearUpdates">USE BUNDLED DATA</button></div>'+
      '<button class="dangerbtn" id="resetData">RESET LOCAL DECK DATA</button></div></div>';
    bindNav();
    document.getElementById('resetData').onclick=function(){try{localStorage.clear();}catch(e){}location.reload();};
    document.getElementById('checkUpdates').onclick=function(){checkDataUpdates(true);};
    document.getElementById('updateData').onclick=function(){
      if(!window.AndroidBridge||typeof window.AndroidBridge.updateAllData!=='function'){toast('Updater only runs in the Android app');return;}
      state.dataUpdate.checking=true;state.dataUpdate.message='Starting update…';renderSettings();
      try{window.AndroidBridge.updateAllData();}catch(e){state.dataUpdate.checking=false;state.dataUpdate.message='Update failed: '+e.message;renderSettings();}
    };
    document.getElementById('clearUpdates').onclick=function(){
      try{if(window.AndroidBridge&&typeof window.AndroidBridge.clearDownloadedData==='function')window.AndroidBridge.clearDownloadedData();}catch(e){}
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      state.dataUpdate={checking:false,available:false,db:false,scripts:false,message:'Using bundled data'};
      toast('Downloaded updates cleared');
      renderSettings();
    };
  }

  window.comboDataUpdateResult=function(r){
    state.dataUpdate.checking=false;
    if(!r||!r.ok){
      state.dataUpdate.available=false;
      state.dataUpdate.message='Could not check right now'+(r&&r.error?': '+r.error:'');
    }else{
      state.dataUpdate.db=!!r.db;state.dataUpdate.scripts=!!r.scripts;
      state.dataUpdate.available=!!(r.db||r.scripts);
      state.dataUpdate.message=state.dataUpdate.available
        ? ('Update available'+(r.db?' · card database':'')+(r.scripts?' · scripts':''))
        : 'Card database and scripts are current';
    }
    if(state.screen==='settings')renderSettings();
  };

  window.comboDataUpdateProgress=function(msg){
    state.dataUpdate.checking=true;state.dataUpdate.message=msg||'Updating…';
    if(state.screen==='settings'){
      var s=document.getElementById('updateStatus');if(s)s.textContent=state.dataUpdate.message;
    }
  };

  window.comboDataUpdateFinished=function(r){
    state.dataUpdate.checking=false;
    if(r&&r.ok){
      state.dataUpdate.available=false;state.dataUpdate.db=false;state.dataUpdate.scripts=false;
      state.dataUpdate.message='Update installed · reload Deck Editor to use the new database';
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      toast('Project Ignis data updated');
    }else{
      state.dataUpdate.message='Update failed'+(r&&r.error?': '+r.error:'');
    }
    if(state.screen==='settings')renderSettings();
  };

  function checkDataUpdates(showStatus){
    try{
      if(!window.AndroidBridge||typeof window.AndroidBridge.checkDataUpdates!=='function'){
        if(showStatus)toast('Update checks run in the Android app');
        return;
      }
      state.dataUpdate.checking=true;state.dataUpdate.message='Checking Project Ignis…';
      if(state.screen==='settings')renderSettings();
      window.AndroidBridge.checkDataUpdates();
    }catch(e){
      state.dataUpdate.checking=false;state.dataUpdate.message='Check failed: '+e.message;
      if(state.screen==='settings')renderSettings();
    }
  }

  function render(){
    if(state.screen==='home')renderHome();
    else if(state.screen==='manager')renderManager();
    else if(state.screen==='editor')renderEditor();
    else if(state.screen==='duel')renderDuel();
    else renderSettings();
  }

  render();
  setTimeout(function(){
    state.engine=bridge('engineVersion');
    if(!state.engine||state.engine==='UNAVAILABLE'||String(state.engine).indexOf('FAIL|')===0)state.engine='offline';
    if(state.screen==='home')renderHome();
  },800);
  setTimeout(function(){checkDataUpdates(false);},2200);
})();
