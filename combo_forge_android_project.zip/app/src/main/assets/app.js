
(function () {
  var A = document.getElementById('app');
  var DB = [];
  var DB_READY = false;
  var DB_LOADING = false;
  var DB_ERROR = '';
  var searchTimer = null;

  var TYPE = {
    MONSTER:1, SPELL:2, TRAP:4, NORMAL:16, EFFECT:32, FUSION:64, RITUAL:128,
    SPIRIT:512, UNION:1024, GEMINI:2048, TUNER:4096, SYNCHRO:8192,
    QUICKPLAY:65536, CONTINUOUS:131072, EQUIP:262144, FIELD:524288,
    COUNTER:1048576, FLIP:2097152, TOON:4194304, XYZ:8388608,
    PENDULUM:16777216, SPSUMMON:33554432, LINK:67108864
  };

  var ATTR = {1:'EARTH',2:'WATER',4:'FIRE',8:'WIND',16:'LIGHT',32:'DARK',64:'DIVINE'};
  var RACE = {
    1:'Warrior',2:'Spellcaster',4:'Fairy',8:'Fiend',16:'Zombie',32:'Machine',
    64:'Aqua',128:'Pyro',256:'Rock',512:'Winged Beast',1024:'Plant',2048:'Insect',
    4096:'Thunder',8192:'Dragon',16384:'Beast',32768:'Beast-Warrior',65536:'Dinosaur',
    131072:'Fish',262144:'Sea Serpent',524288:'Reptile',1048576:'Psychic',
    2097152:'Divine-Beast',4194304:'Creator God',8388608:'Wyrm',16777216:'Cyberse',
    33554432:'Illusion'
  };

  function fail(msg) {
    if (!A) return;
    A.innerHTML =
      '<div style="height:100%;display:grid;place-items:center;padding:8vw;text-align:center;color:white;font-family:Arial,sans-serif">' +
      '<div><div style="font-size:5vh;font-weight:800;letter-spacing:.2em">COMBO FORGE</div>' +
      '<p style="color:#ff9aa8">Client boot error</p><pre style="white-space:pre-wrap;text-align:left;max-width:80vw">' +
      esc(msg) + '</pre><button id="resetBtn" style="padding:12px 20px">RESET LOCAL DATA</button></div></div>';
    var b=document.getElementById('resetBtn');
    if(b)b.onclick=function(){try{localStorage.clear();}catch(e){} location.reload();};
  }

  window.onerror=function(message,source,line,col){
    fail(String(message)+'\n'+String(source||'')+':'+String(line||0)+':'+String(col||0));
    return true;
  };

  function esc(s){
    return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function bridge(name){
    try{
      if(!window.AndroidBridge)return 'UNAVAILABLE';
      var fn=window.AndroidBridge[name];
      if(typeof fn!=='function')return 'UNAVAILABLE';
      return fn.call(window.AndroidBridge);
    }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e);}
  }
  function img(code){return 'https://images.ygoprodeck.com/images/cards/'+code+'.jpg';}
  function has(v,b){return (v & b)!==0;}
  function isExtra(c){return has(c.type,TYPE.FUSION)||has(c.type,TYPE.SYNCHRO)||has(c.type,TYPE.XYZ)||has(c.type,TYPE.LINK);}
  function isMonster(c){return has(c.type,TYPE.MONSTER);}
  function typeLine(c){
    if(has(c.type,TYPE.SPELL)){
      if(has(c.type,TYPE.QUICKPLAY))return 'Quick-Play Spell';
      if(has(c.type,TYPE.FIELD))return 'Field Spell';
      if(has(c.type,TYPE.EQUIP))return 'Equip Spell';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Spell';
      return 'Spell';
    }
    if(has(c.type,TYPE.TRAP)){
      if(has(c.type,TYPE.COUNTER))return 'Counter Trap';
      if(has(c.type,TYPE.CONTINUOUS))return 'Continuous Trap';
      return 'Trap';
    }
    var a=[];
    if(has(c.type,TYPE.FUSION))a.push('Fusion');
    if(has(c.type,TYPE.SYNCHRO))a.push('Synchro');
    if(has(c.type,TYPE.XYZ))a.push('Xyz');
    if(has(c.type,TYPE.LINK))a.push('Link');
    if(has(c.type,TYPE.RITUAL))a.push('Ritual');
    if(has(c.type,TYPE.PENDULUM))a.push('Pendulum');
    if(has(c.type,TYPE.TUNER))a.push('Tuner');
    if(has(c.type,TYPE.FLIP))a.push('Flip');
    if(has(c.type,TYPE.NORMAL))a.push('Normal');
    else if(has(c.type,TYPE.EFFECT))a.push('Effect');
    return a.join(' / ')+' Monster';
  }

  var state={screen:'home',decks:[],active:null,engine:'checking',selected:null,editorQuery:'',
    editorDraft:null,editorDirty:false,
    appUpdate:{checking:false,available:false,versionName:'',apkUrl:'',notes:'',message:'Not checked'},
    dataUpdate:{checking:false,available:false,db:false,scripts:false,message:'Not checked'}};
  var combo={deckIndex:0,handPick:[],started:false,selectedCode:0,field:null,idle:null,prompt:null,phase:'MAIN 1',turn:1,log:[]};

  try{
    var raw=localStorage.getItem('cf54_decks') || localStorage.getItem('cf53_decks');
    if(raw){
      var parsed=JSON.parse(raw);
      if(Object.prototype.toString.call(parsed)==='[object Array]')state.decks=parsed;
    }
  }catch(e){try{localStorage.removeItem('cf54_decks');}catch(_){}}

  function persistDecks(){
    try{localStorage.setItem('cf54_decks',JSON.stringify(state.decks));return true;}catch(e){return false;}
  }
  function markDirty(){state.editorDirty=true;updateSaveBadge();}
  function updateSaveBadge(){
    var b=document.getElementById('saveDeckBtn');
    if(b){b.textContent=state.editorDirty?'SAVE DECK *':'SAVE DECK';b.className=state.editorDirty?'savebtn dirty':'savebtn';}
  }
  function saveCurrentDeck(){
    if(state.active==null||!state.editorDraft)return;
    state.decks[state.active]=JSON.parse(JSON.stringify(state.editorDraft));
    if(persistDecks()){state.editorDirty=false;updateSaveBadge();toast('Deck saved');}
    else toast('Could not save deck');
  }
  function normalizeDeck(d){
    if(!d.main)d.main=[];
    if(!d.extra)d.extra=[];
    if(!d.side)d.side=[];
    return d;
  }

  function top(title,back){
    return '<div class="topbar"><button class="iconbtn" data-go="'+(back||'home')+'">✕</button>'+
      '<button class="iconbtn" data-go="home">⌂</button><div class="title">'+esc(title)+'</div>'+
      '<button class="iconbtn" data-go="settings">⚙</button></div>';
  }
  function bindNav(){
    var n=document.querySelectorAll('[data-go]'),i;
    for(i=0;i<n.length;i++)n[i].onclick=function(){
      var next=this.getAttribute('data-go');
      if(state.screen==='editor'&&state.editorDirty){
        if(!confirm('You have unsaved deck changes. Leave without saving?'))return;
        state.editorDraft=null;state.editorDirty=false;
      }
      state.screen=next;render();
    };
  }

  function renderHome(){
    A.innerHTML='<div class="screen home"><div class="brand"><div class="brandmark">CF</div>'+
      '<h1>COMBO FORGE</h1><div class="home-menu"><button id="comboBtn">COMBO LAB</button>'+
      '<button id="deckBtn">DECK MANAGER</button><button id="settingsBtn">SETTINGS</button></div></div>'+
      '<div class="version">v5.9 · Engine '+esc(state.engine)+'</div></div>';
    document.getElementById('comboBtn').onclick=function(){state.screen='duel';render();};
    document.getElementById('deckBtn').onclick=function(){state.screen='manager';render();};
    document.getElementById('settingsBtn').onclick=function(){state.screen='settings';render();};
  }

  function deckCover(d){
    var code=(d.main&&d.main[0])||(d.extra&&d.extra[0])||0;
    return code?'<img src="'+img(code)+'" onerror="this.style.visibility=\'hidden\'">':'<div class="emptycover">CF</div>';
  }

  function renderManager(){
    var tiles='',i,d;
    for(i=0;i<state.decks.length;i++){
      d=normalizeDeck(state.decks[i]);
      tiles+='<div class="decktile" data-deck="'+i+'">'+deckCover(d)+
        '<div class="deckname">'+esc(d.name||('Deck '+(i+1)))+'</div>'+
        '<div class="deckcounts">'+d.main.length+' / '+d.extra.length+' / '+d.side.length+'</div></div>';
    }
    A.innerHTML='<div class="screen">'+top('DECK MANAGER','home')+
      '<div class="manager"><div class="deckgrid">'+tiles+'</div><div class="sidepanel">'+
      '<button class="action full" id="newDeckBtn">CREATE DECK</button>'+
      '<button class="action full" id="dupDeckBtn">DUPLICATE SELECTED</button>'+
      '<button class="dangerbtn full" id="deleteDeckBtn">DELETE SELECTED</button>'+
      '<div class="managerhint">Tap a deck to open it.<br>Main / Extra / Side counts appear under each deck.</div>'+
      '</div></div></div>';
    bindNav();
    document.getElementById('newDeckBtn').onclick=function(){
      state.decks.push({name:'Deck '+(state.decks.length+1),main:[],extra:[],side:[]});
      state.active=state.decks.length-1; persistDecks(); state.editorDraft=JSON.parse(JSON.stringify(state.decks[state.active])); state.editorDirty=false; state.screen='editor'; render();
    };
    var cards=document.querySelectorAll('[data-deck]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){
      state.active=parseInt(this.getAttribute('data-deck'),10);
        state.editorDraft=JSON.parse(JSON.stringify(normalizeDeck(state.decks[state.active])));
        state.editorDirty=false;state.screen='editor';render();
    };
    document.getElementById('dupDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      var copy=JSON.parse(JSON.stringify(state.decks[state.active]));
      copy.name=(copy.name||'Deck')+' Copy';state.decks.push(copy);persistDecks();renderManager();
    };
    document.getElementById('deleteDeckBtn').onclick=function(){
      if(state.active==null||!state.decks[state.active])return;
      state.decks.splice(state.active,1);state.active=null;persistDecks();renderManager();
    };
  }

  function loadDB(done){
    if(DB_READY){done();return;}
    if(DB_LOADING){setTimeout(function(){loadDB(done);},250);return;}
    DB_LOADING=true; DB_ERROR='';
    var assetText = '';
    try {
      if (window.AndroidBridge && typeof window.AndroidBridge.readAssetText === 'function') {
        assetText = window.AndroidBridge.readAssetText('engine/db/cards.tsv') || '';
      }
    } catch (e) {}
    var source = assetText
      ? Promise.resolve(assetText)
      : fetch('engine/db/cards.tsv').then(function(r){
          if(!r.ok)throw new Error('cards.tsv HTTP '+r.status);
          return r.text();
        });
    source.then(function(text){
      var lines=text.split('\n'),i,cols,cards=[];
      for(i=0;i<lines.length;i++){
        if(!lines[i]||lines[i].charAt(0)==='#')continue;
        cols=lines[i].split('\t');
        if(cols.length<11)continue;
        cards.push({
          id:parseInt(cols[0],10)||0,alias:parseInt(cols[1],10)||0,setcode:cols[2]||'0',
          type:parseInt(cols[3],10)||0,atk:parseInt(cols[4],10)||0,def:parseInt(cols[5],10)||0,
          level:parseInt(cols[6],10)||0,race:parseInt(cols[7],10)||0,attribute:parseInt(cols[8],10)||0,
          name:unescapeField(cols[9]),desc:unescapeField(cols.slice(10).join('\t'))
        });
      }
      DB=cards;DB_READY=true;DB_LOADING=false;done();
    }).catch(function(e){
      DB_ERROR=String(e&&e.message?e.message:e);DB_LOADING=false;done();
    });
  }

  function unescapeField(s){
    return String(s||'').replace(/\\n/g,'\n').replace(/\\t/g,'\t').replace(/\\\\/g,'\\');
  }
  function byId(id){
    var i;
    for(i=0;i<DB.length;i++)if(DB[i].id===id)return DB[i];
    return {id:id,name:'Card '+id,desc:'',type:0,atk:0,def:0,level:0,race:0,attribute:0};
  }
  function copies(d,id){
    var n=0,i,z,arrs=[d.main,d.extra,d.side];
    for(z=0;z<arrs.length;z++)for(i=0;i<arrs[z].length;i++)if(arrs[z][i]===id)n++;
    return n;
  }
  function addCardToDeck(d,c,zone){
    if(copies(d,c.id)>=3){toast('Maximum 3 copies');return false;}
    if(zone==='side'){
      if(d.side.length>=15){toast('Side Deck is full');return false;}
      d.side.push(c.id);
    }else if(isExtra(c)){
      if(d.extra.length>=15){toast('Extra Deck is full');return false;}
      d.extra.push(c.id);
    }else{
      if(d.main.length>=60){toast('Main Deck is full');return false;}
      d.main.push(c.id);
    }
    markDirty();return true;
  }
  function removeOne(d,zone,index){
    if(d[zone]&&index>=0&&index<d[zone].length){d[zone].splice(index,1);markDirty();}
  }
  function toast(msg){
    var old=document.getElementById('toast');if(old&&old.parentNode)old.parentNode.removeChild(old);
    var t=document.createElement('div');t.id='toast';t.className='toast';t.textContent=msg;
    document.body.appendChild(t);setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},1400);
  }

  function cardHtml(id,zone,index){
    var c=byId(id);
    return '<div class="deckcard" data-card="'+id+'" data-zone="'+zone+'" data-index="'+index+'" title="'+esc(c.name)+'">'+
      '<img src="'+img(id)+'" onerror="this.className=\'imgfail\'"></div>';
  }
  function zoneCards(arr,zone){
    var out='',i;
    for(i=0;i<arr.length;i++)out+=cardHtml(arr[i],zone,i);
    return out;
  }
  function filterOptions(map){
    var out='<option value="">Any</option>',k;
    for(k in map)if(map.hasOwnProperty(k))out+='<option value="'+k+'">'+esc(map[k])+'</option>';
    return out;
  }
  function monsterKindOptions(){
    return '<option value="">Any monster</option><option value="normal">Normal</option><option value="effect">Effect</option>'+
      '<option value="ritual">Ritual</option><option value="fusion">Fusion</option><option value="synchro">Synchro</option>'+
      '<option value="xyz">Xyz</option><option value="link">Link</option><option value="pendulum">Pendulum</option>'+
      '<option value="tuner">Tuner</option>';
  }

  function renderEditor(){
    var original=state.decks[state.active];
    if(!original){state.screen='manager';render();return;}
    if(!state.editorDraft)state.editorDraft=JSON.parse(JSON.stringify(normalizeDeck(original)));
    var d=state.editorDraft;
    normalizeDeck(d);
    A.innerHTML='<div class="screen">'+top('DECK EDITOR','manager')+
      '<div class="editor">'+
        '<div class="preview" id="preview">'+previewHtml(state.selected?byId(state.selected):null,d)+'</div>'+
        '<div class="decks">'+
          '<div class="zonebox mainzone"><div class="zonehead"><span>MAIN</span><b>'+d.main.length+'</b></div><div class="zonecards" id="mainCards">'+zoneCards(d.main,'main')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>EXTRA</span><b>'+d.extra.length+'</b></div><div class="zonecards" id="extraCards">'+zoneCards(d.extra,'extra')+'</div></div>'+
          '<div class="zonebox"><div class="zonehead"><span>SIDE</span><b>'+d.side.length+'</b></div><div class="zonecards" id="sideCards">'+zoneCards(d.side,'side')+'</div></div>'+
        '</div>'+
        '<div class="searchpanel">'+
          '<input class="search" id="q" placeholder="Search card name or text…" value="'+esc(state.editorQuery)+'">'+
          '<div class="filters">'+
            '<select id="cat"><option value="">All cards</option><option value="monster">Monster</option><option value="spell">Spell</option><option value="trap">Trap</option></select>'+
            '<select id="kind">'+monsterKindOptions()+'</select>'+
            '<select id="attr">'+filterOptions(ATTR)+'</select>'+
            '<select id="race">'+filterOptions(RACE)+'</select>'+
            '<input id="level" type="number" min="0" max="13" placeholder="Level / Rank">'+
            '<input id="atk" type="number" placeholder="ATK ≥">'+
            '<input id="def" type="number" placeholder="DEF ≥">'+
            '<select id="sort"><option value="name">Name A–Z</option><option value="nameDesc">Name Z–A</option><option value="atk">ATK High → Low</option><option value="atkAsc">ATK Low → High</option><option value="def">DEF High → Low</option><option value="level">Level/Rank High → Low</option><option value="levelAsc">Level/Rank Low → High</option><option value="type">Card Type</option></select>'+
          '</div>'+
          '<div class="filterbuttons"><button id="clearFilters">CLEAR</button><span id="dbStatus">'+(DB_READY?(DB.length+' cards'):(DB_ERROR?'DB error':'Loading card database…'))+'</span></div>'+
          '<div class="results" id="results"></div>'+
        '</div>'+
      '</div>'+
      '<div class="decktitlebar"><input id="deckName" value="'+esc(d.name||'Deck')+'">'+
      '<button id="saveDeckBtn" class="savebtn">SAVE DECK</button>'+
      '<span>Tap result = add · Hold = Side · Double-tap deck card = remove</span></div>'+
      '</div>';
    bindNav();
    bindDeckCards(d);
    document.getElementById('deckName').oninput=function(){d.name=this.value||d.name;markDirty();};
    document.getElementById('saveDeckBtn').onclick=saveCurrentDeck;
    updateSaveBadge();
    bindSearch(d);
    loadDB(function(){
      if(state.screen==='editor'){
        var s=document.getElementById('dbStatus');
        if(s)s.textContent=DB_ERROR?('DB error: '+DB_ERROR):(DB.length+' cards');
        refreshResults(d);
        refreshPreview(d);
      }
    });
  }

  function previewHtml(c,d){
    if(!c)return '<div class="previewempty"><div>SELECT A CARD</div><small>Tap a card to view details.</small></div>';
    var stat='';
    if(isMonster(c)){
      stat='<div class="cardstats">'+(ATTR[c.attribute]||'')+' · '+(RACE[c.race]||'')+' · '+
        (has(c.type,TYPE.LINK)?('LINK-'+((c.level)&255)):('LV '+((c.level)&255)))+
        '<br>ATK '+c.atk+(has(c.type,TYPE.LINK)?'':(' / DEF '+c.def))+'</div>';
    }
    return '<img class="bigcard" src="'+img(c.id)+'"><h3>'+esc(c.name)+'</h3>'+
      '<div class="typeline">'+esc(typeLine(c))+'</div>'+stat+
      '<p>'+esc(c.desc).replace(/\n/g,'<br>')+'</p>'+
      '<div class="previewbuttons"><button id="addMain">ADD</button><button id="addSide">SIDE +</button><button id="removeCopy">REMOVE 1</button></div>'+
      '<div class="copies">Copies in deck: '+copies(d,c.id)+'</div>';
  }
  function refreshPreview(d){
    var p=document.getElementById('preview');if(!p)return;
    p.innerHTML=previewHtml(state.selected?byId(state.selected):null,d);
    bindPreviewButtons(d);
  }
  function bindPreviewButtons(d){
    var c=state.selected?byId(state.selected):null;if(!c)return;
    var a=document.getElementById('addMain'),s=document.getElementById('addSide'),r=document.getElementById('removeCopy');
    if(a)a.onclick=function(){if(addCardToDeck(d,c,'main'))renderEditor();};
    if(s)s.onclick=function(){if(addCardToDeck(d,c,'side'))renderEditor();};
    if(r)r.onclick=function(){
      var zones=['side','extra','main'],z,i;
      for(z=0;z<zones.length;z++){
        for(i=d[zones[z]].length-1;i>=0;i--)if(d[zones[z]][i]===c.id){d[zones[z]].splice(i,1);markDirty();renderEditor();return;}
      }
    };
  }
  function bindDeckCards(d){
    var nodes=document.querySelectorAll('.deckcard'),i,timer;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){state.selected=parseInt(this.getAttribute('data-card'),10);refreshPreview(d);};
      nodes[i].ondblclick=function(){
        removeOne(d,this.getAttribute('data-zone'),parseInt(this.getAttribute('data-index'),10));renderEditor();
      };
    }
    bindPreviewButtons(d);
  }

  function kindMatch(c,k){
    if(!k)return true;
    if(k==='normal')return has(c.type,TYPE.NORMAL);
    if(k==='effect')return has(c.type,TYPE.EFFECT);
    if(k==='ritual')return has(c.type,TYPE.RITUAL);
    if(k==='fusion')return has(c.type,TYPE.FUSION);
    if(k==='synchro')return has(c.type,TYPE.SYNCHRO);
    if(k==='xyz')return has(c.type,TYPE.XYZ);
    if(k==='link')return has(c.type,TYPE.LINK);
    if(k==='pendulum')return has(c.type,TYPE.PENDULUM);
    if(k==='tuner')return has(c.type,TYPE.TUNER);
    return true;
  }

  function bindSearch(d){
    var ids=['q','cat','kind','attr','race','level','atk','def','sort'],i,el;
    for(i=0;i<ids.length;i++){
      el=document.getElementById(ids[i]);
      if(!el)continue;
      el.oninput=el.onchange=function(){
        if(this.id==='q')state.editorQuery=this.value;
        clearTimeout(searchTimer);searchTimer=setTimeout(function(){refreshResults(d);},120);
      };
    }
    document.getElementById('clearFilters').onclick=function(){
      for(i=0;i<ids.length;i++){el=document.getElementById(ids[i]);if(el)el.value=(ids[i]==='sort'?'name':'');}
      state.editorQuery='';refreshResults(d);
    };
  }

  function refreshResults(d){
    var box=document.getElementById('results');if(!box)return;
    if(!DB_READY){box.innerHTML='<div class="resultmsg">'+(DB_ERROR?esc(DB_ERROR):'Loading card database…')+'</div>';return;}
    var q=(document.getElementById('q').value||'').toLowerCase().trim();
    var cat=document.getElementById('cat').value,kind=document.getElementById('kind').value;
    var attr=parseInt(document.getElementById('attr').value,10)||0;
    var race=parseInt(document.getElementById('race').value,10)||0;
    var level=document.getElementById('level').value;
    var atk=document.getElementById('atk').value,def=document.getElementById('def').value;
    var sort=document.getElementById('sort').value;
    var out=[],i,c,lvl;
    for(i=0;i<DB.length;i++){
      c=DB[i];
      if(q && c.name.toLowerCase().indexOf(q)<0 && c.desc.toLowerCase().indexOf(q)<0)continue;
      if(cat==='monster'&&!has(c.type,TYPE.MONSTER))continue;
      if(cat==='spell'&&!has(c.type,TYPE.SPELL))continue;
      if(cat==='trap'&&!has(c.type,TYPE.TRAP))continue;
      if(kind&&!kindMatch(c,kind))continue;
      if(attr&&c.attribute!==attr)continue;
      if(race&&c.race!==race)continue;
      lvl=(c.level&255);
      if(level!==''&&lvl!==parseInt(level,10))continue;
      if(atk!==''&&c.atk<parseInt(atk,10))continue;
      if(def!==''&&c.def<parseInt(def,10))continue;
      out.push(c);
      if(out.length>600&&q==='')break;
    }
    if(sort==='atk')out.sort(function(a,b){return b.atk-a.atk || a.name.localeCompare(b.name);});
    else if(sort==='atkAsc')out.sort(function(a,b){return a.atk-b.atk || a.name.localeCompare(b.name);});
    else if(sort==='def')out.sort(function(a,b){return b.def-a.def || a.name.localeCompare(b.name);});
    else if(sort==='level')out.sort(function(a,b){return (b.level&255)-(a.level&255) || a.name.localeCompare(b.name);});
    else if(sort==='levelAsc')out.sort(function(a,b){return (a.level&255)-(b.level&255) || a.name.localeCompare(b.name);});
    else if(sort==='nameDesc')out.sort(function(a,b){return b.name.localeCompare(a.name);});
    else if(sort==='type')out.sort(function(a,b){return typeLine(a).localeCompare(typeLine(b)) || a.name.localeCompare(b.name);});
    else out.sort(function(a,b){return a.name.localeCompare(b.name);});
    if(out.length>160)out=out.slice(0,160);
    var html='';
    for(i=0;i<out.length;i++){
      c=out[i];
      html+='<div class="result" data-result="'+c.id+'"><img loading="lazy" src="'+img(c.id)+'" onerror="this.className=\'imgfail\'">'+
        '<div class="resultname">'+esc(c.name)+'</div><span>'+copies(d,c.id)+'</span></div>';
    }
    if(!html)html='<div class="resultmsg">No cards match those filters.</div>';
    box.innerHTML=html;
    var nodes=box.querySelectorAll('[data-result]'),pressTimer,longFired=false;
    for(i=0;i<nodes.length;i++){
      nodes[i].onclick=function(){
        if(this.getAttribute('data-long')==='1'){this.setAttribute('data-long','0');return;}
        var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'main'))renderEditor();else refreshPreview(d);
      };
      nodes[i].oncontextmenu=function(e){
        e.preventDefault();var c=byId(parseInt(this.getAttribute('data-result'),10));state.selected=c.id;
        if(addCardToDeck(d,c,'side'))renderEditor();return false;
      };
      nodes[i].ontouchstart=function(){
        var self=this;self.setAttribute('data-long','0');
        pressTimer=setTimeout(function(){
          self.setAttribute('data-long','1');
          var c=byId(parseInt(self.getAttribute('data-result'),10));state.selected=c.id;
          if(addCardToDeck(d,c,'side'))renderEditor();
        },550);
      };
      nodes[i].ontouchend=function(){clearTimeout(pressTimer);};
      nodes[i].ontouchmove=function(){clearTimeout(pressTimer);};
    }
  }

  var LOC={DECK:1,HAND:2,MZONE:4,SZONE:8,GRAVE:16,REMOVED:32,EXTRA:64};
  var POS={FU_ATTACK:1,FD_ATTACK:2,FU_DEF:4,FD_DEF:8};
  var MSGN={4:'START',5:'WIN',10:'SELECT_BATTLECMD',11:'SELECT_IDLECMD',12:'SELECT_EFFECTYN',13:'SELECT_YESNO',
    14:'SELECT_OPTION',15:'SELECT_CARD',16:'SELECT_CHAIN',18:'SELECT_PLACE',19:'SELECT_POSITION',20:'SELECT_TRIBUTE',
    23:'SELECT_SUM',26:'SELECT_UNSELECT_CARD',32:'SHUFFLE_DECK',40:'NEW_TURN',41:'NEW_PHASE',50:'MOVE',53:'POS_CHANGE',
    54:'SET',60:'SUMMONING',61:'SUMMONED',62:'SPSUMMONING',63:'SPSUMMONED',70:'CHAINING',71:'CHAINED',72:'CHAIN_SOLVING',
    73:'CHAIN_SOLVED',74:'CHAIN_END',90:'DRAW',94:'LPUPDATE',100:'PAY_LPCOST'};

  function bridgeCall(name,args){
    try{
      if(!window.AndroidBridge)return 'FAIL|NO_BRIDGE';
      var fn=window.AndroidBridge[name];
      if(typeof fn!=='function')return 'FAIL|NO_'+name;
      return fn.apply(window.AndroidBridge,args||[]);
    }catch(e){return 'FAIL|'+String(e&&e.message?e.message:e);}
  }
  function le32hex(n){
    n=(Number(n)>>>0);
    var a=[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255],s='',i;
    for(i=0;i<a.length;i++)s+=('0'+a[i].toString(16)).slice(-2);
    return s;
  }
  function bytesHex(a){
    var s='',i;for(i=0;i<a.length;i++)s+=('0'+(a[i]&255).toString(16)).slice(-2);return s;
  }
  function Reader(bytes){this.b=bytes;this.o=0;}
  Reader.prototype.left=function(){return this.b.length-this.o;};
  Reader.prototype.u8=function(){return this.b[this.o++]||0;};
  Reader.prototype.u32=function(){
    var b=this.b,o=this.o;this.o+=4;
    return ((b[o]||0)|((b[o+1]||0)<<8)|((b[o+2]||0)<<16)|((b[o+3]||0)<<24))>>>0;
  };
  Reader.prototype.u64=function(){var lo=this.u32(),hi=this.u32();return hi*4294967296+lo;};
  function hexBytes(hex){
    var out=[],i;hex=String(hex||'');
    for(i=0;i+1<hex.length;i+=2)out.push(parseInt(hex.substr(i,2),16)||0);
    return out;
  }
  function parsePackets(hex){
    var b=hexBytes(hex),r=new Reader(b),out=[],size,msg,payload;
    while(r.left()>=5){
      size=r.u32();
      if(size<1||size>r.left())break;
      msg=r.u8();
      payload=r.b.slice(r.o,r.o+size-1);r.o+=size-1;
      out.push({msg:msg,name:MSGN[msg]||('MSG_'+msg),payload:payload});
    }
    return out;
  }
  function frameResult(raw){
    raw=String(raw||'');
    var sm=/status=(\d+)/.exec(raw),hm=/hex=([0-9a-fA-F]*)/.exec(raw),lm=/log=([^|]*)/.exec(raw);
    return {ok:raw.indexOf('OK|')===0,status:sm?parseInt(sm[1],10):-1,hex:hm?hm[1]:'',log:lm?lm[1]:'',raw:raw};
  }
  function readLoc(r){return {con:r.u8(),loc:r.u8(),seq:r.u32(),pos:r.u32()};}
  function parseIdle(payload){
    var r=new Reader(payload),out={player:r.u8(),actions:[],canBP:false,canEP:false,canShuffle:false},i,n,c;
    function cand(kind,cmd,longSeq){
      n=r.u32();
      for(i=0;i<n;i++){
        c={code:r.u32(),con:r.u8(),loc:r.u8(),seq:longSeq?r.u32():r.u8(),kind:kind,cmd:cmd,index:i};
        out.actions.push(c);
      }
    }
    cand('Normal Summon',0,true);
    cand('Special Summon',1,true);
    cand('Change Position',2,false);
    cand('Set Monster',3,true);
    cand('Set Spell/Trap',4,true);
    n=r.u32();
    for(i=0;i<n;i++){
      c={code:r.u32(),con:r.u8(),loc:r.u8(),seq:r.u32(),desc:r.u64(),flag:r.u8(),kind:'Activate',cmd:5,index:i};
      out.actions.push(c);
    }
    out.canBP=!!r.u8();out.canEP=!!r.u8();out.canShuffle=!!r.u8();
    return out;
  }
  function firstLegalPlace(payload){
    var r=new Reader(payload),player=r.u8(),min=r.u8(),flag=r.u32(),avail=(~flag)>>>0,i;
    if(player===0){
      for(i=0;i<7;i++)if(avail&(1<<i))return [0,LOC.MZONE,i];
      for(i=0;i<5;i++)if(avail&(1<<(8+i)))return [0,LOC.SZONE,i];
      if(avail&(1<<14))return [0,LOC.SZONE,6];
      if(avail&(1<<15))return [0,LOC.SZONE,7];
    }else{
      for(i=0;i<7;i++)if(avail&(1<<(16+i)))return [1,LOC.MZONE,i];
      for(i=0;i<5;i++)if(avail&(1<<(24+i)))return [1,LOC.SZONE,i];
    }
    return [player,LOC.MZONE,0];
  }
  function choosePosition(payload){
    var r=new Reader(payload);r.u8();r.u32();var p=r.u8();
    if(p&POS.FU_ATTACK)return POS.FU_ATTACK;
    if(p&POS.FU_DEF)return POS.FU_DEF;
    if(p&POS.FD_DEF)return POS.FD_DEF;
    if(p&POS.FD_ATTACK)return POS.FD_ATTACK;
    return p||POS.FU_ATTACK;
  }
  function zoneArray(loc){
    if(!combo.field)return null;
    if(loc===LOC.HAND)return combo.field.hand;
    if(loc===LOC.DECK)return combo.field.deck;
    if(loc===LOC.EXTRA)return combo.field.extra;
    if(loc===LOC.GRAVE)return combo.field.grave;
    if(loc===LOC.REMOVED)return combo.field.banished;
    return null;
  }
  function removeCode(arr,code,seq){
    if(!arr)return 0;
    var i;
    if(typeof seq==='number'&&seq>=0&&seq<arr.length&&(arr[seq]===code||code===0))return arr.splice(seq,1)[0];
    for(i=0;i<arr.length;i++)if(arr[i]===code)return arr.splice(i,1)[0];
    return code;
  }
  function applyMove(payload){
    if(!combo.field)return;
    var r=new Reader(payload),code=r.u32(),from=readLoc(r),to=readLoc(r),reason=r.u32(),moved=code;
    if(from.loc===LOC.MZONE){moved=combo.field.mz[from.seq]||code;combo.field.mz[from.seq]=null;}
    else if(from.loc===LOC.SZONE){moved=combo.field.sz[from.seq]||code;combo.field.sz[from.seq]=null;}
    else moved=removeCode(zoneArray(from.loc),code,from.seq)||code;
    if(to.loc===LOC.MZONE)combo.field.mz[to.seq]=moved;
    else if(to.loc===LOC.SZONE)combo.field.sz[to.seq]=moved;
    else {var a=zoneArray(to.loc);if(a)a.push(moved);}
  }
  function logCore(s){
    combo.log.push(s);if(combo.log.length>80)combo.log.shift();
  }
  function handlePackets(hex){
    var ps=parsePackets(hex),i,p,r,phase;
    for(i=0;i<ps.length;i++){
      p=ps[i];logCore(p.name);
      if(p.msg===11){combo.idle=parseIdle(p.payload);combo.prompt='Choose a legal action';}
      else if(p.msg===18){
        var place=firstLegalPlace(p.payload);
        combo.prompt='Choosing first legal zone';
        return {respond:bytesHex(place)};
      }else if(p.msg===19){
        combo.prompt='Choosing summon position';
        return {respond:le32hex(choosePosition(p.payload))};
      }else if(p.msg===40){r=new Reader(p.payload);combo.turn++;combo.prompt='Turn '+combo.turn;}
      else if(p.msg===41){
        r=new Reader(p.payload);phase=r.u32();
        combo.phase=phase===1?'DRAW':phase===2?'STANDBY':phase===4?'MAIN 1':phase===128?'BATTLE':phase===256?'MAIN 2':phase===512?'END':('PHASE '+phase);
      }else if(p.msg===50)applyMove(p.payload);
      else if(p.msg===61||p.msg===63||p.msg===74){combo.prompt=p.name;}
      else if(p.msg===12||p.msg===13||p.msg===14||p.msg===15||p.msg===16||p.msg===20||p.msg===23||p.msg===26){
        combo.prompt='Engine prompt: '+p.name+' (next protocol milestone)';
      }
    }
    return null;
  }
  function pumpFrame(raw,depth){
    depth=depth||0;
    var f=frameResult(raw);
    if(!f.ok){logCore(f.raw);combo.prompt=f.raw;renderDuel();return;}
    if(f.log)logCore('CORE: '+f.log);
    var auto=handlePackets(f.hex);
    if(auto&&auto.respond&&depth<12){
      pumpFrame(bridgeCall('respond',[auto.respond]),depth+1);return;
    }
    if(f.status===2&&depth<12){
      pumpFrame(bridgeCall('process',[]),depth+1);return;
    }
    renderDuel();
  }
  function comboDeck(){return state.decks[combo.deckIndex]||null;}
  function pickCount(index){var i,n=0;for(i=0;i<combo.handPick.length;i++)if(combo.handPick[i]===index)n++;return n;}
  function setupCard(code,index,selected){
    var c=byId(code);
    return '<div class="setupcard '+(selected?'picked':'')+'" data-pick="'+index+'" title="'+esc(c.name)+'">'+
      '<img src="'+img(code)+'"><span>'+esc(c.name)+'</span></div>';
  }
  function renderComboSetup(){
    var d=comboDeck(),opts='',i,grid='',hand='';
    for(i=0;i<state.decks.length;i++)opts+='<option value="'+i+'" '+(i===combo.deckIndex?'selected':'')+'>'+esc(state.decks[i].name||('Deck '+(i+1)))+'</option>';
    if(d){
      normalizeDeck(d);
      for(i=0;i<d.main.length;i++)grid+=setupCard(d.main[i],i,combo.handPick.indexOf(i)>=0);
      for(i=0;i<combo.handPick.length;i++)hand+=cardHtml(d.main[combo.handPick[i]],'combohand',i);
    }
    A.innerHTML='<div class="screen">'+top('COMBO LAB','home')+
      '<div class="comboSetup"><div class="comboSetupTop"><label>DECK <select id="comboDeckSelect">'+opts+'</select></label>'+
      '<button class="action" id="randomHand">RANDOM 5</button><button class="action" id="clearHand">CLEAR HAND</button>'+
      '<button class="action comboStart" id="startCombo" '+(!d||combo.handPick.length!==5?'disabled':'')+'>START REAL DUEL</button>'+
      '<span class="badge">Engine '+esc(state.engine)+'</span></div>'+
      '<div class="comboSetupBody"><div class="setupDeck"><div class="zonehead"><span>CHOOSE EXACT STARTING HAND</span><b>'+
      combo.handPick.length+'/5</b></div><div class="setupGrid">'+(grid||'<div class="resultmsg">Create and save a deck first.</div>')+'</div></div>'+
      '<div class="setupSide"><h3>STARTING HAND</h3><div class="startingHand">'+hand+'</div>'+
      '<p>Tap five individual cards from your saved Main Deck. The remaining cards stay in the Deck and your saved Extra Deck is loaded into ygopro-core.</p>'+
      '<p class="green">This is using the real duel engine transport. Unsupported prompts will be shown instead of faked.</p></div></div></div></div>';
    bindNav();
    var sel=document.getElementById('comboDeckSelect');
    if(sel)sel.onchange=function(){combo.deckIndex=parseInt(this.value,10)||0;combo.handPick=[];renderDuel();};
    var cards=document.querySelectorAll('[data-pick]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){
      var x=parseInt(this.getAttribute('data-pick'),10),at=combo.handPick.indexOf(x);
      if(at>=0)combo.handPick.splice(at,1);else if(combo.handPick.length<5)combo.handPick.push(x);
      renderDuel();
    };
    var rh=document.getElementById('randomHand');
    if(rh)rh.onclick=function(){
      if(!d||d.main.length<5)return;
      var a=[],j;for(j=0;j<d.main.length;j++)a.push(j);
      for(j=a.length-1;j>0;j--){var k=Math.floor(Math.random()*(j+1)),t=a[j];a[j]=a[k];a[k]=t;}
      combo.handPick=a.slice(0,5);renderDuel();
    };
    var ch=document.getElementById('clearHand');if(ch)ch.onclick=function(){combo.handPick=[];renderDuel();};
    var st=document.getElementById('startCombo');if(st)st.onclick=startComboEngine;
  }
  function startComboEngine(){
    var d=comboDeck();if(!d||combo.handPick.length!==5)return;
    var create=bridgeCall('sessionCreate',[]);
    if(String(create).indexOf('PASS|')!==0){combo.prompt=create;combo.started=true;renderDuel();return;}
    var picked={},i,code;
    for(i=0;i<combo.handPick.length;i++)picked[combo.handPick[i]]=true;
    combo.field={hand:[],deck:[],extra:d.extra.slice(),grave:[],banished:[],mz:[null,null,null,null,null,null,null],sz:[null,null,null,null,null,null,null,null]};
    for(i=0;i<d.main.length;i++){
      code=d.main[i];
      if(picked[i]){
        combo.field.hand.push(code);
        bridgeCall('addCard',[code,0,0,LOC.HAND,0,POS.FU_ATTACK]);
      }else{
        combo.field.deck.push(code);
        bridgeCall('addCard',[code,0,0,LOC.DECK,0,POS.FD_DEF]);
      }
    }
    for(i=0;i<d.extra.length;i++)bridgeCall('addCard',[d.extra[i],0,0,LOC.EXTRA,0,POS.FD_DEF]);
    combo.started=true;combo.idle=null;combo.prompt='Starting ygopro-core…';combo.log=[];combo.selectedCode=combo.field.hand[0]||0;combo.phase='MAIN 1';combo.turn=1;
    pumpFrame(bridgeCall('start',[]),0);
  }
  function duelCard(code,where,seq){
    if(!code)return '<div class="duelzone empty"></div>';
    return '<div class="duelzone cardzone" data-duelcard="'+code+'" data-where="'+where+'" data-seq="'+seq+'"><img src="'+img(code)+'"></div>';
  }
  function actionForSelected(){
    if(!combo.idle||!combo.selectedCode)return '';
    var acts=[],i,a;
    for(i=0;i<combo.idle.actions.length;i++){
      a=combo.idle.actions[i];
      if(a.code===combo.selectedCode)acts.push(a);
    }
    var out='';
    for(i=0;i<acts.length;i++)out+='<button class="coreAction" data-cmd="'+acts[i].cmd+'" data-idx="'+acts[i].index+'">'+esc(acts[i].kind)+'</button>';
    if(combo.idle.canBP)out+='<button class="coreAction" data-cmd="6" data-idx="0">Battle Phase</button>';
    if(combo.idle.canEP)out+='<button class="coreAction" data-cmd="7" data-idx="0">End Phase</button>';
    return out||'<div class="noactions">Select a card with a legal engine action.</div>';
  }
  function renderActiveDuel(){
    var f=combo.field||{hand:[],deck:[],extra:[],grave:[],banished:[],mz:[],sz:[]},i,mz='',sz='',hand='',extraTop='';
    for(i=0;i<7;i++)mz+=duelCard(f.mz[i],'mz',i);
    for(i=0;i<5;i++)sz+=duelCard(f.sz[i],'sz',i);
    for(i=0;i<f.hand.length;i++)hand+='<div class="handcard '+(f.hand[i]===combo.selectedCode?'selected':'')+'" data-duelcard="'+f.hand[i]+'"><img src="'+img(f.hand[i])+'"></div>';
    extraTop=f.extra.length?'<img src="'+img(f.extra[f.extra.length-1])+'">':'';
    A.innerHTML='<div class="screen">'+top('COMBO LAB','home')+
      '<div class="realDuel"><div class="duelBoard">'+
      '<div class="oppLabel">COMBO TEST · NO OPPONENT ACTIONS</div>'+
      '<div class="duelRows"><div class="duelRow">'+mz+'</div><div class="duelRow five">'+sz+'</div></div>'+
      '<div class="pile deckPile"><span>DECK</span><b>'+f.deck.length+'</b></div>'+
      '<div class="pile gravePile"><span>GY</span><b>'+f.grave.length+'</b></div>'+
      '<div class="pile extraPile">'+extraTop+'<span>EXTRA</span><b>'+f.extra.length+'</b></div>'+
      '<div class="hand">'+hand+'</div>'+
      '<div class="phaseBadge">TURN '+combo.turn+' · '+esc(combo.phase)+'</div></div>'+
      '<div class="duelHud"><span class="badge">OCGCORE '+esc(state.engine)+'</span><h3>'+esc(combo.prompt||'Waiting for engine')+'</h3>'+
      '<div class="actionPanel">'+actionForSelected()+'</div>'+
      '<button class="action" id="processCore">PROCESS CORE</button><button class="dangerbtn" id="resetCombo">NEW COMBO</button>'+
      '<div class="coreLog">'+esc(combo.log.slice(-18).join('\n'))+'</div></div></div></div>';
    bindNav();
    var cards=document.querySelectorAll('[data-duelcard]');
    for(i=0;i<cards.length;i++)cards[i].onclick=function(){combo.selectedCode=parseInt(this.getAttribute('data-duelcard'),10)||0;renderDuel();};
    var acts=document.querySelectorAll('[data-cmd]');
    for(i=0;i<acts.length;i++)acts[i].onclick=function(){
      var cmd=parseInt(this.getAttribute('data-cmd'),10)||0,idx=parseInt(this.getAttribute('data-idx'),10)||0;
      combo.idle=null;combo.prompt='Sending '+(cmd===0?'Normal Summon':cmd===1?'Special Summon':cmd===3?'Set Monster':cmd===4?'Set Spell/Trap':cmd===5?'Activate':cmd===6?'Battle Phase':'End Phase')+'…';
      pumpFrame(bridgeCall('respond',[le32hex(((idx<<16)>>>0)+cmd)]),0);
    };
    document.getElementById('processCore').onclick=function(){pumpFrame(bridgeCall('process',[]),0);};
    document.getElementById('resetCombo').onclick=function(){try{bridgeCall('destroy',[]);}catch(e){}combo.started=false;combo.idle=null;combo.prompt=null;combo.field=null;combo.handPick=[];renderDuel();};
  }
  function renderDuel(){
    if(!combo.started)renderComboSetup();else renderActiveDuel();
  }

  function removeAppUpdateModal(){
    var m=document.getElementById('appUpdateModal');if(m&&m.parentNode)m.parentNode.removeChild(m);
  }
  function showAppUpdateModal(){
    var u=state.appUpdate;if(!u.available||!u.apkUrl)return;
    removeAppUpdateModal();
    var m=document.createElement('div');m.id='appUpdateModal';m.className='updateModal';
    m.innerHTML='<div class="updateDialog"><div class="updateEyebrow">COMBO FORGE UPDATE</div>'+
      '<h2>Version '+esc(u.versionName||'new')+' is ready</h2>'+
      '<p>'+esc(u.notes||'A newer Combo Forge build is available.')+'</p>'+
      '<div id="appUpdateModalStatus" class="updatesmall">Download it here and Android will open the installer for you.</div>'+
      '<div class="updateActions"><button class="action" id="installAppUpdate">UPDATE NOW</button>'+
      '<button class="dangerbtn" id="laterAppUpdate">LATER</button></div></div>';
    document.body.appendChild(m);
    document.getElementById('laterAppUpdate').onclick=removeAppUpdateModal;
    document.getElementById('installAppUpdate').onclick=function(){
      var b=this;b.disabled=true;b.textContent='DOWNLOADING…';
      try{window.AndroidBridge.downloadAppUpdate(u.apkUrl);}catch(e){
        b.disabled=false;b.textContent='UPDATE NOW';
        var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent='Update failed: '+e.message;
      }
    };
  }
  function checkAppUpdate(showStatus){
    try{
      if(!window.AndroidBridge||typeof window.AndroidBridge.checkAppUpdate!=='function'){
        if(showStatus)toast('App updates are available in the Android app');
        return;
      }
      state.appUpdate.checking=true;state.appUpdate.message='Checking for a newer app build…';
      if(state.screen==='settings')renderSettings();
      window.AndroidBridge.checkAppUpdate();
    }catch(e){
      state.appUpdate.checking=false;state.appUpdate.message='Check failed: '+e.message;
      if(state.screen==='settings')renderSettings();
    }
  }
  window.comboAppUpdateResult=function(r){
    state.appUpdate.checking=false;
    if(!r||!r.ok){
      state.appUpdate.available=false;
      state.appUpdate.message='Could not check right now'+(r&&r.error?': '+r.error:'');
    }else if(r.available){
      state.appUpdate.available=true;
      state.appUpdate.versionName=r.versionName||'';
      state.appUpdate.apkUrl=r.apkUrl||'';
      state.appUpdate.notes=r.notes||'';
      state.appUpdate.message='Version '+state.appUpdate.versionName+' available';
      showAppUpdateModal();
    }else{
      state.appUpdate.available=false;
      state.appUpdate.message='Combo Forge is up to date';
    }
    if(state.screen==='settings')renderSettings();
  };
  window.comboAppUpdateProgress=function(msg){
    state.appUpdate.message=msg||'Updating…';
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    if(state.screen==='settings'){
      var x=document.getElementById('appBuildStatus');if(x)x.textContent=state.appUpdate.message;
    }
  };
  window.comboAppUpdateNeedsPermission=function(){
    state.appUpdate.message='Allow “Install unknown apps” for Combo Forge, return here, then tap INSTALL DOWNLOADED UPDATE.';
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    var b=document.getElementById('installAppUpdate');
    if(b){b.disabled=false;b.textContent='INSTALL DOWNLOADED UPDATE';b.onclick=function(){window.AndroidBridge.installDownloadedUpdate();};}
    if(state.screen==='settings')renderSettings();
  };
  window.comboAppUpdateFinished=function(r){
    if(r&&r.ok){state.appUpdate.message='Installer opened';}
    else state.appUpdate.message='Update failed'+(r&&r.error?': '+r.error:'');
    var s=document.getElementById('appUpdateModalStatus');if(s)s.textContent=state.appUpdate.message;
    if(state.screen==='settings')renderSettings();
  };

  function renderSettings(){
    var u=state.dataUpdate,au=state.appUpdate;
    var status=u.checking?'Checking for updates…':u.message;
    var appStatus=au.checking?'Checking for a newer app build…':au.message;
    A.innerHTML='<div class="screen">'+top('SETTINGS','home')+
      '<div class="settingsbox"><h2>Combo Forge v5.9</h2>'+
      '<p>Landscape simulator client.</p><p>Engine: <b>'+esc(state.engine)+'</b></p>'+
      '<div class="updatebox"><h3>COMBO FORGE APP</h3>'+
      '<div id="appBuildStatus" class="'+(au.available?'warn':'green')+'">'+esc(appStatus)+'</div>'+
      '<p class="updatesmall">The app checks this automatically when it opens. New APKs download inside Combo Forge, then Android asks you to confirm installation.</p>'+
      '<button class="action" id="checkAppBuild">CHECK APP UPDATE</button> '+
      (au.available?'<button class="action" id="installAppBuild">UPDATE TO '+esc(au.versionName)+'</button>':'')+
      '</div>'+
      '<p>Card database: <b>'+(DB_READY?(DB.length+' loaded'):'bundled + downloadable updates')+'</b></p>'+
      '<div class="updatebox"><h3>PROJECT IGNIS DATA</h3>'+
      '<div id="updateStatus" class="'+(u.available?'warn':'green')+'">'+esc(status)+'</div>'+
      '<p class="updatesmall">The APK ships with the complete BabelCDB card database and Project Ignis CardScripts. '+
      'Combo Forge checks for newer Project Ignis data and can download it without reinstalling the APK. '+
      'Downloaded card scripts are used by ygopro-core on the next duel session.</p>'+
      '<button class="action" id="checkUpdates">CHECK FOR UPDATES</button> '+
      '<button class="action" id="updateData" '+(u.checking?'disabled':'')+'>UPDATE CARD DATA + SCRIPTS</button> '+
      '<button class="dangerbtn" id="clearUpdates">USE BUNDLED DATA</button></div>'+
      '<button class="dangerbtn" id="resetData">RESET LOCAL DECK DATA</button></div></div>';
    bindNav();
    document.getElementById('resetData').onclick=function(){try{localStorage.clear();}catch(e){}location.reload();};
    document.getElementById('checkAppBuild').onclick=function(){checkAppUpdate(true);};
    var iab=document.getElementById('installAppBuild');
    if(iab)iab.onclick=function(){showAppUpdateModal();};
    document.getElementById('checkUpdates').onclick=function(){checkDataUpdates(true);};
    document.getElementById('updateData').onclick=function(){
      if(!window.AndroidBridge||typeof window.AndroidBridge.updateAllData!=='function'){toast('Updater only runs in the Android app');return;}
      state.dataUpdate.checking=true;state.dataUpdate.message='Starting update…';renderSettings();
      try{window.AndroidBridge.updateAllData();}catch(e){state.dataUpdate.checking=false;state.dataUpdate.message='Update failed: '+e.message;renderSettings();}
    };
    document.getElementById('clearUpdates').onclick=function(){
      try{if(window.AndroidBridge&&typeof window.AndroidBridge.clearDownloadedData==='function')window.AndroidBridge.clearDownloadedData();}catch(e){}
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      state.dataUpdate={checking:false,available:false,db:false,scripts:false,message:'Using bundled data'};
      toast('Downloaded updates cleared');
      renderSettings();
    };
  }

  window.comboDataUpdateResult=function(r){
    state.dataUpdate.checking=false;
    if(!r||!r.ok){
      state.dataUpdate.available=false;
      state.dataUpdate.message='Could not check right now'+(r&&r.error?': '+r.error:'');
    }else{
      state.dataUpdate.db=!!r.db;state.dataUpdate.scripts=!!r.scripts;
      state.dataUpdate.available=!!(r.db||r.scripts);
      state.dataUpdate.message=state.dataUpdate.available
        ? ('Update available'+(r.db?' · card database':'')+(r.scripts?' · scripts':''))
        : 'Card database and scripts are current';
    }
    if(state.screen==='settings')renderSettings();
  };

  window.comboDataUpdateProgress=function(msg){
    state.dataUpdate.checking=true;state.dataUpdate.message=msg||'Updating…';
    if(state.screen==='settings'){
      var s=document.getElementById('updateStatus');if(s)s.textContent=state.dataUpdate.message;
    }
  };

  window.comboDataUpdateFinished=function(r){
    state.dataUpdate.checking=false;
    if(r&&r.ok){
      state.dataUpdate.available=false;state.dataUpdate.db=false;state.dataUpdate.scripts=false;
      state.dataUpdate.message='Update installed · reload Deck Editor to use the new database';
      DB=[];DB_READY=false;DB_LOADING=false;DB_ERROR='';
      toast('Project Ignis data updated');
    }else{
      state.dataUpdate.message='Update failed'+(r&&r.error?': '+r.error:'');
    }
    if(state.screen==='settings')renderSettings();
  };

  function checkDataUpdates(showStatus){
    try{
      if(!window.AndroidBridge||typeof window.AndroidBridge.checkDataUpdates!=='function'){
        if(showStatus)toast('Update checks run in the Android app');
        return;
      }
      state.dataUpdate.checking=true;state.dataUpdate.message='Checking Project Ignis…';
      if(state.screen==='settings')renderSettings();
      window.AndroidBridge.checkDataUpdates();
    }catch(e){
      state.dataUpdate.checking=false;state.dataUpdate.message='Check failed: '+e.message;
      if(state.screen==='settings')renderSettings();
    }
  }

  function render(){
    if(state.screen==='home')renderHome();
    else if(state.screen==='manager')renderManager();
    else if(state.screen==='editor')renderEditor();
    else if(state.screen==='duel')renderDuel();
    else renderSettings();
  }

  render();
  setTimeout(function(){
    state.engine=bridge('engineVersion');
    if(!state.engine||state.engine==='UNAVAILABLE'||String(state.engine).indexOf('FAIL|')===0)state.engine='offline';
    if(state.screen==='home')renderHome();
  },800);
  setTimeout(function(){checkAppUpdate(false);},1400);
  setTimeout(function(){checkDataUpdates(false);},2800);
})();
