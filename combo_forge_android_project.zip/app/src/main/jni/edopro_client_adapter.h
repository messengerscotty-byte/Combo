#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace cfclient {

struct Packet {
    uint8_t message = 0;
    std::vector<uint8_t> payload;
};

struct ClientState {
    uint8_t last_message = 0;
    std::string last_name;
    uint32_t packet_count = 0;
    uint32_t interactive_count = 0;
    bool waiting_for_response = false;
    std::string prompt_summary;
    std::string error;
};

class Adapter {
public:
    void reset();
    bool consume(const uint8_t* data, uint32_t len);
    const ClientState& state() const { return state_; }
    std::string summary() const;
    static const char* messageName(uint8_t msg);
    static bool isInteractive(uint8_t msg);
private:
    ClientState state_;
    bool inspectPacket(const Packet& packet);
};

} // namespace cfclient
