LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := comboengine
LOCAL_SRC_FILES := combo_engine_jni.cpp edopro_client_adapter.cpp
LOCAL_CPPFLAGS += -std=c++17
LOCAL_LDLIBS += -llog -landroid
LOCAL_C_INCLUDES += $(LOCAL_PATH)/../../../../vendor/ygopro-core
LOCAL_SHARED_LIBRARIES := ocgcore
include $(BUILD_SHARED_LIBRARY)

include $(LOCAL_PATH)/../../../../vendor/ygopro-core/Android.mk
