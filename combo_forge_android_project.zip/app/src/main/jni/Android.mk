LOCAL_PATH := $(call my-dir)
COMBO_JNI_PATH := $(LOCAL_PATH)
CORE_PATH := $(abspath $(LOCAL_PATH)/../../../../vendor/ygopro-core)

include $(CORE_PATH)/Android.mk

LOCAL_PATH := $(COMBO_JNI_PATH)
include $(CLEAR_VARS)
LOCAL_MODULE := comboengine
LOCAL_SRC_FILES := combo_engine_jni.cpp
LOCAL_C_INCLUDES := $(CORE_PATH)
LOCAL_SHARED_LIBRARIES := ocgcore
LOCAL_LDLIBS := -llog -landroid
LOCAL_CPPFLAGS := -std=c++17 -fexceptions
ifeq ($(TARGET_ARCH_ABI), arm64-v8a)
LOCAL_LDFLAGS += -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
endif
include $(BUILD_SHARED_LIBRARY)
