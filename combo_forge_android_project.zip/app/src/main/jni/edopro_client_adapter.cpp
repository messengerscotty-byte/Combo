#include "edopro_client_adapter.h"
#include <sstream>

namespace cfclient {

namespace {
struct Reader {
    const uint8_t* p;
    size_t n;
    size_t o = 0;
    bool ok = true;
    Reader(const uint8_t* data, size_t len): p(data), n(len) {}
    uint8_t u8(){ if(o+1>n){ok=false;return 0;} return p[o++]; }
    uint32_t u32(){
        if(o+4>n){ok=false;return 0;}
        uint32_t v=(uint32_t)p[o]|((uint32_t)p[o+1]<<8)|((uint32_t)p[o+2]<<16)|((uint32_t)p[o+3]<<24);
        o+=4; return v;
    }
    uint64_t u64(){ uint64_t lo=u32(), hi=u32(); return lo|(hi<<32); }
    void loc(){ u8();u8();u32();u32(); }
    size_t left() const { return o<=n?n-o:0; }
};
static std::string cardLocSummary(uint32_t code, uint8_t loc) {
    std::ostringstream s; s << "card=" << code << ",loc=" << (unsigned)loc; return s.str();
}
}

void Adapter::reset(){ state_ = {}; }

const char* Adapter::messageName(uint8_t m){
    switch(m){
        case 1:return "RETRY"; case 2:return "HINT"; case 4:return "START"; case 5:return "WIN";
        case 10:return "SELECT_BATTLECMD"; case 11:return "SELECT_IDLECMD"; case 12:return "SELECT_EFFECTYN";
        case 13:return "SELECT_YESNO"; case 14:return "SELECT_OPTION"; case 15:return "SELECT_CARD";
        case 16:return "SELECT_CHAIN"; case 18:return "SELECT_PLACE"; case 19:return "SELECT_POSITION";
        case 20:return "SELECT_TRIBUTE"; case 21:return "SORT_CHAIN"; case 22:return "SELECT_COUNTER";
        case 23:return "SELECT_SUM"; case 24:return "SELECT_DISFIELD"; case 25:return "SORT_CARD";
        case 26:return "SELECT_UNSELECT_CARD"; case 40:return "NEW_TURN"; case 41:return "NEW_PHASE";
        case 50:return "MOVE"; case 53:return "POS_CHANGE"; case 54:return "SET"; case 60:return "SUMMONING";
        case 61:return "SUMMONED"; case 62:return "SPSUMMONING"; case 63:return "SPSUMMONED";
        case 64:return "FLIPSUMMONING"; case 65:return "FLIPSUMMONED"; case 70:return "CHAINING";
        case 71:return "CHAINED"; case 72:return "CHAIN_SOLVING"; case 73:return "CHAIN_SOLVED";
        case 74:return "CHAIN_END"; case 90:return "DRAW"; case 94:return "LPUPDATE"; case 100:return "PAY_LPCOST";
        default:return "MESSAGE";
    }
}
bool Adapter::isInteractive(uint8_t m){
    switch(m){
        case 10:case 11:case 12:case 13:case 14:case 15:case 16:case 18:case 19:case 20:
        case 21:case 22:case 23:case 24:case 25:case 26:return true;
        default:return false;
    }
}

bool Adapter::inspectPacket(const Packet& packet){
    state_.last_message=packet.message;
    state_.last_name=messageName(packet.message);
    state_.packet_count++;
    state_.waiting_for_response=isInteractive(packet.message);
    if(state_.waiting_for_response) state_.interactive_count++;
    state_.prompt_summary.clear();

    Reader r(packet.payload.data(), packet.payload.size());
    std::ostringstream s;
    switch(packet.message){
        case 12: { // SELECT_EFFECTYN
            r.u8(); uint32_t code=r.u32(); r.loc(); uint64_t desc=r.u64();
            s<<"effectyn code="<<code<<" desc="<<desc; break;
        }
        case 13: {
            r.u8(); uint64_t desc=r.u64(); s<<"yesno desc="<<desc; break;
        }
        case 14: {
            r.u8(); uint8_t count=r.u8(); s<<"options="<<(unsigned)count;
            for(uint8_t i=0;i<count;i++)r.u64(); break;
        }
        case 15: {
            r.u8(); bool cancel=r.u8()!=0; uint32_t mn=r.u32(), mx=r.u32(), ct=r.u32();
            s<<"cards="<<ct<<" min="<<mn<<" max="<<mx<<" cancel="<<(cancel?1:0);
            for(uint32_t i=0;i<ct;i++){r.u32();r.loc();} break;
        }
        case 16: {
            r.u8(); uint8_t spec=r.u8(); bool forced=r.u8()!=0; r.u32();r.u32(); uint32_t ct=r.u32();
            s<<"chains="<<ct<<" forced="<<(forced?1:0)<<" spec="<<(unsigned)spec;
            for(uint32_t i=0;i<ct;i++){r.u32();r.loc();r.u64();r.u8();} break;
        }
        case 18: case 24: {
            r.u8(); uint8_t min=r.u8(); uint32_t flag=r.u32();
            s<<"place min="<<(unsigned)min<<" flag="<<flag; break;
        }
        case 19: {
            r.u8(); uint32_t code=r.u32(); uint8_t pos=r.u8();
            s<<"position code="<<code<<" mask="<<(unsigned)pos; break;
        }
        case 20: {
            r.u8(); bool cancel=r.u8()!=0; uint32_t mn=r.u32(),mx=r.u32(),ct=r.u32();
            s<<"tributes="<<ct<<" min="<<mn<<" max="<<mx<<" cancel="<<(cancel?1:0);
            for(uint32_t i=0;i<ct;i++){r.u32();r.u8();r.u8();r.u32();r.u8();} break;
        }
        case 22: {
            r.u8(); uint16_t type=(uint16_t)r.u8()|((uint16_t)r.u8()<<8);
            uint16_t need=(uint16_t)r.u8()|((uint16_t)r.u8()<<8); uint32_t ct=r.u32();
            s<<"counter type="<<type<<" need="<<need<<" cards="<<ct;
            for(uint32_t i=0;i<ct;i++){r.u32();r.u8();r.u8();r.u8();r.u8();r.u8();} break;
        }
        case 23: {
            r.u8(); uint8_t mode=r.u8(); uint32_t sum=r.u32(),mn=r.u32(),mx=r.u32(),must=r.u32();
            s<<"sum="<<sum<<" min="<<mn<<" max="<<mx<<" must="<<must<<" mode="<<(unsigned)mode;
            for(uint32_t i=0;i<must;i++){r.u32();r.loc();r.u32();}
            uint32_t ct=r.u32(); for(uint32_t i=0;i<ct;i++){r.u32();r.loc();r.u32();}
            break;
        }
        case 26: {
            r.u8(); bool fin=r.u8()!=0,cancel=r.u8()!=0; uint32_t mn=r.u32(),mx=r.u32(),a=r.u32();
            s<<"unselect min="<<mn<<" max="<<mx<<" selectable="<<a<<" finish="<<(fin?1:0)<<" cancel="<<(cancel?1:0);
            for(uint32_t i=0;i<a;i++){r.u32();r.loc();}
            uint32_t b=r.u32(); for(uint32_t i=0;i<b;i++){r.u32();r.loc();}
            break;
        }
        default:
            s << messageName(packet.message) << " bytes=" << packet.payload.size();
            break;
    }
    if(!r.ok){
        state_.error="native-client decode underflow in "+state_.last_name;
        return false;
    }
    if(isInteractive(packet.message) && r.left()!=0){
        std::ostringstream e; e<<"native-client trailing "<<r.left()<<" bytes in "<<state_.last_name;
        state_.error=e.str();
    } else state_.error.clear();
    state_.prompt_summary=s.str();
    return true;
}

bool Adapter::consume(const uint8_t* data,uint32_t len){
    if(!data && len) return false;
    size_t o=0;
    while(o+5<=len){
        uint32_t sz=(uint32_t)data[o]|((uint32_t)data[o+1]<<8)|((uint32_t)data[o+2]<<16)|((uint32_t)data[o+3]<<24);
        o+=4;
        if(sz<1 || o+sz>len){ state_.error="invalid packet framing"; return false; }
        Packet p; p.message=data[o++]; p.payload.assign(data+o,data+o+sz-1); o+=sz-1;
        inspectPacket(p);
    }
    if(o!=len){state_.error="trailing bytes after packet stream";return false;}
    return true;
}

std::string Adapter::summary() const{
    std::ostringstream s;
    s<<"msg="<<(unsigned)state_.last_message
     <<",name="<<state_.last_name
     <<",packets="<<state_.packet_count
     <<",interactive="<<state_.interactive_count
     <<",waiting="<<(state_.waiting_for_response?1:0)
     <<",prompt="<<state_.prompt_summary;
    if(!state_.error.empty())s<<",error="<<state_.error;
    return s.str();
}

} // namespace cfclient
