#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include "ocgapi.h"

#define LOG_TAG "ComboForgeCore"

struct CardRecord {
    uint32_t code=0, alias=0, type=0, level=0, attribute=0, lscale=0, rscale=0, link_marker=0;
    uint64_t race=0;
    int32_t attack=0, defense=0;
    std::vector<uint16_t> setcodes;
};

struct Session {
    AAssetManager* assets=nullptr;
    OCG_Duel duel=nullptr;
    std::unordered_map<uint32_t,CardRecord> cards;
    std::string log;
};

static std::mutex gLock;
static Session* gSession=nullptr;

static bool readAsset(AAssetManager* mgr,const std::string& path,std::string& out){
    if(!mgr) return false;
    AAsset* a=AAssetManager_open(mgr,path.c_str(),AASSET_MODE_BUFFER);
    if(!a) return false;
    const auto len=(size_t)AAsset_getLength(a);
    out.resize(len);
    const int got=AAsset_read(a,out.data(),len);
    AAsset_close(a);
    return got==(int)len;
}

static std::string hexEncode(const void* p,uint32_t len){
    static const char* h="0123456789abcdef";
    const auto* b=(const uint8_t*)p;
    std::string s; s.resize((size_t)len*2);
    for(uint32_t i=0;i<len;i++){s[i*2]=h[b[i]>>4];s[i*2+1]=h[b[i]&0xf];}
    return s;
}

static bool hexDecode(const std::string& s,std::vector<uint8_t>& out){
    if(s.size()%2) return false;
    auto cv=[](char c)->int{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};
    out.resize(s.size()/2);
    for(size_t i=0;i<out.size();i++){int a=cv(s[i*2]),b=cv(s[i*2+1]);if(a<0||b<0)return false;out[i]=(uint8_t)((a<<4)|b);}
    return true;
}

static bool loadDb(Session* s){
    std::string txt;
    if(!readAsset(s->assets,"engine/db/cards.tsv",txt)) return false;
    std::istringstream in(txt); std::string line;
    while(std::getline(in,line)){
        if(line.empty()||line[0]=='#') continue;
        std::istringstream row(line); std::string x; std::vector<std::string> v;
        while(std::getline(row,x,'\t')) v.push_back(x);
        if(v.size()<9) continue;
        CardRecord r;
        r.code=(uint32_t)std::strtoull(v[0].c_str(),nullptr,10);
        r.alias=(uint32_t)std::strtoull(v[1].c_str(),nullptr,10);
        uint64_t packed=std::strtoull(v[2].c_str(),nullptr,10);
        for(int i=0;i<4;i++){uint16_t sc=(uint16_t)((packed>>(i*16))&0xffffu);if(sc)r.setcodes.push_back(sc);} r.setcodes.push_back(0);
        r.type=(uint32_t)std::strtoull(v[3].c_str(),nullptr,10);
        r.attack=(int32_t)std::strtoll(v[4].c_str(),nullptr,10);
        r.defense=(int32_t)std::strtoll(v[5].c_str(),nullptr,10);
        uint32_t rawLevel=(uint32_t)std::strtoull(v[6].c_str(),nullptr,10);
        r.level=rawLevel&0xffu; r.rscale=(rawLevel>>16)&0xffu; r.lscale=(rawLevel>>24)&0xffu;
        r.race=std::strtoull(v[7].c_str(),nullptr,10);
        r.attribute=(uint32_t)std::strtoull(v[8].c_str(),nullptr,10);
        if(r.type & 0x4000000u) r.link_marker=(uint32_t)r.defense;
        s->cards.emplace(r.code,std::move(r));
    }
    return !s->cards.empty();
}

static void cardReader(void* payload,uint32_t code,OCG_CardData* data){
    auto* s=(Session*)payload; std::memset(data,0,sizeof(*data));
    if(!s){data->code=code;return;}
    auto it=s->cards.find(code); if(it==s->cards.end()){data->code=code;return;}
    auto& r=it->second;
    data->code=r.code; data->alias=r.alias; data->setcodes=r.setcodes.data(); data->type=r.type;
    data->level=r.level; data->attribute=r.attribute; data->race=r.race; data->attack=r.attack; data->defense=r.defense;
    data->lscale=r.lscale; data->rscale=r.rscale; data->link_marker=r.link_marker;
}
static void cardReaderDone(void*,OCG_CardData*){}
static void logHandler(void* payload,const char* text,int){auto* s=(Session*)payload;if(s&&text)s->log=text;__android_log_print(ANDROID_LOG_INFO,LOG_TAG,"%s",text?text:"");}
static int scriptReader(void* payload,OCG_Duel duel,const char* name){
    auto* s=(Session*)payload; if(!s||!name) return 0;
    const std::string n(name); std::string buf;
    const std::string roots[]={"engine/scripts/","engine/scripts/official/","engine/scripts/pre-release/","engine/scripts/pre-errata/","engine/scripts/rush/","engine/scripts/skill/"};
    for(const auto& root:roots){if(readAsset(s->assets,root+n,buf)) return OCG_LoadScript(duel,buf.data(),(uint32_t)buf.size(),name);}
    return 0;
}

static void destroySession(){if(gSession){if(gSession->duel)OCG_DestroyDuel(gSession->duel);delete gSession;gSession=nullptr;}}

static std::string processFrame(){
    if(!gSession||!gSession->duel) return "FAIL|no-session";
    int status=OCG_DuelProcess(gSession->duel);
    uint32_t len=0; void* msg=OCG_DuelGetMessage(gSession->duel,&len);
    std::string out="OK|status="+std::to_string(status)+"|length="+std::to_string(len)+"|hex="+(msg&&len?hexEncode(msg,len):"");
    if(!gSession->log.empty()) out += "|log="+gSession->log;
    return out;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeEngineVersion(JNIEnv* e,jclass){int a=0,b=0;OCG_GetVersion(&a,&b);auto s=std::to_string(a)+"."+std::to_string(b);return e->NewStringUTF(s.c_str());}

extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionCreate(JNIEnv* e,jclass,jobject am){
    std::lock_guard<std::mutex> guard(gLock); destroySession();
    gSession=new Session(); gSession->assets=AAssetManager_fromJava(e,am);
    if(!gSession->assets||!loadDb(gSession)){destroySession();return e->NewStringUTF("FAIL|database");}
    OCG_DuelOptions o{};
    o.seed[0]=0x13572468; o.seed[1]=0x24681357; o.seed[2]=0x89abcdef; o.seed[3]=0x10293847;
    o.team1={8000,5,1}; o.team2={8000,5,1};
    o.cardReader=cardReader; o.cardReaderDone=cardReaderDone; o.scriptReader=scriptReader; o.logHandler=logHandler;
    o.payload1=o.payload2=o.payload3=o.payload4=gSession;
    int c=OCG_CreateDuel(&gSession->duel,&o);
    if(c!=OCG_DUEL_CREATION_SUCCESS){auto m="FAIL|create="+std::to_string(c);destroySession();return e->NewStringUTF(m.c_str());}
    for(const char* f:{"constant.lua","utility.lua"}){std::string b;if(readAsset(gSession->assets,std::string("engine/scripts/")+f,b))OCG_LoadScript(gSession->duel,b.data(),(uint32_t)b.size(),f);}
    auto m="PASS|cards="+std::to_string(gSession->cards.size()); return e->NewStringUTF(m.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionAddCard(JNIEnv* e,jclass,jint code,jint owner,jint controller,jint location,jint sequence,jint position){
    std::lock_guard<std::mutex> guard(gLock); if(!gSession||!gSession->duel)return e->NewStringUTF("FAIL|no-session");
    OCG_NewCardInfo i{(uint8_t)owner,(uint8_t)controller,(uint32_t)code,0,(uint32_t)location,(uint32_t)sequence,(uint32_t)position};
    OCG_DuelNewCard(gSession->duel,&i); return e->NewStringUTF("OK");
}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionStart(JNIEnv* e,jclass){std::lock_guard<std::mutex> guard(gLock);if(!gSession)return e->NewStringUTF("FAIL|no-session");OCG_StartDuel(gSession->duel);auto m=processFrame();return e->NewStringUTF(m.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionProcess(JNIEnv* e,jclass){std::lock_guard<std::mutex> guard(gLock);auto m=processFrame();return e->NewStringUTF(m.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionRespond(JNIEnv* e,jclass,jstring hex){
    std::lock_guard<std::mutex> guard(gLock); if(!gSession||!gSession->duel)return e->NewStringUTF("FAIL|no-session");
    const char* c=e->GetStringUTFChars(hex,nullptr);std::string s=c?c:"";if(c)e->ReleaseStringUTFChars(hex,c);
    std::vector<uint8_t> b;if(!hexDecode(s,b))return e->NewStringUTF("FAIL|bad-response");
    OCG_DuelSetResponse(gSession->duel,b.data(),(uint32_t)b.size());auto m=processFrame();return e->NewStringUTF(m.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionDestroy(JNIEnv*,jclass){std::lock_guard<std::mutex> guard(gLock);destroySession();}
