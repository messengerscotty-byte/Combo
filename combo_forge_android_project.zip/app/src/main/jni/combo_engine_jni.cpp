#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <cstring>
#include <mutex>
#include "ocgapi.h"

#define LOG_TAG "ComboForgeEngine"

struct CardRecord {
    uint32_t code=0, alias=0, type=0, level=0, attribute=0, lscale=0, rscale=0, link_marker=0;
    uint64_t race=0;
    int32_t attack=0, defense=0;
    std::vector<uint16_t> setcodes;
};
struct EngineSession {
    AAssetManager* assets=nullptr;
    OCG_Duel duel=nullptr;
    std::unordered_map<uint32_t,CardRecord> cards;
    std::string lastLog;
    bool started=false;
};
static std::mutex gMutex;
static EngineSession* gSession=nullptr;

static bool readAsset(AAssetManager* mgr,const char* path,std::string& out){
    AAsset* a=AAssetManager_open(mgr,path,AASSET_MODE_BUFFER); if(!a)return false;
    auto len=AAsset_getLength(a); out.resize((size_t)len); int got=AAsset_read(a,out.data(),(size_t)len); AAsset_close(a); return got==len;
}
static std::string hexEncode(const void* ptr,uint32_t len){
    static const char* h="0123456789abcdef"; const auto* p=(const uint8_t*)ptr; std::string s; s.resize((size_t)len*2);
    for(uint32_t i=0;i<len;i++){s[i*2]=h[p[i]>>4];s[i*2+1]=h[p[i]&15];} return s;
}
static bool hexDecode(const std::string& s,std::vector<uint8_t>& out){
    if(s.size()%2)return false; out.resize(s.size()/2);
    auto cv=[](char c)->int{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};
    for(size_t i=0;i<out.size();i++){int a=cv(s[i*2]),b=cv(s[i*2+1]);if(a<0||b<0)return false;out[i]=(uint8_t)((a<<4)|b);}return true;
}
static bool loadCardDb(EngineSession* s){
    std::string txt;if(!readAsset(s->assets,"engine-scripts/card-data.tsv",txt))return false;
    std::istringstream in(txt);std::string line;
    while(std::getline(in,line)){
        if(line.empty()||line[0]=='#')continue;std::istringstream row(line);std::string x;std::vector<unsigned long long> v;
        while(std::getline(row,x,'\t'))v.push_back(std::strtoull(x.c_str(),nullptr,10)); if(v.size()<9)continue;
        CardRecord r;r.code=(uint32_t)v[0];r.alias=(uint32_t)v[1];uint64_t packed=v[2];
        for(int i=0;i<4;i++){uint16_t sc=(uint16_t)((packed>>(16*i))&0xffffu);if(sc)r.setcodes.push_back(sc);}r.setcodes.push_back(0);
        r.type=(uint32_t)v[3];r.attack=(int32_t)v[4];r.defense=(int32_t)v[5];
        uint32_t rawLevel=(uint32_t)v[6];r.level=rawLevel & 0xffu;r.lscale=(rawLevel>>24)&0xffu;r.rscale=(rawLevel>>16)&0xffu;
        r.race=(uint64_t)v[7];r.attribute=(uint32_t)v[8];r.link_marker=(r.type & 0x4000000u)?(uint32_t)v[5]:0;
        s->cards.emplace(r.code,std::move(r));
    }return !s->cards.empty();
}
static void cardReader(void* payload,uint32_t code,OCG_CardData* data){
    auto* s=(EngineSession*)payload;std::memset(data,0,sizeof(*data));if(!s)return;auto it=s->cards.find(code);if(it==s->cards.end()){data->code=code;return;}auto& r=it->second;
    data->code=r.code;data->alias=r.alias;data->setcodes=r.setcodes.data();data->type=r.type;data->level=r.level;data->attribute=r.attribute;data->race=r.race;data->attack=r.attack;data->defense=r.defense;data->lscale=r.lscale;data->rscale=r.rscale;data->link_marker=r.link_marker;
}
static void cardReaderDone(void*,OCG_CardData*){}
static void logHandler(void* payload,const char* text,int){auto* s=(EngineSession*)payload;if(s&&text)s->lastLog=text;__android_log_print(ANDROID_LOG_INFO,LOG_TAG,"%s",text?text:"");}
static int scriptReader(void* payload,OCG_Duel duel,const char* name){
    auto* s=(EngineSession*)payload;if(!s||!name)return 0;std::string script,path;
    const std::string n(name);const char* roots[]={"engine-scripts/","engine-scripts/official/","engine-scripts/pre-release/","engine-scripts/unofficial/"};
    for(auto root:roots){path=std::string(root)+n;if(readAsset(s->assets,path.c_str(),script))return OCG_LoadScript(duel,script.data(),(uint32_t)script.size(),name);}return 0;
}
static void destroySession(){if(gSession){if(gSession->duel)OCG_DestroyDuel(gSession->duel);delete gSession;gSession=nullptr;}}
static std::string processNow(EngineSession* s){
    if(!s||!s->duel)return "FAIL|no-session";int status=OCG_DuelProcess(s->duel);uint32_t len=0;void* msg=OCG_DuelGetMessage(s->duel,&len);
    std::string out="OK|status="+std::to_string(status)+"|length="+std::to_string(len)+"|hex="+(msg&&len?hexEncode(msg,len):"");if(!s->lastLog.empty())out+="|log="+s->lastLog;return out;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeEngineVersion(JNIEnv* e,jclass){int a=0,b=0;OCG_GetVersion(&a,&b);auto s=std::to_string(a)+"."+std::to_string(b);return e->NewStringUTF(s.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeMilestoneTest(JNIEnv* e,jclass,jobject am){
    AAssetManager* assets=AAssetManager_fromJava(e,am);if(!assets)return e->NewStringUTF("FAIL|asset manager unavailable");std::lock_guard<std::mutex> lock(gMutex);destroySession();
    gSession=new EngineSession();gSession->assets=assets;if(!loadCardDb(gSession)){destroySession();return e->NewStringUTF("FAIL|card database unavailable");}
    OCG_DuelOptions o{};o.seed[0]=1;o.seed[1]=2;o.seed[2]=3;o.seed[3]=4;o.team1={8000,5,1};o.team2={8000,5,1};o.cardReader=cardReader;o.cardReaderDone=cardReaderDone;o.scriptReader=scriptReader;o.logHandler=logHandler;o.payload1=o.payload2=o.payload3=o.payload4=gSession;
    int c=OCG_CreateDuel(&gSession->duel,&o);if(c!=OCG_DUEL_CREATION_SUCCESS){auto m="FAIL|create="+std::to_string(c);destroySession();return e->NewStringUTF(m.c_str());}
    std::string constant,utility;bool a=readAsset(assets,"engine-scripts/constant.lua",constant)&&OCG_LoadScript(gSession->duel,constant.data(),(uint32_t)constant.size(),"constant.lua")>0;bool b=readAsset(assets,"engine-scripts/utility.lua",utility)&&OCG_LoadScript(gSession->duel,utility.data(),(uint32_t)utility.size(),"utility.lua")>0;
    OCG_NewCardInfo ash{0,0,14558127,0,0x02u,0,0x1u};if(a&&b)OCG_DuelNewCard(gSession->duel,&ash);bool ok=a&&b&&gSession->cards.count(14558127);destroySession();auto m=std::string(ok?"PASS":"FAIL")+"|database="+(ok?"loaded":"failed")+"|scripts=constant+utility|card=14558127";return e->NewStringUTF(m.c_str());
}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionCreate(JNIEnv* e,jclass,jobject am){
    std::lock_guard<std::mutex> lock(gMutex);destroySession();gSession=new EngineSession();gSession->assets=AAssetManager_fromJava(e,am);if(!gSession->assets||!loadCardDb(gSession)){destroySession();return e->NewStringUTF("FAIL|database");}
    OCG_DuelOptions o{};o.seed[0]=0x12345678;o.seed[1]=0x23456789;o.seed[2]=0x34567890;o.seed[3]=0x45678901;o.team1={8000,0,1};o.team2={8000,0,1};o.cardReader=cardReader;o.cardReaderDone=cardReaderDone;o.scriptReader=scriptReader;o.logHandler=logHandler;o.payload1=o.payload2=o.payload3=o.payload4=gSession;
    int c=OCG_CreateDuel(&gSession->duel,&o);if(c!=OCG_DUEL_CREATION_SUCCESS){auto m="FAIL|create="+std::to_string(c);destroySession();return e->NewStringUTF(m.c_str());}
    std::string x;for(const char* f:{"constant.lua","utility.lua"}){if(readAsset(gSession->assets,(std::string("engine-scripts/")+f).c_str(),x))OCG_LoadScript(gSession->duel,x.data(),(uint32_t)x.size(),f);}auto m="PASS|cards="+std::to_string(gSession->cards.size());return e->NewStringUTF(m.c_str());
}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionAddCard(JNIEnv* e,jclass,jint code,jint team,jint loc,jint seq,jint pos){std::lock_guard<std::mutex> lock(gMutex);if(!gSession||!gSession->duel)return e->NewStringUTF("FAIL|no-session");OCG_NewCardInfo i{(uint8_t)team,0,(uint32_t)code,0,(uint32_t)loc,(uint32_t)seq,(uint32_t)pos};OCG_DuelNewCard(gSession->duel,&i);return e->NewStringUTF("OK");}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionStart(JNIEnv* e,jclass){std::lock_guard<std::mutex> lock(gMutex);if(!gSession)return e->NewStringUTF("FAIL|no-session");OCG_StartDuel(gSession->duel);gSession->started=true;auto m=processNow(gSession);return e->NewStringUTF(m.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionProcess(JNIEnv* e,jclass){std::lock_guard<std::mutex> lock(gMutex);auto m=processNow(gSession);return e->NewStringUTF(m.c_str());}
extern "C" JNIEXPORT jstring JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionRespond(JNIEnv* e,jclass,jstring hex){std::lock_guard<std::mutex> lock(gMutex);if(!gSession)return e->NewStringUTF("FAIL|no-session");const char* p=e->GetStringUTFChars(hex,nullptr);std::string s=p?p:"";e->ReleaseStringUTFChars(hex,p);std::vector<uint8_t> b;if(!hexDecode(s,b))return e->NewStringUTF("FAIL|bad-response");OCG_DuelSetResponse(gSession->duel,b.data(),(uint32_t)b.size());auto m=processNow(gSession);return e->NewStringUTF(m.c_str());}
extern "C" JNIEXPORT void JNICALL Java_com_brickgame3_comboforge_MainActivity_nativeSessionDestroy(JNIEnv*,jclass){std::lock_guard<std::mutex> lock(gMutex);destroySession();}
