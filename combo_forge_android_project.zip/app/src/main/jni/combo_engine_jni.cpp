#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cstring>
#include "ocgapi.h"

#define LOG_TAG "ComboForgeEngine"

struct TestContext {
    AAssetManager* assets = nullptr;
    bool ashScriptRequested = false;
    bool ashScriptLoaded = false;
    std::string lastLog;
};

static bool readAsset(AAssetManager* mgr, const char* path, std::string& out) {
    AAsset* asset = AAssetManager_open(mgr, path, AASSET_MODE_BUFFER);
    if (!asset) return false;
    const auto len = AAsset_getLength(asset);
    out.resize(static_cast<size_t>(len));
    const int got = AAsset_read(asset, out.data(), static_cast<size_t>(len));
    AAsset_close(asset);
    return got == len;
}

static void cardReader(void*, uint32_t code, OCG_CardData* data) {
    std::memset(data, 0, sizeof(*data));
    data->code = code;
    if (code == 14558127) { // Ash Blossom & Joyous Spring
        data->type = 0x1u | 0x20u | 0x1000u; // MONSTER | EFFECT | TUNER
        data->level = 3;
        data->attribute = 0x4u; // FIRE
        data->race = 0x10u; // Zombie
        data->attack = 0;
        data->defense = 1800;
    }
}

static void cardReaderDone(void*, OCG_CardData*) {}

static void logHandler(void* payload, const char* text, int) {
    auto* ctx = static_cast<TestContext*>(payload);
    if (ctx && text) ctx->lastLog = text;
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "%s", text ? text : "");
}

static int scriptReader(void* payload, OCG_Duel duel, const char* name) {
    auto* ctx = static_cast<TestContext*>(payload);
    if (!ctx || !ctx->assets || !name) return 0;
    std::string assetPath;
    if (std::strcmp(name, "c14558127.lua") == 0) {
        ctx->ashScriptRequested = true;
        assetPath = "engine-scripts/official/c14558127.lua";
    } else {
        assetPath = std::string("engine-scripts/") + name;
    }
    std::string script;
    if (!readAsset(ctx->assets, assetPath.c_str(), script)) return 0;
    const int ok = OCG_LoadScript(duel, script.data(), static_cast<uint32_t>(script.size()), name);
    if (std::strcmp(name, "c14558127.lua") == 0 && ok > 0) ctx->ashScriptLoaded = true;
    return ok;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_brickgame3_comboforge_MainActivity_nativeEngineVersion(JNIEnv* env, jclass) {
    int major = 0, minor = 0;
    OCG_GetVersion(&major, &minor);
    const std::string value = std::to_string(major) + "." + std::to_string(minor);
    return env->NewStringUTF(value.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_brickgame3_comboforge_MainActivity_nativeMilestoneTest(JNIEnv* env, jclass, jobject assetManager) {
    TestContext ctx;
    ctx.assets = AAssetManager_fromJava(env, assetManager);
    if (!ctx.assets) return env->NewStringUTF("FAIL|asset manager unavailable");

    OCG_DuelOptions options{};
    options.seed[0] = 0x123456789abcdef0ULL;
    options.seed[1] = 0x0fedcba987654321ULL;
    options.seed[2] = 0x1122334455667788ULL;
    options.seed[3] = 0x8877665544332211ULL;
    options.team1 = {8000, 5, 1};
    options.team2 = {8000, 5, 1};
    options.cardReader = cardReader;
    options.cardReaderDone = cardReaderDone;
    options.scriptReader = scriptReader;
    options.logHandler = logHandler;
    options.payload1 = &ctx;
    options.payload2 = &ctx;
    options.payload3 = &ctx;
    options.payload4 = &ctx;
    options.enableUnsafeLibraries = 0;

    OCG_Duel duel = nullptr;
    const int created = OCG_CreateDuel(&duel, &options);
    if (created != OCG_DUEL_CREATION_SUCCESS || !duel) {
        const std::string msg = "FAIL|create duel status=" + std::to_string(created) + (ctx.lastLog.empty() ? "" : "|" + ctx.lastLog);
        return env->NewStringUTF(msg.c_str());
    }

    std::string constants, utility;
    bool constantsOk = readAsset(ctx.assets, "engine-scripts/constant.lua", constants)
        && OCG_LoadScript(duel, constants.data(), static_cast<uint32_t>(constants.size()), "constant.lua") > 0;
    bool utilityOk = readAsset(ctx.assets, "engine-scripts/utility.lua", utility)
        && OCG_LoadScript(duel, utility.data(), static_cast<uint32_t>(utility.size()), "utility.lua") > 0;

    OCG_NewCardInfo ash{};
    ash.team = 0;
    ash.duelist = 0;
    ash.code = 14558127;
    ash.con = 0;
    ash.loc = 0x02u; // LOCATION_HAND
    ash.seq = 0;
    ash.pos = 0x1u; // face-up attack; location is what matters for this smoke test
    if (constantsOk && utilityOk) OCG_DuelNewCard(duel, &ash);

    const bool cardOk = ctx.ashScriptRequested && ctx.ashScriptLoaded;
    OCG_DestroyDuel(duel);

    int major = 0, minor = 0;
    OCG_GetVersion(&major, &minor);
    std::string msg = (constantsOk && utilityOk && cardOk) ? "PASS" : "FAIL";
    msg += "|engine=" + std::to_string(major) + "." + std::to_string(minor);
    msg += "|duel=create/destroy";
    msg += constantsOk ? "|constant=loaded" : "|constant=failed";
    msg += utilityOk ? "|utility=loaded" : "|utility=failed";
    msg += cardOk ? "|card=c14558127.lua loaded" : "|card=c14558127.lua failed";
    if (!ctx.lastLog.empty()) msg += "|log=" + ctx.lastLog;
    return env->NewStringUTF(msg.c_str());
}
