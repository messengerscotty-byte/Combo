# Combo Forge Engine Architecture

Combo Forge is being migrated from text-derived actions to the Project Ignis
duel model.

## Authority

- `ygopro-core` owns duel state, legality, chains, costs, targets and resolution.
- Project Ignis `CardScripts` owns card-specific behavior.
- The Combo Forge UI translates engine prompts into phone-friendly selections.
- Manual steps remain available, but are explicitly unvalidated and never mutate
  authoritative engine state.

## Boundary

The web UI must not decide whether an action is legal. It sends an intent to the
native engine adapter and renders the returned choices. A completed engine
message becomes a combo step and a complete state snapshot, enabling reliable
undo and export.

## Migration stages

1. Native engine bridge and version reporting.
2. Duel creation from a saved deck and five-card starting hand.
3. Decode selectable-card, option, position, zone and chain prompts.
4. Convert resolved engine messages into combo steps.
5. Engine-backed undo by deterministic replay from the starting state.
6. Branching by cloning/replaying the action log.

Until a stage is implemented and tested, the UI must report it as unsupported.

