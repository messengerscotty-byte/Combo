# Combo Forge MVP

Mobile-first installable PWA prototype for building Yu-Gi-Oh! decks and documenting combos.

## Included now
- Live YGOPRODeck card search with image support and offline sample fallback
- Main / Extra / Side Deck sections
- Auto routing of Extra Deck monsters
- Total 3-copy validation across deck sections
- Deck sorting by type, alphabetic, level/rank/link, and ATK
- Five-card starting hand with `Any Card` placeholders
- Phone-friendly combo builder and card drawer
- Basic validation for one Normal Summon and Level 5+ tribute requirement
- Manual-action fallback for unsupported effects
- Full combo timeline, undo, summon count, Nibiru warning
- End-board view
- Long full-flow PNG export and deck-list PNG export
- Local autosave / resume using localStorage
- Installable PWA shell

## Run locally
Because browsers restrict service workers on `file://`, serve this folder over HTTP.

Python:
`python -m http.server 8080`

Then open `http://localhost:8080`.

## Important
This MVP does **not** claim to contain a complete Yu-Gi-Oh! rulings engine yet. Unsupported card effects are deliberately marked manual/unvalidated. The next engineering phase should add structured card effects, costs, targets, chains, restrictions, material validation, rulings/versioning, and automated tests.
