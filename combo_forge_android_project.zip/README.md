# Combo Forge v7.0 — native duel-client reset

This is the architecture reset requested after the WebView-only duel-client approach proved too fragile.

What changed:
- Added a native C++ duel-client adapter (`edopro_client_adapter.*`).
- Every framed ygopro-core message now passes through that native adapter before the WebView processes it.
- The adapter understands and validates the main interactive `MSG_SELECT_*` packet families and records native client state.
- Native packet underflow/trailing-byte mismatches are surfaced in the debug trace.
- The WebView remains the visual renderer for now; it is no longer intended to become the rules/protocol authority.
- `prepare-engine.sh` now checks out `edo9300/edopro` under `vendor/edopro` as the open-source client reference, alongside ygopro-core and Project Ignis data.
- EDOPro license files are copied into app assets when dependencies are prepared.
- Existing Deck Editor, updater, saved decks, selected starting hand, Combo field UI, and flow recording are preserved.

Important:
This is the first native-client milestone, not a claim that the entire EDOPro/OMEGA gameplay stack has already been ported. The next milestones are to move response encoding, selectable-card ownership, field-query reconciliation, chains, and command generation fully into C++ and then retire the duplicate JavaScript protocol implementation.

No proprietary YGO Omega source code or assets are included.
