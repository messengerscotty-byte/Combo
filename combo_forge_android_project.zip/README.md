# Combo Forge v5.4

Known-good v5.3 startup retained.

## Added
- Current BabelCDB card database loaded from bundled `engine/db/cards.tsv`
- Omega-style Deck Editor layout with card preview, Main/Extra/Side zones, and searchable results
- Search by name/effect text, card category, monster kind, attribute, race, Level/Rank, minimum ATK/DEF, and sorting
- Automatic Main vs Extra Deck routing
- 3-copy, 60 Main, 15 Extra, and 15 Side limits
- Tap a search result to add it; hold to add to Side Deck
- Tap a deck card to preview it; double-tap to remove it
- Saved multi-deck support retained
- Live card artwork loaded from the YGOPRODeck image CDN when internet is available

The duel field is intentionally still a shell. Engine-driven duel protocol automation is the next milestone.
