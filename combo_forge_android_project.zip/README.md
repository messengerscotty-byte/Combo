# Combo Forge v6.0 — Combo Engine Protocol + Flow Recorder

This build moves Combo Lab much closer to a real simulator client.

Implemented client-side prompt handling for the modern ygopro-core protocol:
- `MSG_SELECT_IDLECMD`
- `MSG_SELECT_EFFECTYN`
- `MSG_SELECT_YESNO`
- `MSG_SELECT_OPTION`
- `MSG_SELECT_CARD`
- `MSG_SELECT_CHAIN`
- `MSG_SELECT_PLACE`
- `MSG_SELECT_DISFIELD`
- `MSG_SELECT_POSITION`
- `MSG_SELECT_TRIBUTE`
- `MSG_SELECT_COUNTER`
- `MSG_SELECT_SUM`
- `MSG_SORT_CARD`
- `MSG_SORT_CHAIN`
- `MSG_SELECT_UNSELECT_CARD`

Field/session handling includes MOVE, DRAW, position, turn/phase, summon/chain trace messages.

Combo flow recording:
- Every player action/selection is recorded during the session.
- `SAVE FLOW CHART` stores the combo in localStorage.
- Saved combo flow charts appear on the Combo Lab setup screen.
- A flow viewer renders each step vertically.
- `COPY FLOW CHART TEXT` produces Mermaid flow-chart markup.

Important: this is a substantial protocol implementation, but it has not been device-tested across every Yu-Gi-Oh card/script edge case. The app deliberately exposes core RETRY/errors instead of inventing card-specific behavior.
