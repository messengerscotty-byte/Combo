# Combo Forge v2.0

Simulator-engine foundation milestone.

- Landscape Android UI and existing multi-deck saving preserved.
- `ygopro-core` still compiles as `libocgcore.so` for `arm64-v8a`.
- Full Project Ignis `CardScripts` is copied into APK assets at build time.
- Project Ignis `BabelCDB/cards.cdb` is converted at build time into a compact native card-data table so ocgcore gets real card type/level/ATK/DEF/race/attribute/setcode data.
- New JNI duel-session transport exposes create/add-card/start/process/respond/destroy around `OCG_StartDuel`, `OCG_DuelProcess`, `OCG_DuelGetMessage`, and `OCG_DuelSetResponse`.
- Entering the Combo Field now creates a real native duel session and seeds Main Deck, exact starting hand, and Extra Deck into ocgcore.

## Honest status
This is the engine transport layer required for EDOPro-style interaction. The app does **not** yet claim universal automated effects: the next step is decoding every relevant ocgcore message type into visual prompts (legal targets, zones, materials, chain choices) and encoding the corresponding responses. Existing validated/hard-coded combo helpers remain available while that protocol UI is being replaced.
