# Combo Forge v1.8 — landscape combo field

This keeps the v1.6 portrait mobile UI, multi-deck local saving, web/PWA assets, GitHub Pages layout, and Android WebView APK workflow.

## v1.8 changes

The Android APK now builds `edo9300/ygopro-core` with the Android NDK for **arm64-v8a** and links it to a JNI bridge. At app startup the engine panel performs a smoke test that:

1. reads `OCG_GetVersion()` from the real native core;
2. creates an `OCG_Duel` with non-null card/script/log callbacks;
3. loads Project Ignis `constant.lua` and `utility.lua`;
4. adds Ash Blossom & Joyous Spring (`14558127`) so the core requests and loads the real Project Ignis `official/c14558127.lua` through the script callback;
5. destroys the duel;
6. reports PASS/FAIL in the app.

The Android app is now locked to landscape and the Combo Lab transitions from five-card hand selection into a full-screen duel-field interface inspired by modern duel simulators while keeping Combo Forge's own visual design. The authoritative ygopro-core/JNI milestone remains included.

**Automation status:** the native core now compiles into the APK, but arbitrary card-effect automation is not being claimed yet. The current UI still uses the existing validated rules/known-effect handlers with manual fallback while the next engine stage implements the full OCG process/message/response loop and card database coverage.

## Build

The project intentionally does not vendor thousands of upstream source files. `app:prepareEngine` clones:

- https://github.com/edo9300/ygopro-core (recursively, including Lua)
- https://github.com/ProjectIgnis/CardScripts

Then `ndk-build` compiles `libocgcore.so` plus `libcomboengine.so` for arm64-v8a. The exact revisions used in a build are written into `assets/engine-scripts/SOURCE-REVISIONS.txt`.

From the project root:

```bash
gradle assembleDebug
```

The existing repository GitHub Actions workflow can continue extracting this project ZIP and running that command.

## GitHub Pages

Pages still publishes `app/src/main/assets`. The web version keeps deck/combo/library behavior; its engine card correctly shows WEB ONLY because JNI is Android-only.

## Licensing

`ygopro-core` is AGPL-3.0-or-later. Project Ignis CardScripts are their upstream canonical scripts. Review and satisfy upstream license requirements before distributing releases beyond private testing.
