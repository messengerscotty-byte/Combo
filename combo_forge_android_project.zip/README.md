# Combo Forge v5.9 — In-app updater

- Checks `https://messengerscotty-byte.github.io/Combo/update/latest.json` automatically shortly after app startup.
- Shows an in-app update prompt when a newer version is published.
- Downloads the new APK inside Combo Forge and opens Android's installer.
- If Android requires permission, opens the per-app “Install unknown apps” settings page and keeps the downloaded APK ready.
- Adds a manual app-update check in Settings.
- Uses a stable development signing key from v5.9 forward so future APKs can install as updates to the same package.
- Keeps Project Ignis card database/script updating separate from app updates.

Important: Android does not allow a normal app to silently replace itself. The updater removes the GitHub download step, but Android will still require the user to confirm installation.

The development signing key is suitable for this private/testing workflow. Before public distribution, migrate signing to a private GitHub Actions secret.
