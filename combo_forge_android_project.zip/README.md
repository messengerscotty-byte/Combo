# Combo Forge v4.0

Landscape-first rebuild of Combo Forge.

## Implemented in v4
- Full app locked to landscape on Android.
- Simulator-style home screen, deck manager, deck editor, and combo field.
- Multi-deck local saving preserved.
- Advanced YGOProDeck search/filter panel.
- Interactive combo field: draw/reset hands, summon/set from hand, activate/set Spell/Trap cards, move cards to GY/banished/hand, inspect Deck/Extra/GY/banished piles, and simple Extra Deck material matching for Synchro/Xyz/Link/Fusion.
- Existing ygopro-core + Project Ignis native engine transport retained.

## Automation status
The field is now interactive and usable for combo prototyping, but full Omega/EDOPro-style rules automation is not yet claimed. The next layer is decoding ygopro-core selection/move/chain messages and feeding responses back into the core so legality comes entirely from the engine.
