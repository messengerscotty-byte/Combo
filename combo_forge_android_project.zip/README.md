# Combo Forge v6.2 — Duel-client Combo Lab

This build redesigns the active Combo Lab around a simulator-style duel field while keeping the v6.1 ygopro-core protocol layer underneath it.

Visual/interaction changes:
- Full-width duel field replaces the permanent debug HUD.
- Opponent field mirrored at the top.
- Player monster and spell/trap zones positioned like a real duel client.
- Deck / Extra / GY / Banished piles placed around the field.
- Hand is displayed as a bottom fan; selected cards raise/highlight.
- Legal engine actions appear contextually beside the selected card.
- Battle/End phase buttons are integrated into the center rail when legal.
- Engine prompts are compact centered overlays.
- Debug/core trace is hidden in a slide-out drawer.
- Flow recording remains active in the background and is saved from a small utility button.

No proprietary Omega assets or code are included. The build reproduces the interaction pattern with Combo Forge's own UI on top of Project Ignis CardScripts + ygopro-core.
