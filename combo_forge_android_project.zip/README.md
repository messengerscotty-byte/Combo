# Combo Forge v6.1 — Protocol hardening

This build fixes the packet/response alignment problems observed in the v6.0 Fortuna test.

Key fixes:
- `MSG_SELECT_OPTION`: count is decoded as uint8, matching EDOPro.
- `MSG_SELECT_TRIBUTE`: uses its real code/controller/location/sequence/tribute-value format instead of incorrectly treating entries as loc_info.
- `MSG_SELECT_COUNTER`: uses the real compact controller/location/sequence structure and sends uint16 allocations.
- `MSG_SELECT_SUM`: mandatory materials are separated from selectable response indices.
- `MSG_SELECT_UNSELECT_CARD`: sends EDOPro's exact `{1, select_seq}` two-uint32 response.
- General card-selection responses now mirror EDOPro's modern ProgressiveBuffer format (bitfield / uint8 / uint16 / uint32 modes).
- `MSG_SELECT_CHAIN` is validated for trailing bytes.
- Prompt decoders log packet byte lengths and decoder leftovers to expose future protocol mismatch instead of silently inventing card IDs.
- Tribute readiness uses tribute values rather than card count alone.

No card-specific effect logic was added. Project Ignis CardScripts + ygopro-core remain authoritative.
