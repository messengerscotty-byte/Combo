# Combo Forge v3.0

Landscape-first rebuild.

## Included in this milestone
- Entire Android application locked to landscape.
- New original Combo Forge home screen.
- Deck Manager with multiple saved decks, create/delete/import/export.
- Landscape Deck Editor modeled on simulator workflow without copying Omega assets.
- Advanced card search filters: name, card family, attribute, race/type, monster kind, level/rank, ATK, DEF, archetype, sorting.
- Main / Extra / Side deck editing and card detail panel.
- Combo Lab landscape field shell.
- Existing ygopro-core + Project Ignis CardScripts/BabelCDB JNI integration retained.
- Native duel session create/add/start transport retained.

## Automation status
Full ygopro-core message/response protocol decoding is not complete yet. v3.0 does not claim full Omega-style automation.
