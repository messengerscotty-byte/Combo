# Combo Forge v5.6

## Data/update system
- Full BabelCDB card database is bundled in every APK build.
- Full Project Ignis CardScripts are bundled in every APK build.
- The app asynchronously checks Project Ignis GitHub revisions after startup.
- Settings can download the newest `cards.cdb`, convert it locally to Combo Forge's TSV database, and download/activate the newest CardScripts without reinstalling the APK.
- `ygopro-core` prefers downloaded database/scripts on the next duel session and falls back to the bundled copies.
- Card artwork remains remote to keep APK size manageable; Android now intercepts and caches viewed YGOPRODeck card images locally.

The safe v5.3 startup architecture remains intact. Updates never block initial UI startup.
