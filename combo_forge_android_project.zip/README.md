# Combo Forge v2.1

Fix release for the simulator-style combo field.

- Fixes all dynamic choice-sheet buttons that use hyphenated `data-*` attributes, including Synchro target/material selection.
- Forces Android sensor-landscape in manifest, onCreate, and onResume.
- Enables native fullscreen window + immersive system UI.
- Keeps the v2.0 native ygopro-core duel-session bridge intact.

Full universal automation is still in progress; this release specifically fixes the non-responsive Extra Deck selection and orientation shell.
