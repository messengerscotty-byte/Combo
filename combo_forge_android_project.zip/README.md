# Combo Forge 5.0 — clean restart

This tree is a clean-room restart of the Android client. It does not reuse the v1–v4 front-end.

## Goal
Match the *workflow and simulator behavior* users expect from YGO Omega while using original Combo Forge branding/UI assets and an open authoritative duel stack.

## Authoritative/open components pulled at build time
- `edo9300/ygopro-core` — duel/rules engine (AGPL-3.0-or-later)
- `ProjectIgnis/CardScripts` — canonical card scripts (AGPL-3.0-or-later)
- `ProjectIgnis/BabelCDB` — card database
- `ProjectIgnis/LFLists` — forbidden/limited lists
- `edo9300/edopro` — open-source **client protocol reference** only; not packaged into the app

YGO Omega's public GitHub repository is a releases/config hub, not the full current client source. The app therefore does not copy Omega binaries/assets/source. We reproduce interaction patterns with our own implementation.

## Architecture
1. Android landscape shell + WebView UI.
2. NDK `libocgcore.so` built for `arm64-v8a`.
3. JNI transport wrapping duel create/add/start/process/respond/destroy.
4. Full Project Ignis scripts + Babel card data available offline.
5. Next milestone: implement the EDOPro-compatible message decoder/response encoder (`MSG_SELECT_*`, `MSG_MOVE`, summon/chain messages) and render the field from core state.

## Current alpha UI
- simulator-style home
- deck manager
- deck editor with Main/Extra/Side and card search
- Combo Lab that can create/seed/process a real ocgcore session

This is not yet full automatic gameplay; protocol decoding is intentionally the next milestone.
