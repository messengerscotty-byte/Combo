# Combo Forge Combo Engine Flow Chart

```mermaid
flowchart TD
    A[Open Combo Lab] --> B[Choose saved deck]
    B --> C[Choose exact 5-card hand or Random 5]
    C --> D[Create ygopro-core duel]
    D --> E[Load hand / remaining Main Deck / Extra Deck]
    E --> F[OCG_StartDuel]
    F --> G[Process packet stream]
    G --> H{Message type}

    H -->|SELECT_IDLECMD| I[Show only engine-legal actions]
    I --> J[Normal Summon / Special Summon / Set / Activate / Phase]
    J --> K[Encode action response]
    K --> G

    H -->|SELECT_EFFECTYN / YESNO| L[Yes / No prompt]
    L --> M[Encode integer response]
    M --> G

    H -->|SELECT_OPTION| N[Show effect options]
    N --> O[Encode selected option index]
    O --> G

    H -->|SELECT_CARD / TRIBUTE / SUM / UNSELECT| P[Show selectable cards]
    P --> Q[Track selected indices]
    Q --> R[Encode modern selected-card response]
    R --> G

    H -->|SELECT_CHAIN| S[Show chainable cards + Do Not Chain]
    S --> T[Encode chain index or -1]
    T --> G

    H -->|SELECT_PLACE / DISFIELD| U[Show legal zones]
    U --> V[Encode controller/location/sequence]
    V --> G

    H -->|SELECT_POSITION| W[Show legal battle positions]
    W --> X[Encode chosen position]
    X --> G

    H -->|SORT_CARD / SORT_CHAIN| Y[Reorder cards]
    Y --> Z[Encode selected order]
    Z --> G

    H -->|MOVE / DRAW / POSITION / PHASE| AA[Update visible field model]
    AA --> G

    H -->|SUMMONED / SPSUMMONED / CHAIN_END| AB[Refresh action state]
    AB --> G

    J --> AC[Record combo step]
    L --> AC
    N --> AC
    P --> AC
    S --> AC
    U --> AC
    W --> AC
    Y --> AC

    AC --> AD[Session flow recorder]
    AD --> AE[Save Flow Chart]
    AE --> AF[Persist in localStorage]
    AF --> AG[View saved combo as step-by-step flow]
    AG --> AH[Copy Mermaid flow-chart text]
```

## Design rule

The UI never invents card effects. Project Ignis CardScripts and `ygopro-core` remain authoritative. Combo Forge only decodes core prompts, presents legal choices, encodes the user's response, updates the visual field, and records the resulting combo path.
