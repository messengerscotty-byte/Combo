# Combo Forge v7 native duel-client architecture

```mermaid
flowchart TD
    A[Saved Deck + Exact Starting Hand] --> B[Android / JNI]
    B --> C[ygopro-core]
    C --> D[Project Ignis CardScripts]
    D --> C
    C --> E[Core message stream]
    E --> F[Native C++ Duel Client Adapter]
    F --> G{Message}
    G -->|SELECT_*| H[Native protocol validation]
    G -->|MOVE / DRAW / CHAIN / PHASE| I[Native duel state events]
    H --> J[Combo Forge renderer]
    I --> J
    J --> K[Player selects card / zone / effect / phase]
    K --> L[Native response layer]
    L --> C

    F --> M[Flow recorder]
    M --> N[Saved combo flow]
```

## v7 rule

The WebView is now treated as the presentation shell, not the authoritative duel client.

`ygopro-core` and Project Ignis CardScripts remain the rules authority. A native C++ adapter now consumes the same framed core message stream before the UI sees it, validates interactive packet structures, owns native duel-client state metadata, and reports protocol errors. This is the first step in moving selection handling and field synchronization out of JavaScript.

The source preparation step also pulls the official open-source `edo9300/edopro` client into `vendor/edopro` as the reference implementation and preserves its license notices. EDOPro is AGPLv3/GPLv3 depending on module ancestry; Combo Forge must retain and comply with those licenses when code is ported.
