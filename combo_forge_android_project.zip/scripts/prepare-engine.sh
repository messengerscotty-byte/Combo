#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENDOR="$ROOT/vendor"
ASSETS="$ROOT/app/src/main/assets/engine-scripts"
mkdir -p "$VENDOR" "$ASSETS"
clone_or_update() {
  local url="$1" dir="$2"
  if [ ! -d "$dir/.git" ]; then git clone --depth 1 --recurse-submodules --shallow-submodules "$url" "$dir"
  else git -C "$dir" fetch --depth 1 origin master || true; git -C "$dir" reset --hard FETCH_HEAD || true; git -C "$dir" submodule update --init --recursive --depth 1
  fi
}
clone_or_update https://github.com/edo9300/ygopro-core.git "$VENDOR/ygopro-core"
clone_or_update https://github.com/ProjectIgnis/CardScripts.git "$VENDOR/CardScripts"
clone_or_update https://github.com/ProjectIgnis/BabelCDB.git "$VENDOR/BabelCDB"
rm -rf "$ASSETS"
mkdir -p "$ASSETS"
cp -a "$VENDOR/CardScripts/." "$ASSETS/"
rm -rf "$ASSETS/.git" "$ASSETS/.github"
python3 - "$VENDOR/BabelCDB/cards.cdb" "$ASSETS/card-data.tsv" <<'PY'
import sqlite3, sys
src,out=sys.argv[1:]
con=sqlite3.connect(src)
cols={r[1] for r in con.execute('pragma table_info(datas)')}
need=['id','alias','setcode','type','atk','def','level','race','attribute']
missing=[x for x in need if x not in cols]
if missing: raise SystemExit('BabelCDB datas schema missing '+','.join(missing))
with open(out,'w',encoding='utf-8',newline='\n') as f:
    f.write('# code\talias\tsetcode\ttype\tatk\tdef\tlevel\trace\tattribute\n')
    for row in con.execute('select id,alias,setcode,type,atk,def,level,race,attribute from datas order by id'):
        f.write('\t'.join(str(int(x or 0)) for x in row)+'\n')
PY
{
 echo "ygopro-core=$(git -C "$VENDOR/ygopro-core" rev-parse HEAD)"
 echo "CardScripts=$(git -C "$VENDOR/CardScripts" rev-parse HEAD)"
 echo "BabelCDB=$(git -C "$VENDOR/BabelCDB" rev-parse HEAD)"
} > "$ASSETS/SOURCE-REVISIONS.txt"
