#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENDOR="$ROOT/vendor"
CORE="$VENDOR/ygopro-core"
SCRIPTS="$VENDOR/CardScripts"
mkdir -p "$VENDOR" "$ROOT/app/src/main/assets/engine-scripts/official"

if [ ! -d "$CORE/.git" ]; then
  rm -rf "$CORE"
  git clone --depth 1 --recurse-submodules --shallow-submodules https://github.com/edo9300/ygopro-core.git "$CORE"
else
  git -C "$CORE" submodule update --init --recursive
fi

if [ ! -d "$SCRIPTS/.git" ]; then
  rm -rf "$SCRIPTS"
  git clone --depth 1 https://github.com/ProjectIgnis/CardScripts.git "$SCRIPTS"
fi

cp "$SCRIPTS/constant.lua" "$ROOT/app/src/main/assets/engine-scripts/constant.lua"
cp "$SCRIPTS/utility.lua" "$ROOT/app/src/main/assets/engine-scripts/utility.lua"
cp "$SCRIPTS/official/c14558127.lua" "$ROOT/app/src/main/assets/engine-scripts/official/c14558127.lua"
printf '%s\n' "edo9300/ygopro-core: $(git -C "$CORE" rev-parse HEAD)" > "$ROOT/app/src/main/assets/engine-scripts/SOURCE-REVISIONS.txt"
printf '%s\n' "ProjectIgnis/CardScripts: $(git -C "$SCRIPTS" rev-parse HEAD)" >> "$ROOT/app/src/main/assets/engine-scripts/SOURCE-REVISIONS.txt"
