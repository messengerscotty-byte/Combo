#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VENDOR="$ROOT/vendor"
ASSETS="$ROOT/app/src/main/assets/engine"
REF="$ROOT/reference"
LICENSES="$ROOT/app/src/main/assets/licenses"
mkdir -p "$VENDOR" "$ASSETS" "$REF" "$LICENSES"

clone_repo(){
  local url="$1" dir="$2"
  if [ ! -d "$dir/.git" ]; then
    git clone --depth 1 --recurse-submodules --shallow-submodules "$url" "$dir"
  else
    git -C "$dir" fetch --depth 1 origin
    git -C "$dir" reset --hard FETCH_HEAD
    git -C "$dir" submodule update --init --recursive --depth 1
  fi
}

clone_repo https://github.com/edo9300/ygopro-core.git "$VENDOR/ygopro-core"
clone_repo https://github.com/ProjectIgnis/CardScripts.git "$VENDOR/CardScripts"
clone_repo https://github.com/ProjectIgnis/BabelCDB.git "$VENDOR/BabelCDB"
clone_repo https://github.com/ProjectIgnis/LFLists.git "$VENDOR/LFLists"
clone_repo https://github.com/edo9300/edopro.git "$VENDOR/edopro"
rm -rf "$REF/edopro"
ln -s ../vendor/edopro "$REF/edopro" 2>/dev/null || true

rm -rf "$ASSETS"
mkdir -p "$ASSETS/scripts" "$ASSETS/banlists" "$ASSETS/db"
mkdir -p "$LICENSES"
cp "$VENDOR/edopro/LICENSE" "$LICENSES/EDOPRO-LICENSE.txt" 2>/dev/null || true
cp "$VENDOR/edopro/COPYING" "$LICENSES/EDOPRO-COPYING.txt" 2>/dev/null || true
cp -a "$VENDOR/CardScripts/." "$ASSETS/scripts/"
rm -rf "$ASSETS/scripts/.git" "$ASSETS/scripts/.github"
cp "$VENDOR/BabelCDB/cards.cdb" "$ASSETS/db/cards.cdb"
cp "$VENDOR/LFLists"/*.lflist.conf "$ASSETS/banlists/" 2>/dev/null || true

python3 - "$VENDOR/BabelCDB/cards.cdb" "$ASSETS/db/cards.tsv" <<'PY'
import sqlite3, sys, pathlib
src,out=sys.argv[1:]
con=sqlite3.connect(src)
q='''select d.id,d.alias,d.setcode,d.type,d.atk,d.def,d.level,d.race,d.attribute,
            coalesce(t.name,''),coalesce(t.desc,'')
     from datas d left join texts t on t.id=d.id order by d.id'''
with open(out,'w',encoding='utf-8',newline='\n') as f:
    f.write('#id\talias\tsetcode\ttype\tatk\tdef\tlevel\trace\tattribute\tname\tdesc\n')
    for row in con.execute(q):
        nums=[str(int(x or 0)) for x in row[:9]]
        text=[str(x or '').replace('\\','\\\\').replace('\t','\\t').replace('\n','\\n').replace('\r','') for x in row[9:]]
        f.write('\t'.join(nums+text)+'\n')
PY

{
  echo "ygopro-core=$(git -C "$VENDOR/ygopro-core" rev-parse HEAD)"
  echo "CardScripts=$(git -C "$VENDOR/CardScripts" rev-parse HEAD)"
  echo "BabelCDB=$(git -C "$VENDOR/BabelCDB" rev-parse HEAD)"
  echo "LFLists=$(git -C "$VENDOR/LFLists" rev-parse HEAD)"
  echo "EDOPro-client=$(git -C "$VENDOR/edopro" rev-parse HEAD)"
} > "$ASSETS/SOURCE-REVISIONS.txt"
