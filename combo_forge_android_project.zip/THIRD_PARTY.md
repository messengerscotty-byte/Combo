# Third-party engine notice

Combo Forge's planned rules backend uses:

- ygopro-core / EDOPro core: https://github.com/edo9300/ygopro-core
- Project Ignis CardScripts: https://github.com/ProjectIgnis/CardScripts

Both projects are licensed under GNU AGPL version 3 or later. Their copyright
notices and source history must be preserved when incorporated. Combo Forge
will publish corresponding source for distributed builds that contain them.

